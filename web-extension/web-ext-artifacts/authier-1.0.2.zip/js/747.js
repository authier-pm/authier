"use strict";
(self["webpackChunkauthier_web_extension"] = self["webpackChunkauthier_web_extension"] || []).push([[747],{

/***/ 15485:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.chakraRawTheme = exports.authierColors = void 0;
// 2. Extend the theme to include custom colors, fonts, etc
exports.authierColors = {
    brand: {
        100: '#F0C645',
        200: '#FFC045',
        300: '#FC045A',
        700: '#0691AB',
        800: '#0F01AB'
    },
    orange: {
        '50': '#FFF6E5',
        '100': '#FFE7B8',
        '200': '#FFD78A',
        '300': '#FFC85C',
        '400': '#FFB82E',
        '500': '#FFA900',
        '600': '#CC8700',
        '700': '#996500',
        '800': '#664300',
        '900': '#332200'
    },
    gray: {
        '50': '#F0F4F4',
        '100': '#D6E0E0',
        '200': '#BCCDCD',
        '300': '#A2B9B9',
        '400': '#88A5A5',
        '500': '#6D9292',
        '600': '#577575',
        '700': '#425757',
        '800': '#2C3A3A',
        '900': '#161D1D'
    },
    green: {
        '50': '#E9FBF9',
        '100': '#C2F5EE',
        '200': '#9BEEE3',
        '300': '#74E7D8',
        '400': '#4CE0CD',
        '500': '#25DAC2',
        '600': '#1EAE9B',
        '700': '#168375',
        '800': '#0F574E',
        '900': '#072C27'
    },
    teal: {
        '50': '#EAFBFB',
        '100': '#C3F3F3',
        '200': '#9DECEB',
        '300': '#77E4E3',
        '400': '#50DDDC',
        '500': '#2AD5D4',
        '600': '#21ABA9',
        '700': '#19807F',
        '800': '#115555',
        '900': '#082B2A'
    },
    cyan: {
        '50': '#E5FBFF',
        '100': '#B8F4FF',
        '200': '#8AEEFF',
        '300': '#5CE7FF',
        '400': '#2EE0FF',
        '500': '#00D9FF',
        '600': '#3FC1C9',
        '700': '#008299',
        '800': '#005766',
        '900': '#002B33'
    }
};
exports.chakraRawTheme = {
    colors: exports.authierColors,
    config: {
        initialColorMode: 'dark'
    }
};
// brand: {
//   50: '#84CAE7',
//   100: '#68D5DD',
//   200: '#5ADBD8',
//   300: '#4CE0D2',
//   400: '#37C5BA',
//   500: '#22AAA1',
//   600: '#1B8D82',
//   700: '#136F63',
//   800: '#0C453C',
//   900: '#041B15'
// }


/***/ }),

/***/ 40729:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.errorLink = void 0;
const error_1 = __webpack_require__(17309);
const graphql_1 = __webpack_require__(95237);
//@ts-ignore
const ExtensionDevice_1 = __webpack_require__(2247);
const Providers_1 = __webpack_require__(62142);
// Log any GraphQL errors or network error that occurred
exports.errorLink = (0, error_1.onError)(({ graphQLErrors, networkError, operation }) => {
    var _a;
    if (graphQLErrors) {
        if (graphQLErrors[0].message === 'not authenticated') {
            //Here just logout the user
            ExtensionDevice_1.device.clearAndReload();
        }
        graphQLErrors.map(({ message, path }) => {
            console.error(`[GraphQL error]: Message: ${message}, operation: ${operation.operationName}, Path: ${path}`);
            console.error('full operation: ', (0, graphql_1.print)(operation.query));
        });
        (0, Providers_1.toast)({
            title: (_a = graphQLErrors[0].message) !== null && _a !== void 0 ? _a : 'There was API error.',
            status: 'warning',
            isClosable: true
        });
    }
    else if (networkError) {
        console.log('pepe');
        console.error(`[Network error]: ${networkError}`);
        (0, Providers_1.toast)({
            title: 'There was network error.',
            status: 'error',
            isClosable: true
        });
    }
});


/***/ }),

/***/ 28091:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TOTPSchema = exports.PasswordSchema = void 0;
const Yup = __importStar(__webpack_require__(87017));
exports.PasswordSchema = Yup.object().shape({
    url: Yup.string().url('Invalid URL').required('Required'),
    label: Yup.string().required('Required'),
    username: Yup.string().required('Required'),
    password: Yup.string().required('Required')
});
exports.TOTPSchema = Yup.object().shape({
    url: Yup.string().url('Invalid URL').required('Required'),
    label: Yup.string().required('Required'),
    secret: Yup.string().required('Required'),
    iconUrl: Yup.string().url('Invalid URL').nullable(),
    digits: Yup.number().min(6).max(8).required('Required'),
    period: Yup.number().min(30).max(120).required('Required')
});


/***/ }),

/***/ 89931:
/***/ ((__unused_webpack_module, exports) => {


/** All built-in and custom scalars, mapped to their actual values */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.WebInputType = exports.TokenType = exports.EncryptedSecretType = exports.EmailVerificationType = void 0;
(function (EmailVerificationType) {
    EmailVerificationType["CONTACT"] = "CONTACT";
    EmailVerificationType["PRIMARY"] = "PRIMARY";
})(exports.EmailVerificationType || (exports.EmailVerificationType = {}));
(function (EncryptedSecretType) {
    EncryptedSecretType["LOGIN_CREDENTIALS"] = "LOGIN_CREDENTIALS";
    EncryptedSecretType["TOTP"] = "TOTP";
})(exports.EncryptedSecretType || (exports.EncryptedSecretType = {}));
(function (TokenType) {
    TokenType["API"] = "API";
    TokenType["EMAIL"] = "EMAIL";
})(exports.TokenType || (exports.TokenType = {}));
(function (WebInputType) {
    WebInputType["CUSTOM"] = "CUSTOM";
    WebInputType["EMAIL"] = "EMAIL";
    WebInputType["NEW_PASSWORD"] = "NEW_PASSWORD";
    WebInputType["NEW_PASSWORD_CONFIRMATION"] = "NEW_PASSWORD_CONFIRMATION";
    WebInputType["PASSWORD"] = "PASSWORD";
    WebInputType["SUBMIT_BUTTON"] = "SUBMIT_BUTTON";
    WebInputType["TOTP"] = "TOTP";
    WebInputType["USERNAME"] = "USERNAME";
    WebInputType["USERNAME_OR_EMAIL"] = "USERNAME_OR_EMAIL";
})(exports.WebInputType || (exports.WebInputType = {}));


/***/ }),

/***/ 8756:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useChangeMasterDeviceMutation = exports.ChangeMasterDeviceDocument = exports.useRemoveDeviceMutation = exports.RemoveDeviceDocument = exports.useLogoutDeviceMutation = exports.LogoutDeviceDocument = exports.useDevicesRequestsLazyQuery = exports.useDevicesRequestsQuery = exports.DevicesRequestsDocument = exports.useApproveChallengeMutation = exports.ApproveChallengeDocument = exports.useRejectChallengeMutation = exports.RejectChallengeDocument = exports.useMyDevicesLazyQuery = exports.useMyDevicesQuery = exports.MyDevicesDocument = void 0;
const client_1 = __webpack_require__(91416);
const Apollo = __importStar(__webpack_require__(91416));
const defaultOptions = {};
exports.MyDevicesDocument = (0, client_1.gql) `
    query myDevices {
  me {
    id
    masterDeviceId
    devices {
      id
      name
      firstIpAddress
      lastIpAddress
      logoutAt
      lastGeoLocation
      createdAt
      lastSyncAt
      platform
      createdAt
    }
  }
}
    `;
/**
 * __useMyDevicesQuery__
 *
 * To run a query within a React component, call `useMyDevicesQuery` and pass it any options that fit your needs.
 * When your component renders, `useMyDevicesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useMyDevicesQuery({
 *   variables: {
 *   },
 * });
 */
function useMyDevicesQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.MyDevicesDocument, options);
}
exports.useMyDevicesQuery = useMyDevicesQuery;
function useMyDevicesLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.MyDevicesDocument, options);
}
exports.useMyDevicesLazyQuery = useMyDevicesLazyQuery;
exports.RejectChallengeDocument = (0, client_1.gql) `
    mutation RejectChallenge($id: Int!) {
  me {
    decryptionChallenge(id: $id) {
      reject {
        id
      }
    }
  }
}
    `;
/**
 * __useRejectChallengeMutation__
 *
 * To run a mutation, you first call `useRejectChallengeMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useRejectChallengeMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [rejectChallengeMutation, { data, loading, error }] = useRejectChallengeMutation({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
function useRejectChallengeMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.RejectChallengeDocument, options);
}
exports.useRejectChallengeMutation = useRejectChallengeMutation;
exports.ApproveChallengeDocument = (0, client_1.gql) `
    mutation ApproveChallenge($id: Int!) {
  me {
    decryptionChallenge(id: $id) {
      approve {
        id
      }
    }
  }
}
    `;
/**
 * __useApproveChallengeMutation__
 *
 * To run a mutation, you first call `useApproveChallengeMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useApproveChallengeMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [approveChallengeMutation, { data, loading, error }] = useApproveChallengeMutation({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
function useApproveChallengeMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.ApproveChallengeDocument, options);
}
exports.useApproveChallengeMutation = useApproveChallengeMutation;
exports.DevicesRequestsDocument = (0, client_1.gql) `
    query DevicesRequests {
  me {
    id
    masterDeviceId
    decryptionChallengesWaiting {
      id
      createdAt
      deviceName
      deviceId
      ipAddress
      ipGeoLocation
    }
  }
}
    `;
/**
 * __useDevicesRequestsQuery__
 *
 * To run a query within a React component, call `useDevicesRequestsQuery` and pass it any options that fit your needs.
 * When your component renders, `useDevicesRequestsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useDevicesRequestsQuery({
 *   variables: {
 *   },
 * });
 */
function useDevicesRequestsQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.DevicesRequestsDocument, options);
}
exports.useDevicesRequestsQuery = useDevicesRequestsQuery;
function useDevicesRequestsLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.DevicesRequestsDocument, options);
}
exports.useDevicesRequestsLazyQuery = useDevicesRequestsLazyQuery;
exports.LogoutDeviceDocument = (0, client_1.gql) `
    mutation logoutDevice($id: String!) {
  me {
    device(id: $id) {
      logout {
        id
      }
    }
  }
}
    `;
/**
 * __useLogoutDeviceMutation__
 *
 * To run a mutation, you first call `useLogoutDeviceMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useLogoutDeviceMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [logoutDeviceMutation, { data, loading, error }] = useLogoutDeviceMutation({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
function useLogoutDeviceMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.LogoutDeviceDocument, options);
}
exports.useLogoutDeviceMutation = useLogoutDeviceMutation;
exports.RemoveDeviceDocument = (0, client_1.gql) `
    mutation removeDevice($id: String!) {
  me {
    device(id: $id) {
      removeDevice
    }
  }
}
    `;
/**
 * __useRemoveDeviceMutation__
 *
 * To run a mutation, you first call `useRemoveDeviceMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useRemoveDeviceMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [removeDeviceMutation, { data, loading, error }] = useRemoveDeviceMutation({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
function useRemoveDeviceMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.RemoveDeviceDocument, options);
}
exports.useRemoveDeviceMutation = useRemoveDeviceMutation;
exports.ChangeMasterDeviceDocument = (0, client_1.gql) `
    mutation ChangeMasterDevice($newMasterDeviceId: String!) {
  me {
    setMasterDevice(newMasterDeviceId: $newMasterDeviceId) {
      id
    }
  }
}
    `;
/**
 * __useChangeMasterDeviceMutation__
 *
 * To run a mutation, you first call `useChangeMasterDeviceMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useChangeMasterDeviceMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [changeMasterDeviceMutation, { data, loading, error }] = useChangeMasterDeviceMutation({
 *   variables: {
 *      newMasterDeviceId: // value for 'newMasterDeviceId'
 *   },
 * });
 */
function useChangeMasterDeviceMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.ChangeMasterDeviceDocument, options);
}
exports.useChangeMasterDeviceMutation = useChangeMasterDeviceMutation;


/***/ }),

/***/ 98533:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useUpdateEncryptedSecretMutation = exports.UpdateEncryptedSecretDocument = exports.useDeleteEncryptedSecretMutation = exports.DeleteEncryptedSecretDocument = exports.useEncryptedSecretsLazyQuery = exports.useEncryptedSecretsQuery = exports.EncryptedSecretsDocument = void 0;
const client_1 = __webpack_require__(91416);
const Apollo = __importStar(__webpack_require__(91416));
const defaultOptions = {};
exports.EncryptedSecretsDocument = (0, client_1.gql) `
    query encryptedSecrets {
  me {
    id
    encryptedSecrets {
      id
      kind
      encrypted
    }
  }
}
    `;
/**
 * __useEncryptedSecretsQuery__
 *
 * To run a query within a React component, call `useEncryptedSecretsQuery` and pass it any options that fit your needs.
 * When your component renders, `useEncryptedSecretsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useEncryptedSecretsQuery({
 *   variables: {
 *   },
 * });
 */
function useEncryptedSecretsQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.EncryptedSecretsDocument, options);
}
exports.useEncryptedSecretsQuery = useEncryptedSecretsQuery;
function useEncryptedSecretsLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.EncryptedSecretsDocument, options);
}
exports.useEncryptedSecretsLazyQuery = useEncryptedSecretsLazyQuery;
exports.DeleteEncryptedSecretDocument = (0, client_1.gql) `
    mutation deleteEncryptedSecret($id: ID!) {
  me {
    encryptedSecret(id: $id) {
      id
      delete {
        id
      }
    }
  }
}
    `;
/**
 * __useDeleteEncryptedSecretMutation__
 *
 * To run a mutation, you first call `useDeleteEncryptedSecretMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeleteEncryptedSecretMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deleteEncryptedSecretMutation, { data, loading, error }] = useDeleteEncryptedSecretMutation({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
function useDeleteEncryptedSecretMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.DeleteEncryptedSecretDocument, options);
}
exports.useDeleteEncryptedSecretMutation = useDeleteEncryptedSecretMutation;
exports.UpdateEncryptedSecretDocument = (0, client_1.gql) `
    mutation updateEncryptedSecret($id: ID!, $patch: EncryptedSecretInput!) {
  me {
    encryptedSecret(id: $id) {
      id
      update(patch: $patch) {
        id
      }
    }
  }
}
    `;
/**
 * __useUpdateEncryptedSecretMutation__
 *
 * To run a mutation, you first call `useUpdateEncryptedSecretMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateEncryptedSecretMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateEncryptedSecretMutation, { data, loading, error }] = useUpdateEncryptedSecretMutation({
 *   variables: {
 *      id: // value for 'id'
 *      patch: // value for 'patch'
 *   },
 * });
 */
function useUpdateEncryptedSecretMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.UpdateEncryptedSecretDocument, options);
}
exports.useUpdateEncryptedSecretMutation = useUpdateEncryptedSecretMutation;


/***/ }),

/***/ 79982:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useAddEncryptedSecretsMutation = exports.AddEncryptedSecretsDocument = exports.useSyncEncryptedSecretsLazyQuery = exports.useSyncEncryptedSecretsQuery = exports.SyncEncryptedSecretsDocument = exports.useMarkAsSyncedMutation = exports.MarkAsSyncedDocument = exports.useLogoutMutation = exports.LogoutDocument = exports.SecretExtensionFragmentDoc = void 0;
const client_1 = __webpack_require__(91416);
const Apollo = __importStar(__webpack_require__(91416));
const defaultOptions = {};
exports.SecretExtensionFragmentDoc = (0, client_1.gql) `
    fragment secretExtension on EncryptedSecretQuery {
  id
  encrypted
  kind
  createdAt
  updatedAt
  deletedAt
  version
}
    `;
exports.LogoutDocument = (0, client_1.gql) `
    mutation logout {
  currentDevice {
    logout {
      logoutAt
    }
  }
}
    `;
/**
 * __useLogoutMutation__
 *
 * To run a mutation, you first call `useLogoutMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useLogoutMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [logoutMutation, { data, loading, error }] = useLogoutMutation({
 *   variables: {
 *   },
 * });
 */
function useLogoutMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.LogoutDocument, options);
}
exports.useLogoutMutation = useLogoutMutation;
exports.MarkAsSyncedDocument = (0, client_1.gql) `
    mutation markAsSynced {
  currentDevice {
    markAsSynced
  }
}
    `;
/**
 * __useMarkAsSyncedMutation__
 *
 * To run a mutation, you first call `useMarkAsSyncedMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useMarkAsSyncedMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [markAsSyncedMutation, { data, loading, error }] = useMarkAsSyncedMutation({
 *   variables: {
 *   },
 * });
 */
function useMarkAsSyncedMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.MarkAsSyncedDocument, options);
}
exports.useMarkAsSyncedMutation = useMarkAsSyncedMutation;
exports.SyncEncryptedSecretsDocument = (0, client_1.gql) `
    query SyncEncryptedSecrets {
  currentDevice {
    id
    encryptedSecretsToSync {
      ...secretExtension
    }
  }
}
    ${exports.SecretExtensionFragmentDoc}`;
/**
 * __useSyncEncryptedSecretsQuery__
 *
 * To run a query within a React component, call `useSyncEncryptedSecretsQuery` and pass it any options that fit your needs.
 * When your component renders, `useSyncEncryptedSecretsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useSyncEncryptedSecretsQuery({
 *   variables: {
 *   },
 * });
 */
function useSyncEncryptedSecretsQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.SyncEncryptedSecretsDocument, options);
}
exports.useSyncEncryptedSecretsQuery = useSyncEncryptedSecretsQuery;
function useSyncEncryptedSecretsLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.SyncEncryptedSecretsDocument, options);
}
exports.useSyncEncryptedSecretsLazyQuery = useSyncEncryptedSecretsLazyQuery;
exports.AddEncryptedSecretsDocument = (0, client_1.gql) `
    mutation addEncryptedSecrets($secrets: [EncryptedSecretInput!]!) {
  me {
    addEncryptedSecrets(secrets: $secrets) {
      id
      kind
      encrypted
      version
      createdAt
      updatedAt
    }
  }
}
    `;
/**
 * __useAddEncryptedSecretsMutation__
 *
 * To run a mutation, you first call `useAddEncryptedSecretsMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAddEncryptedSecretsMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [addEncryptedSecretsMutation, { data, loading, error }] = useAddEncryptedSecretsMutation({
 *   variables: {
 *      secrets: // value for 'secrets'
 *   },
 * });
 */
function useAddEncryptedSecretsMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.AddEncryptedSecretsDocument, options);
}
exports.useAddEncryptedSecretsMutation = useAddEncryptedSecretsMutation;


/***/ }),

/***/ 81950:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useDeviceDecryptionChallengeMutation = exports.DeviceDecryptionChallengeDocument = exports.useAddNewDeviceForUserMutation = exports.AddNewDeviceForUserDocument = void 0;
const client_1 = __webpack_require__(91416);
const Apollo = __importStar(__webpack_require__(91416));
const defaultOptions = {};
exports.AddNewDeviceForUserDocument = (0, client_1.gql) `
    mutation addNewDeviceForUser($email: EmailAddress!, $deviceInput: DeviceInput!, $currentAddDeviceSecret: NonEmptyString!, $input: AddNewDeviceInput!) {
  deviceDecryptionChallenge(email: $email, deviceInput: $deviceInput) {
    ... on DecryptionChallengeApproved {
      id
      addNewDeviceForUser(
        currentAddDeviceSecret: $currentAddDeviceSecret
        input: $input
      ) {
        accessToken
        user {
          EncryptedSecrets {
            id
            encrypted
            kind
            createdAt
            updatedAt
            version
          }
        }
      }
    }
  }
}
    `;
/**
 * __useAddNewDeviceForUserMutation__
 *
 * To run a mutation, you first call `useAddNewDeviceForUserMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAddNewDeviceForUserMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [addNewDeviceForUserMutation, { data, loading, error }] = useAddNewDeviceForUserMutation({
 *   variables: {
 *      email: // value for 'email'
 *      deviceInput: // value for 'deviceInput'
 *      currentAddDeviceSecret: // value for 'currentAddDeviceSecret'
 *      input: // value for 'input'
 *   },
 * });
 */
function useAddNewDeviceForUserMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.AddNewDeviceForUserDocument, options);
}
exports.useAddNewDeviceForUserMutation = useAddNewDeviceForUserMutation;
exports.DeviceDecryptionChallengeDocument = (0, client_1.gql) `
    mutation deviceDecryptionChallenge($email: EmailAddress!, $deviceInput: DeviceInput!) {
  deviceDecryptionChallenge(email: $email, deviceInput: $deviceInput) {
    ... on DecryptionChallengeApproved {
      id
      addDeviceSecretEncrypted
      encryptionSalt
      userId
      approvedAt
      deviceId
      deviceName
    }
    ... on DecryptionChallengeForApproval {
      id
    }
  }
}
    `;
/**
 * __useDeviceDecryptionChallengeMutation__
 *
 * To run a mutation, you first call `useDeviceDecryptionChallengeMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeviceDecryptionChallengeMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deviceDecryptionChallengeMutation, { data, loading, error }] = useDeviceDecryptionChallengeMutation({
 *   variables: {
 *      email: // value for 'email'
 *      deviceInput: // value for 'deviceInput'
 *   },
 * });
 */
function useDeviceDecryptionChallengeMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.DeviceDecryptionChallengeDocument, options);
}
exports.useDeviceDecryptionChallengeMutation = useDeviceDecryptionChallengeMutation;


/***/ }),

/***/ 95403:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useUpdateSettingsMutation = exports.UpdateSettingsDocument = exports.useSyncSettingsLazyQuery = exports.useSyncSettingsQuery = exports.SyncSettingsDocument = void 0;
const client_1 = __webpack_require__(91416);
const Apollo = __importStar(__webpack_require__(91416));
const defaultOptions = {};
exports.SyncSettingsDocument = (0, client_1.gql) `
    query SyncSettings {
  me {
    PasswordLimits
    TOTPlimit
    id
    autofill
    language
    theme
  }
  currentDevice {
    id
    syncTOTP
    vaultLockTimeoutSeconds
  }
}
    `;
/**
 * __useSyncSettingsQuery__
 *
 * To run a query within a React component, call `useSyncSettingsQuery` and pass it any options that fit your needs.
 * When your component renders, `useSyncSettingsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useSyncSettingsQuery({
 *   variables: {
 *   },
 * });
 */
function useSyncSettingsQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.SyncSettingsDocument, options);
}
exports.useSyncSettingsQuery = useSyncSettingsQuery;
function useSyncSettingsLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.SyncSettingsDocument, options);
}
exports.useSyncSettingsLazyQuery = useSyncSettingsLazyQuery;
exports.UpdateSettingsDocument = (0, client_1.gql) `
    mutation updateSettings($config: SettingsInput!) {
  me {
    updateSettings(config: $config) {
      id
    }
  }
}
    `;
/**
 * __useUpdateSettingsMutation__
 *
 * To run a mutation, you first call `useUpdateSettingsMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateSettingsMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateSettingsMutation, { data, loading, error }] = useUpdateSettingsMutation({
 *   variables: {
 *      config: // value for 'config'
 *   },
 * });
 */
function useUpdateSettingsMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.UpdateSettingsDocument, options);
}
exports.useUpdateSettingsMutation = useUpdateSettingsMutation;


/***/ }),

/***/ 5970:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useRegisterNewUserMutation = exports.RegisterNewUserDocument = void 0;
const client_1 = __webpack_require__(91416);
const Apollo = __importStar(__webpack_require__(91416));
const defaultOptions = {};
exports.RegisterNewUserDocument = (0, client_1.gql) `
    mutation registerNewUser($input: RegisterNewAccountInput!, $userId: UUID!) {
  registerNewUser(input: $input, userId: $userId) {
    accessToken
    user {
      id
      sendEmailVerification
      Devices {
        id
        name
      }
    }
  }
}
    `;
/**
 * __useRegisterNewUserMutation__
 *
 * To run a mutation, you first call `useRegisterNewUserMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useRegisterNewUserMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [registerNewUserMutation, { data, loading, error }] = useRegisterNewUserMutation({
 *   variables: {
 *      input: // value for 'input'
 *      userId: // value for 'userId'
 *   },
 * });
 */
function useRegisterNewUserMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.RegisterNewUserDocument, options);
}
exports.useRegisterNewUserMutation = useRegisterNewUserMutation;


/***/ }),

/***/ 4147:
/***/ ((module) => {

module.exports = JSON.parse('{"name":"authier-web-extension","version":"1.0.0","description":"Authier web Extension for all our supported browsers","license":"AGPL-3.0-or-later","scripts":{"prodbuild":"webpack --config webpack.prod.js","devBuild":"webpack --config webpack.dev.js","checkBuildOutput":"node ./check-es6.js","dev":"webpack -w --config webpack.dev.js","tsc":"tsc","lingui:extract":"lingui extract","lingui:compile":"lingui compile","test":"echo","playwright:run":"npx playwright test","test2":"jest --config=jest.config.js","lint":"eslint --fix -c ../.eslintrc.js \\"src/**/*.ts*\\"","gen":"graphql-codegen","test:run":"cd .. && cd backend && pnpm dev","uploadApp":"dotenv chrome-webstore-upload upload --source dist.zip --extension-id $EXTENSION_ID --client-id $CLIENT_ID --client-secret $CLIENT_SECRET --refresh-token $REFRESH_TOKEN","publishApp":"dotenv chrome-webstore-upload publish --source dist.zip --extension-id padmmdghcflnaellmmckicifafoenfdi"},"keywords":["react","typescript","chrome","extension","boilerplate"],"devDependencies":{"@babel/core":"^7.20.12","@babel/preset-env":"^7.20.2","@babel/preset-react":"^7.18.6","@babel/preset-typescript":"^7.18.6","@lingui/core":"^3.15.0","@lingui/react":"^3.15.0","@playwright/test":"^1.29.2","@svgr/webpack":"^6.5.1","@types/chrome":"^0.0.208","@types/crypto-js":"^4.1.1","@types/debug":"^4.1.7","@types/mz":"^2.7.4","@types/papaparse":"^5.3.7","@types/react":"^18.0.26","@types/react-dom":"^18.0.10","@types/react-test-renderer":"^18.0.0","@types/webextension-polyfill":"^0.10.0","acorn":"^8.8.1","babel-core":"^6.26.3","babel-jest":"^28.1.3","babel-loader":"^8.3.0","babel-plugin-import-graphql":"^2.8.1","chrome-webstore-upload":"^1.0.0","chrome-webstore-upload-cli":"^2.1.0","css-loader":"^6.7.3","date-fns":"^2.29.3","debug":"^4.3.4","dotenv-webpack":"^8.0.1","firebase":"9.15.0","gqlSchemas":"file:../backend/schemas","js-file-download":"^0.4.12","jsdom":"^20.0.3","lodash":"^4.17.21","mem":"^9.0.2","mitt":"^3.0.0","mockzilla":"^0.14.0","mockzilla-webextension":"^0.15.0","ms":"^2.1.3","papaparse":"^5.3.2","pretty-quick":"^3.1.3","proxy-date":"^0.1.1","react-dropzone":"^14.2.3","react-toastify":"^9.1.1","sass-loader":"^13.2.0","slugify":"^1.6.5","style-loader":"^3.3.1","ts-jest":"^28.0.8","ts-loader":"^9.4.2","ts-node-dev":"^2.0.0","type-graphql":"^1.1.1","typescript":"^4.9.4","vitest":"^0.27.1","webpack":"^5.75.0","webpack-cli":"^4.10.0","webpack-extension-reloader":"^1.1.4","webpack-merge":"^5.8.0","zod":"^3.20.2"},"dependencies":{"@apollo/client":"^3.7.4","@apollo/react-hooks":"^4.0.0","@chakra-ui/color-mode":"^2.1.12","@chakra-ui/icons":"^2.0.17","@chakra-ui/react":"^2.4.8","@emotion/babel-plugin":"^11.10.5","@emotion/css":"^11.10.5","@emotion/styled":"11.10.5","@lingui/cli":"^3.15.0","@lingui/macro":"^3.15.0","@sentry/browser":"^7.30.0","@sentry/tracing":"^7.30.0","@trpc/client":"^10.9.0","@trpc/server":"^10.9.0","@types/offscreencanvas":"^2019.7.0","apollo-boost":"^0.4.9","apollo-link-serialize":"^4.0.0","apollo-link-token-refresh":"^0.4.0","babel-plugin-macros":"^3.1.0","base64-arraybuffer":"^1.0.2","bowser":"^2.11.0","buffer":"^6.0.3","check-password-strength":"^2.0.7","crypto-browserify":"^3.12.0","crypto-js":"^4.1.1","firefox-extension-deploy":"^1.1.2","formik":"^2.2.9","generate-password":"^1.7.0","graphql":"^16.6.0","jsqr":"^1.4.0","jwt-decode":"^3.1.2","nano-jsx":"^0.0.36","otplib":"^12.0.1","preact":"^10.11.3","query-string":"^7.1.3","react":"^18.2.0","react-device-detect":"^2.2.2","react-dom":"^18.2.0","react-icons":"^4.7.1","react-qr-code":"^2.0.11","react-router-dom":"^6.6.2","react-select":"^5.7.0","react-spring":"^9.6.1","react-test-renderer":"^18.2.0","react-transition-group":"^4.4.5","react-virtualized":"^9.22.3","reflect-metadata":"^0.1.13","stream-browserify":"^3.0.0","trpc-chrome":"^1.0.0","webextension-polyfill":"^0.10.0","wouter":"^2.9.1","yup":"^0.32.11"}}');

/***/ })

}]);