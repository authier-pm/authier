/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 88300:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


function getMessageFromUnknownError(err, fallback) {
    if (typeof err === 'string') {
        return err;
    }
    if (err instanceof Error && typeof err.message === 'string') {
        return err.message;
    }
    return fallback;
}
function getErrorFromUnknown(cause) {
    if (cause instanceof Error) {
        return cause;
    }
    const message = getMessageFromUnknownError(cause, 'Unknown error');
    return new Error(message);
}
function getTRPCErrorFromUnknown(cause) {
    const error = getErrorFromUnknown(cause);
    // this should ideally be an `instanceof TRPCError` but for some reason that isn't working
    // ref https://github.com/trpc/trpc/issues/331
    if (error.name === 'TRPCError') {
        return cause;
    }
    const trpcError = new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        cause: error,
        message: error.message
    });
    // Inherit stack from error
    trpcError.stack = error.stack;
    return trpcError;
}
function getCauseFromUnknown(cause) {
    if (cause instanceof Error) {
        return cause;
    }
    return undefined;
}

class TRPCError extends Error {
    constructor(opts){
        const code = opts.code;
        const message = opts.message ?? getMessageFromUnknownError(opts.cause, code);
        const cause = opts.cause !== undefined ? getErrorFromUnknown(opts.cause) : undefined;
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore https://github.com/tc39/proposal-error-cause
        super(message, {
            cause
        });
        this.code = code;
        this.cause = cause;
        this.name = 'TRPCError';
        Object.setPrototypeOf(this, new.target.prototype);
    }
}

exports.TRPCError = TRPCError;
exports.getCauseFromUnknown = getCauseFromUnknown;
exports.getTRPCErrorFromUnknown = getTRPCErrorFromUnknown;


/***/ }),

/***/ 76375:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


function invert(obj) {
    const newObj = Object.create(null);
    for(const key in obj){
        const v = obj[key];
        newObj[v] = key;
    }
    return newObj;
}

// reference: https://www.jsonrpc.org/specification
/**
 * JSON-RPC 2.0 Error codes
 *
 * `-32000` to `-32099` are reserved for implementation-defined server-errors.
 * For tRPC we're copying the last digits of HTTP 4XX errors.
 */ const TRPC_ERROR_CODES_BY_KEY = {
    /**
   * Invalid JSON was received by the server.
   * An error occurred on the server while parsing the JSON text.
   */ PARSE_ERROR: -32700,
    /**
   * The JSON sent is not a valid Request object.
   */ BAD_REQUEST: -32600,
    /**
   * Internal JSON-RPC error.
   */ INTERNAL_SERVER_ERROR: -32603,
    // Implementation specific errors
    UNAUTHORIZED: -32001,
    FORBIDDEN: -32003,
    NOT_FOUND: -32004,
    METHOD_NOT_SUPPORTED: -32005,
    TIMEOUT: -32008,
    CONFLICT: -32009,
    PRECONDITION_FAILED: -32012,
    PAYLOAD_TOO_LARGE: -32013,
    TOO_MANY_REQUESTS: -32029,
    CLIENT_CLOSED_REQUEST: -32099
};
const TRPC_ERROR_CODES_BY_NUMBER = invert(TRPC_ERROR_CODES_BY_KEY);

exports.TRPC_ERROR_CODES_BY_KEY = TRPC_ERROR_CODES_BY_KEY;
exports.TRPC_ERROR_CODES_BY_NUMBER = TRPC_ERROR_CODES_BY_NUMBER;
exports.invert = invert;


/***/ }),

/***/ 55275:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var TRPCError = __webpack_require__(88300);
var codes = __webpack_require__(76375);
var index = __webpack_require__(86495);

/**
 * @public
 */ /**
 * @internal
 */ function getDataTransformer(transformer) {
    if ('input' in transformer) {
        return transformer;
    }
    return {
        input: transformer,
        output: transformer
    };
}
/**
 * @internal
 */ const defaultTransformer = {
    _default: true,
    input: {
        serialize: (obj)=>obj,
        deserialize: (obj)=>obj
    },
    output: {
        serialize: (obj)=>obj,
        deserialize: (obj)=>obj
    }
};

const defaultFormatter = ({ shape  })=>{
    return shape;
};

const TRPC_ERROR_CODES_BY_NUMBER = codes.invert(codes.TRPC_ERROR_CODES_BY_KEY);
const JSONRPC2_TO_HTTP_CODE = {
    PARSE_ERROR: 400,
    BAD_REQUEST: 400,
    NOT_FOUND: 404,
    INTERNAL_SERVER_ERROR: 500,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    TIMEOUT: 408,
    CONFLICT: 409,
    CLIENT_CLOSED_REQUEST: 499,
    PRECONDITION_FAILED: 412,
    PAYLOAD_TOO_LARGE: 413,
    METHOD_NOT_SUPPORTED: 405,
    TOO_MANY_REQUESTS: 429
};
function getStatusCodeFromKey(code) {
    return JSONRPC2_TO_HTTP_CODE[code] ?? 500;
}
function getHTTPStatusCode(json) {
    const arr = Array.isArray(json) ? json : [
        json
    ];
    const httpStatuses = new Set(arr.map((res)=>{
        if ('error' in res) {
            const data = res.error.data;
            if (typeof data.httpStatus === 'number') {
                return data.httpStatus;
            }
            const code = TRPC_ERROR_CODES_BY_NUMBER[res.error.code];
            return getStatusCodeFromKey(code);
        }
        return 200;
    }));
    if (httpStatuses.size !== 1) {
        return 207;
    }
    const httpStatus = httpStatuses.values().next().value;
    return httpStatus;
}
function getHTTPStatusCodeFromError(error) {
    const { code  } = error;
    return getStatusCodeFromKey(code);
}

/**
 * Create an object without inheriting anything from `Object.prototype`
 * @internal
 */ function omitPrototype(obj) {
    return Object.assign(Object.create(null), obj);
}

const procedureTypes = [
    'query',
    'mutation',
    'subscription'
];

function isRouter(procedureOrRouter) {
    return 'router' in procedureOrRouter._def;
}
const emptyRouter = {
    _ctx: null,
    _errorShape: null,
    _meta: null,
    queries: {},
    mutations: {},
    subscriptions: {},
    errorFormatter: defaultFormatter,
    transformer: defaultTransformer
};
/**
 * Reserved words that can't be used as router or procedure names
 */ const reservedWords = [
    /**
   * Then is a reserved word because otherwise we can't return a promise that returns a Proxy
   * since JS will think that `.then` is something that exists
   */ 'then'
];
/**
 * @internal
 */ function createRouterFactory(config) {
    return function createRouterInner(procedures) {
        const reservedWordsUsed = new Set(Object.keys(procedures).filter((v)=>reservedWords.includes(v)));
        if (reservedWordsUsed.size > 0) {
            throw new Error('Reserved words used in `router({})` call: ' + Array.from(reservedWordsUsed).join(', '));
        }
        const routerProcedures = omitPrototype({});
        function recursiveGetPaths(procedures, path = '') {
            for (const [key, procedureOrRouter] of Object.entries(procedures ?? {})){
                const newPath = `${path}${key}`;
                if (isRouter(procedureOrRouter)) {
                    recursiveGetPaths(procedureOrRouter._def.procedures, `${newPath}.`);
                    continue;
                }
                if (routerProcedures[newPath]) {
                    throw new Error(`Duplicate key: ${newPath}`);
                }
                routerProcedures[newPath] = procedureOrRouter;
            }
        }
        recursiveGetPaths(procedures);
        const _def = {
            _config: config,
            router: true,
            procedures: routerProcedures,
            ...emptyRouter,
            record: procedures,
            queries: Object.entries(routerProcedures).filter((pair)=>pair[1]._def.query).reduce((acc, [key, val])=>({
                    ...acc,
                    [key]: val
                }), {}),
            mutations: Object.entries(routerProcedures).filter((pair)=>pair[1]._def.mutation).reduce((acc, [key, val])=>({
                    ...acc,
                    [key]: val
                }), {}),
            subscriptions: Object.entries(routerProcedures).filter((pair)=>pair[1]._def.subscription).reduce((acc, [key, val])=>({
                    ...acc,
                    [key]: val
                }), {})
        };
        const router = {
            ...procedures,
            _def,
            createCaller (ctx) {
                const proxy = index.createRecursiveProxy(({ path , args  })=>{
                    // interop mode
                    if (path.length === 1 && procedureTypes.includes(path[0])) {
                        return callProcedure({
                            procedures: _def.procedures,
                            path: args[0],
                            rawInput: args[1],
                            ctx,
                            type: path[0]
                        });
                    }
                    const fullPath = path.join('.');
                    const procedure = _def.procedures[fullPath];
                    let type = 'query';
                    if (procedure._def.mutation) {
                        type = 'mutation';
                    } else if (procedure._def.subscription) {
                        type = 'subscription';
                    }
                    return procedure({
                        path: fullPath,
                        rawInput: args[0],
                        ctx,
                        type
                    });
                });
                return proxy;
            },
            getErrorShape (opts) {
                const { path , error  } = opts;
                const { code  } = opts.error;
                const shape = {
                    message: error.message,
                    code: codes.TRPC_ERROR_CODES_BY_KEY[code],
                    data: {
                        code,
                        httpStatus: getHTTPStatusCodeFromError(error)
                    }
                };
                if (config.isDev && typeof opts.error.stack === 'string') {
                    shape.data.stack = opts.error.stack;
                }
                if (typeof path === 'string') {
                    shape.data.path = path;
                }
                return this._def._config.errorFormatter({
                    ...opts,
                    shape
                });
            }
        };
        return router;
    };
}
/**
 * @internal
 */ function callProcedure(opts) {
    const { type , path  } = opts;
    if (!(path in opts.procedures) || !opts.procedures[path]?._def[type]) {
        throw new TRPCError.TRPCError({
            code: 'NOT_FOUND',
            message: `No "${type}"-procedure on path "${path}"`
        });
    }
    const procedure = opts.procedures[path];
    return procedure(opts);
}

/**
 * The default check to see if we're in a server
 */ const isServerDefault = typeof window === 'undefined' || 'Deno' in window || globalThis.process?.env?.NODE_ENV === 'test' || !!globalThis.process?.env?.JEST_WORKER_ID;

exports.TRPC_ERROR_CODES_BY_NUMBER = TRPC_ERROR_CODES_BY_NUMBER;
exports.callProcedure = callProcedure;
exports.createRouterFactory = createRouterFactory;
exports.defaultFormatter = defaultFormatter;
exports.defaultTransformer = defaultTransformer;
exports.getDataTransformer = getDataTransformer;
exports.getHTTPStatusCode = getHTTPStatusCode;
exports.getHTTPStatusCodeFromError = getHTTPStatusCodeFromError;
exports.isServerDefault = isServerDefault;
exports.procedureTypes = procedureTypes;


/***/ }),

/***/ 63539:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({ value: true }));

var config = __webpack_require__(55275);
var TRPCError = __webpack_require__(88300);
var codes = __webpack_require__(76375);
var index = __webpack_require__(86495);

/**
 * @deprecated
 */ const middlewareMarker$1 = 'middlewareMarker';

function getParseFn$1(procedureParser) {
    const parser = procedureParser;
    if (typeof parser === 'function') {
        // ProcedureParserCustomValidatorEsque
        return parser;
    }
    if (typeof parser.parseAsync === 'function') {
        // ProcedureParserZodEsque
        return parser.parseAsync.bind(parser);
    }
    if (typeof parser.parse === 'function') {
        // ProcedureParserZodEsque
        return parser.parse.bind(parser);
    }
    if (typeof parser.validateSync === 'function') {
        // ProcedureParserYupEsque
        return parser.validateSync.bind(parser);
    }
    if (typeof parser.create === 'function') {
        // ProcedureParserSuperstructEsque
        return parser.create.bind(parser);
    }
    throw new Error('Could not find a validator fn');
}
/**
 * @internal
 * @deprecated
 */ class Procedure {
    _def() {
        return {
            middlewares: this.middlewares,
            resolver: this.resolver,
            inputParser: this.inputParser,
            outputParser: this.outputParser,
            meta: this.meta
        };
    }
    async parseInput(rawInput) {
        try {
            return await this.parseInputFn(rawInput);
        } catch (cause) {
            throw new TRPCError.TRPCError({
                code: 'BAD_REQUEST',
                cause: TRPCError.getCauseFromUnknown(cause)
            });
        }
    }
    async parseOutput(rawOutput) {
        try {
            return await this.parseOutputFn(rawOutput);
        } catch (cause) {
            throw new TRPCError.TRPCError({
                code: 'INTERNAL_SERVER_ERROR',
                cause: TRPCError.getCauseFromUnknown(cause),
                message: 'Output validation failed'
            });
        }
    }
    /**
   * Trigger middlewares in order, parse raw input, call resolver & parse raw output
   * @internal
   */ async call(opts) {
        // wrap the actual resolver and treat as the last "middleware"
        const middlewaresWithResolver = this.middlewares.concat([
            async ({ ctx  })=>{
                const input = await this.parseInput(opts.rawInput);
                const rawOutput = await this.resolver({
                    ...opts,
                    ctx,
                    input
                });
                const data = await this.parseOutput(rawOutput);
                return {
                    marker: middlewareMarker$1,
                    ok: true,
                    data,
                    ctx
                };
            }
        ]);
        // run the middlewares recursively with the resolver as the last one
        const callRecursive = async (callOpts = {
            index: 0,
            ctx: opts.ctx
        })=>{
            try {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                const result = await middlewaresWithResolver[callOpts.index]({
                    ctx: callOpts.ctx,
                    type: opts.type,
                    path: opts.path,
                    rawInput: opts.rawInput,
                    meta: this.meta,
                    next: async (nextOpts)=>{
                        return await callRecursive({
                            index: callOpts.index + 1,
                            ctx: nextOpts ? nextOpts.ctx : callOpts.ctx
                        });
                    }
                });
                return result;
            } catch (cause) {
                return {
                    ctx: callOpts.ctx,
                    ok: false,
                    error: TRPCError.getTRPCErrorFromUnknown(cause),
                    marker: middlewareMarker$1
                };
            }
        };
        // there's always at least one "next" since we wrap this.resolver in a middleware
        const result = await callRecursive();
        if (!result) {
            throw new TRPCError.TRPCError({
                code: 'INTERNAL_SERVER_ERROR',
                message: 'No result from middlewares - did you forget to `return next()`?'
            });
        }
        if (!result.ok) {
            // re-throw original error
            throw result.error;
        }
        return result.data;
    }
    /**
   * Create new procedure with passed middlewares
   * @param middlewares
   */ inheritMiddlewares(middlewares) {
        const Constructor = this.constructor;
        const instance = new Constructor({
            middlewares: [
                ...middlewares,
                ...this.middlewares
            ],
            resolver: this.resolver,
            inputParser: this.inputParser,
            outputParser: this.outputParser,
            meta: this.meta
        });
        return instance;
    }
    constructor(opts){
        this.middlewares = opts.middlewares;
        this.resolver = opts.resolver;
        this.inputParser = opts.inputParser;
        this.parseInputFn = getParseFn$1(this.inputParser);
        this.outputParser = opts.outputParser;
        this.parseOutputFn = getParseFn$1(this.outputParser);
        this.meta = opts.meta;
    }
}
function createProcedure(opts) {
    const inputParser = 'input' in opts ? opts.input : (input)=>{
        if (input != null) {
            throw new TRPCError.TRPCError({
                code: 'BAD_REQUEST',
                message: 'No input expected'
            });
        }
        return undefined;
    };
    const outputParser = 'output' in opts && opts.output ? opts.output : (output)=>output;
    return new Procedure({
        inputParser: inputParser,
        resolver: opts.resolve,
        middlewares: [],
        outputParser: outputParser,
        meta: opts.meta
    });
}

function getParseFn(procedureParser) {
    const parser = procedureParser;
    if (typeof parser === 'function') {
        // ProcedureParserCustomValidatorEsque
        return parser;
    }
    if (typeof parser.parseAsync === 'function') {
        // ProcedureParserZodEsque
        return parser.parseAsync.bind(parser);
    }
    if (typeof parser.parse === 'function') {
        // ProcedureParserZodEsque
        return parser.parse.bind(parser);
    }
    if (typeof parser.validateSync === 'function') {
        // ProcedureParserYupEsque
        return parser.validateSync.bind(parser);
    }
    if (typeof parser.create === 'function') {
        // ProcedureParserSuperstructEsque
        return parser.create.bind(parser);
    }
    throw new Error('Could not find a validator fn');
}
/**
 * @deprecated only for backwards compat
 * @internal
 */ function getParseFnOrPassThrough(procedureParser) {
    if (!procedureParser) {
        return (v)=>v;
    }
    return getParseFn(procedureParser);
}

/**
 * Ensures there are no duplicate keys when building a procedure.
 */ function mergeWithoutOverrides(obj1, ...objs) {
    const newObj = Object.assign(Object.create(null), obj1);
    for (const overrides of objs){
        for(const key in overrides){
            if (key in newObj && newObj[key] !== overrides[key]) {
                throw new Error(`Duplicate key ${key}`);
            }
            newObj[key] = overrides[key];
        }
    }
    return newObj;
}

/**
 * @internal
 */ // FIXME this should use RootConfig
function createMiddlewareFactory() {
    return function createMiddleware(fn) {
        return fn;
    };
}
function isPlainObject(obj) {
    return obj && typeof obj === 'object' && !Array.isArray(obj);
}
/**
 * @internal
 * Please note, `trpc-openapi` uses this function.
 */ function createInputMiddleware(parse) {
    const inputMiddleware = async ({ next , rawInput , input  })=>{
        let parsedInput;
        try {
            parsedInput = await parse(rawInput);
        } catch (cause) {
            throw new TRPCError.TRPCError({
                code: 'BAD_REQUEST',
                cause: TRPCError.getCauseFromUnknown(cause)
            });
        }
        // Multiple input parsers
        const combinedInput = isPlainObject(input) && isPlainObject(parsedInput) ? {
            ...input,
            ...parsedInput
        } : parsedInput;
        // TODO fix this typing?
        return next({
            input: combinedInput
        });
    };
    inputMiddleware._type = 'input';
    return inputMiddleware;
}
/**
 * @internal
 */ function createOutputMiddleware(parse) {
    const outputMiddleware = async ({ next  })=>{
        const result = await next();
        if (!result.ok) {
            // pass through failures without validating
            return result;
        }
        try {
            const data = await parse(result.data);
            return {
                ...result,
                data
            };
        } catch (cause) {
            throw new TRPCError.TRPCError({
                message: 'Output validation failed',
                code: 'INTERNAL_SERVER_ERROR',
                cause: TRPCError.getCauseFromUnknown(cause)
            });
        }
    };
    outputMiddleware._type = 'output';
    return outputMiddleware;
}

/**
 * @internal
 */ const middlewareMarker = 'middlewareMarker';

function createNewBuilder(def1, def2) {
    const { middlewares =[] , inputs , ...rest } = def2;
    // TODO: maybe have a fn here to warn about calls
    return createBuilder({
        ...mergeWithoutOverrides(def1, rest),
        inputs: [
            ...def1.inputs,
            ...inputs ?? []
        ],
        middlewares: [
            ...def1.middlewares,
            ...middlewares
        ]
    });
}
function createBuilder(initDef) {
    const _def = initDef || {
        inputs: [],
        middlewares: []
    };
    return {
        _def,
        input (input) {
            const parser = getParseFn(input);
            return createNewBuilder(_def, {
                inputs: [
                    input
                ],
                middlewares: [
                    createInputMiddleware(parser)
                ]
            });
        },
        output (output) {
            const parseOutput = getParseFn(output);
            return createNewBuilder(_def, {
                output,
                middlewares: [
                    createOutputMiddleware(parseOutput)
                ]
            });
        },
        meta (meta) {
            return createNewBuilder(_def, {
                meta: meta
            });
        },
        unstable_concat (builder) {
            return createNewBuilder(_def, builder._def);
        },
        use (middleware) {
            return createNewBuilder(_def, {
                middlewares: [
                    middleware
                ]
            });
        },
        query (resolver) {
            return createResolver({
                ..._def,
                query: true
            }, resolver);
        },
        mutation (resolver) {
            return createResolver({
                ..._def,
                mutation: true
            }, resolver);
        },
        subscription (resolver) {
            return createResolver({
                ..._def,
                subscription: true
            }, resolver);
        }
    };
}
function createResolver(_def, resolver) {
    const finalBuilder = createNewBuilder(_def, {
        resolver,
        middlewares: [
            async function resolveMiddleware(opts) {
                const data = await resolver(opts);
                return {
                    marker: middlewareMarker,
                    ok: true,
                    data,
                    ctx: opts.ctx
                };
            }
        ]
    });
    return createProcedureCaller(finalBuilder._def);
}
const codeblock = `
If you want to call this function on the server, you do the following:
This is a client-only function.

const caller = appRouter.createCaller({
  /* ... your context */
});

const result = await caller.call('myProcedure', input);
`.trim();
function createProcedureCaller(_def) {
    const procedure = async function resolve(opts) {
        // is direct server-side call
        if (!opts || !('rawInput' in opts)) {
            throw new Error(codeblock);
        }
        // run the middlewares recursively with the resolver as the last one
        const callRecursive = async (callOpts = {
            index: 0,
            ctx: opts.ctx
        })=>{
            try {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                const middleware = _def.middlewares[callOpts.index];
                const result = await middleware({
                    ctx: callOpts.ctx,
                    type: opts.type,
                    path: opts.path,
                    rawInput: opts.rawInput,
                    meta: _def.meta,
                    input: callOpts.input,
                    next: async (nextOpts)=>{
                        return await callRecursive({
                            index: callOpts.index + 1,
                            ctx: nextOpts && 'ctx' in nextOpts ? {
                                ...callOpts.ctx,
                                ...nextOpts.ctx
                            } : callOpts.ctx,
                            input: nextOpts && 'input' in nextOpts ? nextOpts.input : callOpts.input
                        });
                    }
                });
                return result;
            } catch (cause) {
                return {
                    ok: false,
                    error: TRPCError.getTRPCErrorFromUnknown(cause),
                    marker: middlewareMarker
                };
            }
        };
        // there's always at least one "next" since we wrap this.resolver in a middleware
        const result = await callRecursive();
        if (!result) {
            throw new TRPCError.TRPCError({
                code: 'INTERNAL_SERVER_ERROR',
                message: 'No result from middlewares - did you forget to `return next()`?'
            });
        }
        if (!result.ok) {
            // re-throw original error
            throw result.error;
        }
        return result.data;
    };
    procedure._def = _def;
    procedure.meta = _def.meta;
    return procedure;
}

function migrateProcedure(oldProc, type) {
    const def = oldProc._def();
    const inputParser = getParseFnOrPassThrough(def.inputParser);
    const outputParser = getParseFnOrPassThrough(def.outputParser);
    const inputMiddleware = createInputMiddleware(inputParser);
    const builder = createBuilder({
        inputs: [
            def.inputParser
        ],
        middlewares: [
            ...def.middlewares,
            inputMiddleware,
            createOutputMiddleware(outputParser)
        ],
        meta: def.meta,
        output: def.outputParser,
        mutation: type === 'mutation',
        query: type === 'query',
        subscription: type === 'subscription'
    });
    const proc = builder[type]((opts)=>def.resolver(opts));
    return proc;
}
function migrateRouter(oldRouter) {
    const errorFormatter = oldRouter._def.errorFormatter;
    const transformer = oldRouter._def.transformer;
    const queries = {};
    const mutations = {};
    const subscriptions = {};
    for (const [name, procedure] of Object.entries(oldRouter._def.queries)){
        queries[name] = migrateProcedure(procedure, 'query');
    }
    for (const [name1, procedure1] of Object.entries(oldRouter._def.mutations)){
        mutations[name1] = migrateProcedure(procedure1, 'mutation');
    }
    for (const [name2, procedure2] of Object.entries(oldRouter._def.subscriptions)){
        subscriptions[name2] = migrateProcedure(procedure2, 'subscription');
    }
    const procedures = mergeWithoutOverrides(queries, mutations, subscriptions);
    const newRouter = config.createRouterFactory({
        transformer,
        errorFormatter,
        isDev: "production" !== 'production'
    })(procedures);
    return newRouter;
}

function getDataTransformer(transformer) {
    if ('input' in transformer) {
        return transformer;
    }
    return {
        input: transformer,
        output: transformer
    };
}
const PROCEDURE_DEFINITION_MAP = {
    query: 'queries',
    mutation: 'mutations',
    subscription: 'subscriptions'
};
function safeObject(...args) {
    return Object.assign(Object.create(null), ...args);
}
/**
 * @internal The type signature of this class may change without warning.
 * @deprecated
 */ class Router {
    static prefixProcedures(procedures, prefix) {
        const eps = safeObject();
        for (const [key, procedure] of Object.entries(procedures)){
            eps[prefix + key] = procedure;
        }
        return eps;
    }
    query(path, procedure) {
        const router = new Router({
            queries: safeObject({
                [path]: createProcedure(procedure)
            })
        });
        return this.merge(router);
    }
    mutation(path, procedure) {
        const router = new Router({
            mutations: safeObject({
                [path]: createProcedure(procedure)
            })
        });
        return this.merge(router);
    }
    subscription(path, procedure) {
        const router = new Router({
            subscriptions: safeObject({
                [path]: createProcedure(procedure)
            })
        });
        return this.merge(router);
    }
    merge(prefixOrRouter, maybeRouter) {
        let prefix = '';
        let childRouter;
        if (typeof prefixOrRouter === 'string' && maybeRouter instanceof Router) {
            prefix = prefixOrRouter;
            childRouter = maybeRouter;
        } else if (prefixOrRouter instanceof Router) {
            childRouter = prefixOrRouter;
        } else {
            throw new Error('Invalid args');
        }
        const duplicateQueries = Object.keys(childRouter._def.queries).filter((key)=>!!this._def['queries'][prefix + key]);
        const duplicateMutations = Object.keys(childRouter._def.mutations).filter((key)=>!!this._def['mutations'][prefix + key]);
        const duplicateSubscriptions = Object.keys(childRouter._def.subscriptions).filter((key)=>!!this._def['subscriptions'][prefix + key]);
        const duplicates = [
            ...duplicateQueries,
            ...duplicateMutations,
            ...duplicateSubscriptions
        ];
        if (duplicates.length) {
            throw new Error(`Duplicate endpoint(s): ${duplicates.join(', ')}`);
        }
        const mergeProcedures = (defs)=>{
            const newDefs = safeObject();
            for (const [key, procedure] of Object.entries(defs)){
                const newProcedure = procedure.inheritMiddlewares(this._def.middlewares);
                newDefs[key] = newProcedure;
            }
            return Router.prefixProcedures(newDefs, prefix);
        };
        return new Router({
            ...this._def,
            queries: safeObject(this._def.queries, mergeProcedures(childRouter._def.queries)),
            mutations: safeObject(this._def.mutations, mergeProcedures(childRouter._def.mutations)),
            subscriptions: safeObject(this._def.subscriptions, mergeProcedures(childRouter._def.subscriptions))
        });
    }
    /**
   * Invoke procedure. Only for internal use within library.
   */ async call(opts) {
        const { type , path  } = opts;
        const defTarget = PROCEDURE_DEFINITION_MAP[type];
        const defs = this._def[defTarget];
        const procedure = defs[path];
        if (!procedure) {
            throw new TRPCError.TRPCError({
                code: 'NOT_FOUND',
                message: `No "${type}"-procedure on path "${path}"`
            });
        }
        return procedure.call(opts);
    }
    createCaller(ctx) {
        return {
            query: (path, ...args)=>{
                return this.call({
                    type: 'query',
                    ctx,
                    path,
                    rawInput: args[0]
                });
            },
            mutation: (path, ...args)=>{
                return this.call({
                    type: 'mutation',
                    ctx,
                    path,
                    rawInput: args[0]
                });
            },
            subscription: (path, ...args)=>{
                return this.call({
                    type: 'subscription',
                    ctx,
                    path,
                    rawInput: args[0]
                });
            }
        };
    }
    /**
   * Function to be called before any procedure is invoked
   * @link https://trpc.io/docs/middlewares
   */ middleware(middleware) {
        return new Router({
            ...this._def,
            middlewares: [
                ...this._def.middlewares,
                middleware
            ]
        });
    }
    /**
   * Format errors
   * @link https://trpc.io/docs/error-formatting
   */ formatError(errorFormatter) {
        if (this._def.errorFormatter !== config.defaultFormatter) {
            throw new Error('You seem to have double `formatError()`-calls in your router tree');
        }
        return new Router({
            ...this._def,
            errorFormatter: errorFormatter
        });
    }
    getErrorShape(opts) {
        const { path , error  } = opts;
        const { code  } = opts.error;
        const shape = {
            message: error.message,
            code: codes.TRPC_ERROR_CODES_BY_KEY[code],
            data: {
                code,
                httpStatus: config.getHTTPStatusCodeFromError(error)
            }
        };
        if (globalThis.process?.env?.NODE_ENV !== 'production' && typeof opts.error.stack === 'string') {
            shape.data.stack = opts.error.stack;
        }
        if (typeof path === 'string') {
            shape.data.path = path;
        }
        return this._def.errorFormatter({
            ...opts,
            shape
        });
    }
    /**
   * Add data transformer to serialize/deserialize input args + output
   * @link https://trpc.io/docs/data-transformers
   */ transformer(_transformer) {
        const transformer = getDataTransformer(_transformer);
        if (this._def.transformer !== config.defaultTransformer) {
            throw new Error('You seem to have double `transformer()`-calls in your router tree');
        }
        return new Router({
            ...this._def,
            transformer
        });
    }
    /**
   * Flattens the generics of TQueries/TMutations/TSubscriptions.
   * ⚠️ Experimental - might disappear. ⚠️
   *
   * @alpha
   */ flat() {
        return this;
    }
    /**
   * Interop mode for v9.x -> v10.x
   */ interop() {
        return migrateRouter(this);
    }
    constructor(def){
        this._def = {
            queries: def?.queries ?? safeObject(),
            mutations: def?.mutations ?? safeObject(),
            subscriptions: def?.subscriptions ?? safeObject(),
            middlewares: def?.middlewares ?? [],
            errorFormatter: def?.errorFormatter ?? config.defaultFormatter,
            transformer: def?.transformer ?? config.defaultTransformer
        };
    }
}
/**
 * @deprecated
 */ function router() {
    return new Router();
}

// ts-prune-ignore-next -- Used in generated code
function mergeRouters(...routerList) {
    const record = mergeWithoutOverrides({}, ...routerList.map((r)=>r._def.record));
    const errorFormatter = routerList.reduce((currentErrorFormatter, nextRouter)=>{
        if (nextRouter._def._config.errorFormatter && nextRouter._def._config.errorFormatter !== config.defaultFormatter) {
            if (currentErrorFormatter !== config.defaultFormatter && currentErrorFormatter !== nextRouter._def._config.errorFormatter) {
                throw new Error('You seem to have several error formatters');
            }
            return nextRouter._def._config.errorFormatter;
        }
        return currentErrorFormatter;
    }, config.defaultFormatter);
    const transformer = routerList.reduce((prev, current)=>{
        if (current._def._config.transformer && current._def._config.transformer !== config.defaultTransformer) {
            if (prev !== config.defaultTransformer && prev !== current._def._config.transformer) {
                throw new Error('You seem to have several transformers');
            }
            return current._def._config.transformer;
        }
        return prev;
    }, config.defaultTransformer);
    const router = config.createRouterFactory({
        errorFormatter,
        transformer,
        isDev: routerList.some((r)=>r._def._config.isDev),
        allowOutsideOfServer: routerList.some((r)=>r._def._config.allowOutsideOfServer),
        isServer: routerList.some((r)=>r._def._config.isServer),
        $types: routerList[0]?._def._config.$types
    })(record);
    return router;
}

function mergeRoutersGeneric(...args) {
    return mergeRouters(...args);
}

/**
 * TODO: This can be improved:
 * - We should be able to chain `.meta()`/`.context()` only once
 * - Simplify typings
 * - Doesn't need to be a class but it doesn't really hurt either
 */ class TRPCBuilder {
    context() {
        return new TRPCBuilder();
    }
    meta() {
        return new TRPCBuilder();
    }
    create(options) {
        return createTRPCInner()(options);
    }
}
/**
 * Initialize tRPC - be done exactly once per backend
 */ const initTRPC = new TRPCBuilder();
function createTRPCInner() {
    return function initTRPCInner(runtime) {
        const errorFormatter = runtime?.errorFormatter ?? config.defaultFormatter;
        const transformer = config.getDataTransformer(runtime?.transformer ?? config.defaultTransformer);
        const config$1 = {
            transformer,
            isDev: runtime?.isDev ?? globalThis.process?.env?.NODE_ENV !== 'production',
            allowOutsideOfServer: runtime?.allowOutsideOfServer ?? false,
            errorFormatter,
            isServer: runtime?.isServer ?? config.isServerDefault,
            /**
       * @internal
       */ $types: index.createFlatProxy((key)=>{
                throw new Error(`Tried to access "$types.${key}" which is not available at runtime`);
            })
        };
        {
            // Server check
            const isServer = runtime?.isServer ?? config.isServerDefault;
            if (!isServer && runtime?.allowOutsideOfServer !== true) {
                throw new Error(`You're trying to use @trpc/server in a non-server environment. This is not supported by default.`);
            }
        }
        return {
            /**
       * These are just types, they can't be used
       * @internal
       */ _config: config$1,
            /**
       * Builder object for creating procedures
       */ procedure: createBuilder(),
            /**
       * Create reusable middlewares
       */ middleware: createMiddlewareFactory(),
            /**
       * Create a router
       */ router: config.createRouterFactory(config$1),
            /**
       * Merge Routers
       */ mergeRouters: mergeRoutersGeneric
        };
    };
}

exports.callProcedure = config.callProcedure;
exports.defaultTransformer = config.defaultTransformer;
exports.getDataTransformer = config.getDataTransformer;
exports.procedureTypes = config.procedureTypes;
exports.TRPCError = TRPCError.TRPCError;
exports.createInputMiddleware = createInputMiddleware;
exports.createOutputMiddleware = createOutputMiddleware;
exports.initTRPC = initTRPC;
exports.router = router;


/***/ }),

/***/ 21494:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const p_defer_1 = __importDefault(__webpack_require__(36313));
function mapAgeCleaner(map, property = 'maxAge') {
    let processingKey;
    let processingTimer;
    let processingDeferred;
    const cleanup = () => __awaiter(this, void 0, void 0, function* () {
        if (processingKey !== undefined) {
            // If we are already processing an item, we can safely exit
            return;
        }
        const setupTimer = (item) => __awaiter(this, void 0, void 0, function* () {
            processingDeferred = p_defer_1.default();
            const delay = item[1][property] - Date.now();
            if (delay <= 0) {
                // Remove the item immediately if the delay is equal to or below 0
                map.delete(item[0]);
                processingDeferred.resolve();
                return;
            }
            // Keep track of the current processed key
            processingKey = item[0];
            processingTimer = setTimeout(() => {
                // Remove the item when the timeout fires
                map.delete(item[0]);
                if (processingDeferred) {
                    processingDeferred.resolve();
                }
            }, delay);
            // tslint:disable-next-line:strict-type-predicates
            if (typeof processingTimer.unref === 'function') {
                // Don't hold up the process from exiting
                processingTimer.unref();
            }
            return processingDeferred.promise;
        });
        try {
            for (const entry of map) {
                yield setupTimer(entry);
            }
        }
        catch (_a) {
            // Do nothing if an error occurs, this means the timer was cleaned up and we should stop processing
        }
        processingKey = undefined;
    });
    const reset = () => {
        processingKey = undefined;
        if (processingTimer !== undefined) {
            clearTimeout(processingTimer);
            processingTimer = undefined;
        }
        if (processingDeferred !== undefined) { // tslint:disable-line:early-exit
            processingDeferred.reject(undefined);
            processingDeferred = undefined;
        }
    };
    const originalSet = map.set.bind(map);
    map.set = (key, value) => {
        if (map.has(key)) {
            // If the key already exist, remove it so we can add it back at the end of the map.
            map.delete(key);
        }
        // Call the original `map.set`
        const result = originalSet(key, value);
        // If we are already processing a key and the key added is the current processed key, stop processing it
        if (processingKey && processingKey === key) {
            reset();
        }
        // Always run the cleanup method in case it wasn't started yet
        cleanup(); // tslint:disable-line:no-floating-promises
        return result;
    };
    cleanup(); // tslint:disable-line:no-floating-promises
    return map;
}
exports["default"] = mapAgeCleaner;
// Add support for CJS
module.exports = mapAgeCleaner;
module.exports["default"] = mapAgeCleaner;


/***/ }),

/***/ 48628:
/***/ ((module) => {

/**
 * Helpers.
 */

var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var w = d * 7;
var y = d * 365.25;

/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} [options]
 * @throws {Error} throw an error if val is not a non-empty string or a number
 * @return {String|Number}
 * @api public
 */

module.exports = function (val, options) {
  options = options || {};
  var type = typeof val;
  if (type === 'string' && val.length > 0) {
    return parse(val);
  } else if (type === 'number' && isFinite(val)) {
    return options.long ? fmtLong(val) : fmtShort(val);
  }
  throw new Error(
    'val is not a non-empty string or a valid number. val=' +
      JSON.stringify(val)
  );
};

/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */

function parse(str) {
  str = String(str);
  if (str.length > 100) {
    return;
  }
  var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
    str
  );
  if (!match) {
    return;
  }
  var n = parseFloat(match[1]);
  var type = (match[2] || 'ms').toLowerCase();
  switch (type) {
    case 'years':
    case 'year':
    case 'yrs':
    case 'yr':
    case 'y':
      return n * y;
    case 'weeks':
    case 'week':
    case 'w':
      return n * w;
    case 'days':
    case 'day':
    case 'd':
      return n * d;
    case 'hours':
    case 'hour':
    case 'hrs':
    case 'hr':
    case 'h':
      return n * h;
    case 'minutes':
    case 'minute':
    case 'mins':
    case 'min':
    case 'm':
      return n * m;
    case 'seconds':
    case 'second':
    case 'secs':
    case 'sec':
    case 's':
      return n * s;
    case 'milliseconds':
    case 'millisecond':
    case 'msecs':
    case 'msec':
    case 'ms':
      return n;
    default:
      return undefined;
  }
}

/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtShort(ms) {
  var msAbs = Math.abs(ms);
  if (msAbs >= d) {
    return Math.round(ms / d) + 'd';
  }
  if (msAbs >= h) {
    return Math.round(ms / h) + 'h';
  }
  if (msAbs >= m) {
    return Math.round(ms / m) + 'm';
  }
  if (msAbs >= s) {
    return Math.round(ms / s) + 's';
  }
  return ms + 'ms';
}

/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtLong(ms) {
  var msAbs = Math.abs(ms);
  if (msAbs >= d) {
    return plural(ms, msAbs, d, 'day');
  }
  if (msAbs >= h) {
    return plural(ms, msAbs, h, 'hour');
  }
  if (msAbs >= m) {
    return plural(ms, msAbs, m, 'minute');
  }
  if (msAbs >= s) {
    return plural(ms, msAbs, s, 'second');
  }
  return ms + ' ms';
}

/**
 * Pluralization helper.
 */

function plural(ms, msAbs, n, name) {
  var isPlural = msAbs >= n * 1.5;
  return Math.round(ms / n) + ' ' + name + (isPlural ? 's' : '');
}


/***/ }),

/***/ 36313:
/***/ ((module) => {

"use strict";

module.exports = () => {
	const ret = {};

	ret.promise = new Promise((resolve, reject) => {
		ret.resolve = resolve;
		ret.reject = reject;
	});

	return ret;
};


/***/ }),

/***/ 88461:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getErrorFromUnknown = void 0;
const server_1 = __webpack_require__(63539);
function getErrorFromUnknown(cause) {
    if (cause instanceof Error && cause.name === 'TRPCError') {
        return cause;
    }
    let errorCause = undefined;
    let stack = undefined;
    if (cause instanceof Error) {
        errorCause = cause;
        stack = cause.stack;
    }
    const error = new server_1.TRPCError({
        message: 'Internal server error',
        code: 'INTERNAL_SERVER_ERROR',
        cause: errorCause,
    });
    if (stack) {
        error.stack = stack;
    }
    return error;
}
exports.getErrorFromUnknown = getErrorFromUnknown;
//# sourceMappingURL=errors.js.map

/***/ }),

/***/ 52729:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createChromeHandler = void 0;
const server_1 = __webpack_require__(63539);
const observable_1 = __webpack_require__(77920);
const errors_1 = __webpack_require__(88461);
const createChromeHandler = (opts) => {
    const { router, createContext, onError } = opts;
    const { transformer } = router._def._config;
    chrome.runtime.onConnect.addListener((port) => {
        const subscriptions = new Map();
        const listeners = [];
        const onDisconnect = () => {
            listeners.forEach((unsub) => unsub());
        };
        port.onDisconnect.addListener(onDisconnect);
        listeners.push(() => port.onDisconnect.removeListener(onDisconnect));
        const onMessage = async (message) => {
            if (!('trpc' in message))
                return;
            const { trpc } = message;
            if (!('id' in trpc) || trpc.id === null || trpc.id === undefined)
                return;
            if (!trpc)
                return;
            const { id, jsonrpc, method } = trpc;
            const sendResponse = (response) => {
                port.postMessage({
                    trpc: Object.assign({ id, jsonrpc }, response),
                });
            };
            let params;
            let input;
            let ctx;
            try {
                if (method === 'subscription.stop') {
                    const subscription = subscriptions.get(id);
                    if (subscription) {
                        subscription.unsubscribe();
                        sendResponse({
                            result: {
                                type: 'stopped',
                            },
                        });
                    }
                    subscriptions.delete(id);
                    return;
                }
                params = trpc.params;
                input = transformer.input.deserialize(params.input);
                ctx = await (createContext === null || createContext === void 0 ? void 0 : createContext({ req: port, res: undefined }));
                const caller = router.createCaller(ctx);
                const segments = params.path.split('.');
                const procedureFn = segments.reduce((acc, segment) => acc[segment], caller);
                const result = await procedureFn(input);
                if (method !== 'subscription') {
                    const data = transformer.output.serialize(result);
                    sendResponse({
                        result: {
                            type: 'data',
                            data,
                        },
                    });
                    return;
                }
                if (!(0, observable_1.isObservable)(result)) {
                    throw new server_1.TRPCError({
                        message: 'Subscription ${params.path} did not return an observable',
                        code: 'INTERNAL_SERVER_ERROR',
                    });
                }
                const subscription = result.subscribe({
                    next: (data) => {
                        sendResponse({
                            result: {
                                type: 'data',
                                data,
                            },
                        });
                    },
                    error: (cause) => {
                        const error = (0, errors_1.getErrorFromUnknown)(cause);
                        onError === null || onError === void 0 ? void 0 : onError({
                            error,
                            type: method,
                            path: params === null || params === void 0 ? void 0 : params.path,
                            input,
                            ctx,
                            req: port,
                        });
                        sendResponse({
                            error: router.getErrorShape({
                                error,
                                type: method,
                                path: params === null || params === void 0 ? void 0 : params.path,
                                input,
                                ctx,
                            }),
                        });
                    },
                    complete: () => {
                        sendResponse({
                            result: {
                                type: 'stopped',
                            },
                        });
                    },
                });
                if (subscriptions.has(id)) {
                    subscription.unsubscribe();
                    sendResponse({
                        result: {
                            type: 'stopped',
                        },
                    });
                    throw new server_1.TRPCError({
                        message: `Duplicate id ${id}`,
                        code: 'BAD_REQUEST',
                    });
                }
                listeners.push(() => subscription.unsubscribe());
                subscriptions.set(id, subscription);
                sendResponse({
                    result: {
                        type: 'started',
                    },
                });
                return;
            }
            catch (cause) {
                const error = (0, errors_1.getErrorFromUnknown)(cause);
                onError === null || onError === void 0 ? void 0 : onError({
                    error,
                    type: method,
                    path: params === null || params === void 0 ? void 0 : params.path,
                    input,
                    ctx,
                    req: port,
                });
                sendResponse({
                    error: router.getErrorShape({
                        error,
                        type: method,
                        path: params === null || params === void 0 ? void 0 : params.path,
                        input,
                        ctx,
                    }),
                });
            }
        };
        port.onMessage.addListener(onMessage);
        listeners.push(() => port.onMessage.removeListener(onMessage));
    });
};
exports.createChromeHandler = createChromeHandler;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ 51087:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.log = void 0;
__webpack_require__(15664);
const debug_1 = __importDefault(__webpack_require__(96292));
exports.log = (0, debug_1.default)('au:backgroundPage');
localStorage.debug = 'au:*'; // enable all debug messages
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/firebase-messaging-sw.js').then(function (registration) {
        (0, exports.log)('ServiceWorker registration successful with scope: ', registration.scope);
    }).catch(function (err) {
        //registration failed :(
        (0, exports.log)('ServiceWorker registration failed: ', err);
    });
}
else {
    (0, exports.log)('No service-worker on this browser');
}


/***/ }),

/***/ 24434:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.backgroundStateSerializableLockedSchema = exports.settingsSchema = exports.webInputElementSchema = exports.capturedEventsPayloadSchema = exports.encryptedDataSchema = exports.loginCredentialsFromContentScriptSchema = exports.loginCredentialSchema = exports.contentScriptContextSchema = exports.capturedInputSchema = void 0;
const graphqlBaseTypes_1 = __webpack_require__(89931);
const zod_1 = __webpack_require__(78754);
exports.capturedInputSchema = zod_1.z.object({
    cssSelector: zod_1.z.string().min(1),
    domOrdinal: zod_1.z.number(),
    type: zod_1.z.union([zod_1.z.literal('input'), zod_1.z.literal('submit'), zod_1.z.literal('keydown')]),
    kind: zod_1.z.nativeEnum(graphqlBaseTypes_1.WebInputType),
    inputted: zod_1.z.string().optional(),
    domCoordinates: zod_1.z.object({
        x: zod_1.z.number(),
        y: zod_1.z.number()
    })
});
exports.contentScriptContextSchema = zod_1.z.object({
    capturedInputEvents: zod_1.z.array(exports.capturedInputSchema),
    openInVault: zod_1.z.boolean()
});
exports.loginCredentialSchema = zod_1.z.object({
    username: zod_1.z.string(),
    password: zod_1.z.string()
});
exports.loginCredentialsFromContentScriptSchema = exports.contentScriptContextSchema.extend({
    username: zod_1.z.string(),
    password: zod_1.z.string()
});
exports.encryptedDataSchema = exports.loginCredentialSchema.extend({
    iconUrl: zod_1.z.string().nullable(),
    url: zod_1.z.string(),
    label: zod_1.z.string()
});
exports.capturedEventsPayloadSchema = zod_1.z.object({
    url: zod_1.z.string(),
    inputEvents: zod_1.z.array(exports.capturedInputSchema)
});
exports.webInputElementSchema = zod_1.z.object({
    domCoordinates: zod_1.z.object({
        x: zod_1.z.number(),
        y: zod_1.z.number()
    }),
    domOrdinal: zod_1.z.number(),
    domPath: zod_1.z.string(),
    kind: zod_1.z.nativeEnum(graphqlBaseTypes_1.WebInputType),
    url: zod_1.z.string()
});
exports.settingsSchema = zod_1.z.object({
    autofill: zod_1.z.boolean(),
    language: zod_1.z.string(),
    syncTOTP: zod_1.z.boolean(),
    theme: zod_1.z.string().optional().nullable(),
    vaultLockTimeoutSeconds: zod_1.z.number()
});
exports.backgroundStateSerializableLockedSchema = zod_1.z.object({
    email: zod_1.z.string(),
    userId: zod_1.z.string(),
    secrets: zod_1.z.array(zod_1.z.object({
        id: zod_1.z.string(),
        encrypted: zod_1.z.string(),
        kind: zod_1.z.nativeEnum(graphqlBaseTypes_1.EncryptedSecretType),
        lastUsedAt: zod_1.z.string().nullable().optional(),
        createdAt: zod_1.z.string(),
        deletedAt: zod_1.z.string().nullable().optional(),
        updatedAt: zod_1.z.string().nullable().optional()
    })),
    encryptionSalt: zod_1.z.string(),
    deviceName: zod_1.z.string(),
    authSecretEncrypted: zod_1.z.string(),
    authSecret: zod_1.z.string(),
    lockTime: zod_1.z.number(),
    autofill: zod_1.z.boolean(),
    language: zod_1.z.string(),
    theme: zod_1.z.string(),
    syncTOTP: zod_1.z.boolean(),
    masterEncryptionKey: zod_1.z.string()
});


/***/ }),

/***/ 5486:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useWebInputsForHostLazyQuery = exports.useWebInputsForHostQuery = exports.WebInputsForHostDocument = exports.useAddWebInputsMutation = exports.AddWebInputsDocument = void 0;
const client_1 = __webpack_require__(17547);
const Apollo = __importStar(__webpack_require__(17547));
const defaultOptions = {};
exports.AddWebInputsDocument = (0, client_1.gql) `
    mutation addWebInputs($webInputs: [WebInputElement!]!) {
  addWebInputs(webInputs: $webInputs) {
    id
  }
}
    `;
/**
 * __useAddWebInputsMutation__
 *
 * To run a mutation, you first call `useAddWebInputsMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAddWebInputsMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [addWebInputsMutation, { data, loading, error }] = useAddWebInputsMutation({
 *   variables: {
 *      webInputs: // value for 'webInputs'
 *   },
 * });
 */
function useAddWebInputsMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.AddWebInputsDocument, options);
}
exports.useAddWebInputsMutation = useAddWebInputsMutation;
exports.WebInputsForHostDocument = (0, client_1.gql) `
    query webInputsForHost($host: String!) {
  webInputs(host: $host) {
    id
    host
    url
    domPath
    domOrdinal
    kind
    createdAt
    domCoordinates
  }
}
    `;
/**
 * __useWebInputsForHostQuery__
 *
 * To run a query within a React component, call `useWebInputsForHostQuery` and pass it any options that fit your needs.
 * When your component renders, `useWebInputsForHostQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useWebInputsForHostQuery({
 *   variables: {
 *      host: // value for 'host'
 *   },
 * });
 */
function useWebInputsForHostQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.WebInputsForHostDocument, options);
}
exports.useWebInputsForHostQuery = useWebInputsForHostQuery;
function useWebInputsForHostLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.WebInputsForHostDocument, options);
}
exports.useWebInputsForHostLazyQuery = useWebInputsForHostLazyQuery;


/***/ }),

/***/ 15664:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.noHandsLogin = exports.saveLoginModalsStates = void 0;
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const debug_1 = __importDefault(__webpack_require__(96292));
const apolloClient_1 = __webpack_require__(77348);
const chromeRuntimeListener_codegen_1 = __webpack_require__(5486);
const graphqlBaseTypes_1 = __webpack_require__(89931);
const server_1 = __webpack_require__(63539);
const adapter_1 = __webpack_require__(52729);
const ExtensionDevice_1 = __webpack_require__(2247);
const getContentScriptInitialState_1 = __webpack_require__(95748);
const backgroundSchemas_1 = __webpack_require__(24434);
const zod_1 = __webpack_require__(78754);
const log = (0, debug_1.default)('au:chListener');
if (!ExtensionDevice_1.isRunningInBgPage) {
    throw new Error('this file should only be imported in the background page');
}
const t = server_1.initTRPC.create({
    isServer: false,
    allowOutsideOfServer: true
});
//NOTE: temporery storage for not yet saved credentials. (during page rerender)
exports.saveLoginModalsStates = new Map();
exports.noHandsLogin = false;
let capturedInputEvents = [];
let inputsUrl;
let lockTimeEnd;
let lockTimeStart;
let lockInterval;
const appRouter = t.router({
    addLoginCredentials: t.procedure.input(backgroundSchemas_1.loginCredentialsFromContentScriptSchema).mutation(({ ctx, input }) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b;
        // @ts-expect-error
        const tab = ctx.sender.tab;
        const deviceState = ExtensionDevice_1.device.state;
        const { url } = tab;
        if (!url || !deviceState) {
            return false; // we can't do anything without a valid url
        }
        let urlParsed;
        try {
            urlParsed = new URL(url);
        }
        catch (err) {
            return false;
        }
        const credentials = input;
        log('addLoginCredentials', credentials);
        const encryptedData = {
            username: credentials.username,
            password: credentials.password,
            iconUrl: (_a = tab.favIconUrl) !== null && _a !== void 0 ? _a : null,
            url: inputsUrl,
            label: (_b = tab.title) !== null && _b !== void 0 ? _b : `${credentials.username}@${urlParsed.hostname}`
        };
        backgroundSchemas_1.encryptedDataSchema.parse(encryptedData);
        const encrypted = yield deviceState.encrypt(JSON.stringify(encryptedData));
        const [secret] = yield deviceState.addSecrets([{
                kind: graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS,
                loginCredentials: encryptedData,
                encrypted,
                createdAt: new Date().toJSON()
            }]);
        if (!secret) {
            return false;
        }
        tab.id && exports.saveLoginModalsStates.delete(tab.id);
        const webInputs = credentials.capturedInputEvents.map(captured => {
            return {
                domPath: captured.cssSelector,
                kind: captured.kind,
                url: inputsUrl,
                domOrdinal: captured.domOrdinal,
                domCoordinates: captured.domCoordinates
            };
        });
        yield apolloClient_1.apolloClient.mutate({
            mutation: chromeRuntimeListener_codegen_1.AddWebInputsDocument,
            variables: {
                webInputs
            }
        });
        if (input.openInVault) {
            webextension_polyfill_1.default.tabs.create({
                url: `vault.html#/secret/${secret.id}`
            });
        }
    })),
    saveCapturedInputEvents: t.procedure.input(backgroundSchemas_1.capturedEventsPayloadSchema).mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        capturedInputEvents = input.inputEvents;
        inputsUrl = input.url;
        const newWebInputs = capturedInputEvents.map(captured => {
            return {
                domPath: captured.cssSelector,
                kind: captured.kind,
                url: inputsUrl,
                domOrdinal: captured.domOrdinal,
                domCoordinates: captured.domCoordinates
            };
        });
        //Update web inputs in DB
        yield apolloClient_1.apolloClient.mutate({
            mutation: chromeRuntimeListener_codegen_1.AddWebInputsDocument,
            variables: {
                webInputs: newWebInputs
            }
        });
    })),
    saveLoginCredentialsModalShown: t.procedure.input(backgroundSchemas_1.loginCredentialSchema).mutation(({ input, ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        // @ts-expect-error
        const tab = ctx.sender.tab;
        const currentTabId = tab.id;
        if (currentTabId) {
            exports.saveLoginModalsStates.set(currentTabId, input);
        }
    })),
    hideLoginCredentialsModal: t.procedure.mutation(({ ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        // @ts-expect-error
        const tab = ctx.sender.tab;
        const currentTabId = tab.id;
        if (currentTabId) {
            exports.saveLoginModalsStates.delete(currentTabId);
        }
    })),
    addTOTPInput: t.procedure.input(backgroundSchemas_1.webInputElementSchema).mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        yield apolloClient_1.apolloClient.mutate({
            mutation: chromeRuntimeListener_codegen_1.AddWebInputsDocument,
            variables: {
                webInputs: [input]
            }
        });
    })),
    getFallbackUsernames: t.procedure.query(() => __awaiter(void 0, void 0, void 0, function* () {
        const deviceState = ExtensionDevice_1.device.state;
        log('Getting fallback usernames', deviceState === null || deviceState === void 0 ? void 0 : deviceState.email);
        return [deviceState === null || deviceState === void 0 ? void 0 : deviceState.email];
    })),
    getContentScriptInitialState: t.procedure.query(({ ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        // @ts-expect-error
        const tab = ctx.sender.tab;
        const currentTabId = tab.id;
        const tabUrl = tab === null || tab === void 0 ? void 0 : tab.url;
        const deviceState = ExtensionDevice_1.device.state;
        log('GEtting initial state from BG', tab === null || tab === void 0 ? void 0 : tab.url, tab === null || tab === void 0 ? void 0 : tab.pendingUrl);
        if (!tabUrl || !deviceState || !currentTabId) {
            log('~ chromeRuntimeListener We dont have tabURL or deviceState or tabId');
            return null;
        }
        else {
            //We will have to get webInputs for current URL from DB and send it to content script for reseting after new DOM path save
            return (0, getContentScriptInitialState_1.getContentScriptInitialState)(tabUrl, currentTabId);
        }
    })),
    getCapturedInputEvents: t.procedure.query(({ ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        // @ts-expect-error
        const tab = ctx.sender.tab;
        return {
            capturedInputEvents,
            inputsUrl: tab === null || tab === void 0 ? void 0 : tab.url
        };
    })),
    securitySettings: t.procedure.input(backgroundSchemas_1.settingsSchema).mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        const deviceState = ExtensionDevice_1.device.state;
        if (deviceState) {
            deviceState.lockTime = input.vaultLockTimeoutSeconds;
            deviceState.syncTOTP = input.syncTOTP;
            deviceState.language = input.language;
            deviceState.autofill = input.autofill;
            exports.noHandsLogin = input.autofill;
            //Refresh the lock interval
            lockInterval = clearInterval(lockInterval);
            lockTimeStart = Date.now();
            lockTimeEnd = lockTimeStart + deviceState.lockTime * 1000;
            checkInterval(lockTimeEnd);
            deviceState.save();
        }
        return true;
    })),
    setLockInterval: t.procedure.input(zod_1.z.object({
        time: zod_1.z.number()
    })).mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        if (!lockInterval) {
            lockTimeStart = Date.now();
            lockTimeEnd = lockTimeStart + input.time * 1000;
        }
        checkInterval(lockTimeEnd);
        return true;
    })),
    clearLockInterval: t.procedure.mutation(() => __awaiter(void 0, void 0, void 0, function* () {
        resetInterval();
        return true;
    })),
    setDeviceState: t.procedure.input(backgroundSchemas_1.backgroundStateSerializableLockedSchema).mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        ExtensionDevice_1.device.save(input);
        return true;
    }))
});
(0, adapter_1.createChromeHandler)({
    router: appRouter,
    createContext: ctx => {
        return {
            sender: ctx.req.sender
        };
    },
    onError: err => {
        console.error('TRPC ERROR', err);
    }
});
log('background page loaded');
const checkInterval = time => {
    if (!lockInterval && lockTimeStart !== lockTimeEnd) {
        lockInterval = setInterval(() => {
            if (time && time <= Date.now()) {
                log('lock', Date.now(), ExtensionDevice_1.device);
                resetInterval();
                ExtensionDevice_1.device.lock();
            }
        }, 5000);
    }
};
const resetInterval = () => {
    lockTimeEnd = null;
    lockTimeStart = null;
    lockInterval = clearInterval(lockInterval);
};


/***/ }),

/***/ 95748:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getContentScriptInitialState = void 0;
const apolloClient_1 = __webpack_require__(77348);
const graphqlBaseTypes_1 = __webpack_require__(89931);
const chromeRuntimeListener_1 = __webpack_require__(15664);
const chromeRuntimeListener_codegen_1 = __webpack_require__(5486);
const ExtensionDevice_1 = __webpack_require__(2247);
const mem_1 = __importDefault(__webpack_require__(48747));
const ms_1 = __importDefault(__webpack_require__(48628));
const AccountLimits_codegen_1 = __webpack_require__(54417);
const debug_1 = __importDefault(__webpack_require__(96292));
const log = (0, debug_1.default)('au:getContentScriptInitialState');
const getContentScriptInitialState = (tabUrl, currentTabId) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f;
    log('tabUrl', tabUrl);
    const hostname = new URL(tabUrl).hostname;
    const decrypted = (_b = (yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.getSecretsDecryptedByHostname(hostname)))) !== null && _b !== void 0 ? _b : [];
    const res = yield getWebInputs(hostname);
    const userInfo = yield getAccountLimits();
    return {
        extensionDeviceReady: !!((_c = ExtensionDevice_1.device.state) === null || _c === void 0 ? void 0 : _c.masterEncryptionKey),
        autofillEnabled: !!((_d = ExtensionDevice_1.device.state) === null || _d === void 0 ? void 0 : _d.autofill),
        webInputs: res.data.webInputs,
        passwordLimit: userInfo.data.me.PasswordLimits,
        passwordCount: (_f = (_e = ExtensionDevice_1.device.state) === null || _e === void 0 ? void 0 : _e.secrets.filter(i => i.kind === graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS).length) !== null && _f !== void 0 ? _f : 0,
        secretsForHost: {
            loginCredentials: decrypted.filter(({ kind }) => kind === graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS),
            totpSecrets: decrypted.filter(({ kind }) => kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP)
        },
        saveLoginModalsState: currentTabId ? chromeRuntimeListener_1.saveLoginModalsStates.get(currentTabId) : null
    };
});
exports.getContentScriptInitialState = getContentScriptInitialState;
const getAccountLimits = () => {
    return apolloClient_1.apolloClient.query({
        query: AccountLimits_codegen_1.MeExtensionDocument,
        fetchPolicy: 'network-only'
    });
};
// TODO stop using mem for this, we should be able to use the apollo cache
const getWebInputs = (0, mem_1.default)(hostname => {
    return apolloClient_1.apolloClient.query({
        query: chromeRuntimeListener_codegen_1.WebInputsForHostDocument,
        variables: {
            host: hostname
        },
        fetchPolicy: 'network-only'
    });
}, {
    maxAge: (0, ms_1.default)('2 days')
});


/***/ }),

/***/ 22729:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.renderPopup = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const Sentry = __importStar(__webpack_require__(18749));
const client_1 = __importDefault(__webpack_require__(20745));
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const client_2 = __webpack_require__(17547);
const App_1 = __importDefault(__webpack_require__(50257));
const apolloClient_1 = __webpack_require__(77348);
const react_1 = __webpack_require__(53159);
const chakraRawTheme_1 = __webpack_require__(15485);
Sentry.init({
    dsn: 'https://528d6bfc04eb436faea6046afc419f56@o997539.ingest.sentry.io/5955889'
});
let popupRoot;
const renderPopup = () => {
    var _a;
    popupRoot.render((0, jsx_runtime_1.jsxs)(client_2.ApolloProvider, Object.assign({ client: apolloClient_1.apolloClient }, { children: [(0, jsx_runtime_1.jsx)(react_1.ColorModeScript, { initialColorMode: (_a = chakraRawTheme_1.chakraRawTheme.config) === null || _a === void 0 ? void 0 : _a.initialColorMode }), (0, jsx_runtime_1.jsx)(App_1.default, { parent: "popup" })] })));
};
exports.renderPopup = renderPopup;
webextension_polyfill_1.default.tabs.query({
    active: true,
    currentWindow: true
}).then(() => {
    popupRoot = client_1.default.createRoot(document.getElementById('popup'));
    (0, exports.renderPopup)();
});


/***/ }),

/***/ 84161:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.renderVault = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const Sentry = __importStar(__webpack_require__(18749));
const react_1 = __importDefault(__webpack_require__(27378));
const client_1 = __importDefault(__webpack_require__(20745));
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const client_2 = __webpack_require__(17547);
const App_1 = __importDefault(__webpack_require__(50257));
const apolloClient_1 = __webpack_require__(77348);
const react_router_dom_1 = __webpack_require__(36634);
const react_2 = __webpack_require__(53159);
const chakraRawTheme_1 = __webpack_require__(15485);
Sentry.init({
    dsn: 'https://528d6bfc04eb436faea6046afc419f56@o997539.ingest.sentry.io/5955889'
});
let vaultRoot;
const renderVault = () => {
    var _a;
    vaultRoot.render((0, jsx_runtime_1.jsx)(react_router_dom_1.HashRouter, Object.assign({ basename: "/" }, { children: (0, jsx_runtime_1.jsxs)(client_2.ApolloProvider, Object.assign({ client: apolloClient_1.apolloClient }, { children: [(0, jsx_runtime_1.jsx)(react_2.ColorModeScript, { initialColorMode: (_a = chakraRawTheme_1.chakraRawTheme.config) === null || _a === void 0 ? void 0 : _a.initialColorMode }), (0, jsx_runtime_1.jsx)(App_1.default, { parent: "vault" })] })) })));
};
exports.renderVault = renderVault;
webextension_polyfill_1.default.tabs.query({
    active: true,
    currentWindow: true
}).then(() => {
    vaultRoot = client_1.default.createRoot(document.getElementById('vault'));
    (0, exports.renderVault)();
});


/***/ }),

/***/ 56970:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ maybe)
/* harmony export */ });
function maybe(thunk) {
    try {
        return thunk();
    }
    catch (_a) { }
}
//# sourceMappingURL=maybe.js.map

/***/ }),

/***/ 48747:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ mem),
  "memClear": () => (/* binding */ memClear),
  "memDecorator": () => (/* binding */ memDecorator)
});

;// CONCATENATED MODULE: ./node_modules/mimic-fn/index.js
const copyProperty = (to, from, property, ignoreNonConfigurable) => {
	// `Function#length` should reflect the parameters of `to` not `from` since we keep its body.
	// `Function#prototype` is non-writable and non-configurable so can never be modified.
	if (property === 'length' || property === 'prototype') {
		return;
	}

	// `Function#arguments` and `Function#caller` should not be copied. They were reported to be present in `Reflect.ownKeys` for some devices in React Native (#41), so we explicitly ignore them here.
	if (property === 'arguments' || property === 'caller') {
		return;
	}

	const toDescriptor = Object.getOwnPropertyDescriptor(to, property);
	const fromDescriptor = Object.getOwnPropertyDescriptor(from, property);

	if (!canCopyProperty(toDescriptor, fromDescriptor) && ignoreNonConfigurable) {
		return;
	}

	Object.defineProperty(to, property, fromDescriptor);
};

// `Object.defineProperty()` throws if the property exists, is not configurable and either:
// - one its descriptors is changed
// - it is non-writable and its value is changed
const canCopyProperty = function (toDescriptor, fromDescriptor) {
	return toDescriptor === undefined || toDescriptor.configurable || (
		toDescriptor.writable === fromDescriptor.writable &&
		toDescriptor.enumerable === fromDescriptor.enumerable &&
		toDescriptor.configurable === fromDescriptor.configurable &&
		(toDescriptor.writable || toDescriptor.value === fromDescriptor.value)
	);
};

const changePrototype = (to, from) => {
	const fromPrototype = Object.getPrototypeOf(from);
	if (fromPrototype === Object.getPrototypeOf(to)) {
		return;
	}

	Object.setPrototypeOf(to, fromPrototype);
};

const wrappedToString = (withName, fromBody) => `/* Wrapped ${withName}*/\n${fromBody}`;

const toStringDescriptor = Object.getOwnPropertyDescriptor(Function.prototype, 'toString');
const toStringName = Object.getOwnPropertyDescriptor(Function.prototype.toString, 'name');

// We call `from.toString()` early (not lazily) to ensure `from` can be garbage collected.
// We use `bind()` instead of a closure for the same reason.
// Calling `from.toString()` early also allows caching it in case `to.toString()` is called several times.
const changeToString = (to, from, name) => {
	const withName = name === '' ? '' : `with ${name.trim()}() `;
	const newToString = wrappedToString.bind(null, withName, from.toString());
	// Ensure `to.toString.toString` is non-enumerable and has the same `same`
	Object.defineProperty(newToString, 'name', toStringName);
	Object.defineProperty(to, 'toString', {...toStringDescriptor, value: newToString});
};

function mimicFunction(to, from, {ignoreNonConfigurable = false} = {}) {
	const {name} = to;

	for (const property of Reflect.ownKeys(from)) {
		copyProperty(to, from, property, ignoreNonConfigurable);
	}

	changePrototype(to, from);
	changeToString(to, from, name);

	return to;
}

// EXTERNAL MODULE: ../node_modules/map-age-cleaner/dist/index.js
var dist = __webpack_require__(21494);
;// CONCATENATED MODULE: ./node_modules/mem/dist/index.js


const cacheStore = new WeakMap();
/**
[Memoize](https://en.wikipedia.org/wiki/Memoization) functions - An optimization used to speed up consecutive function calls by caching the result of calls with identical input.

@param fn - Function to be memoized.

@example
```
import mem from 'mem';

let index = 0;
const counter = () => ++index;
const memoized = mem(counter);

memoized('foo');
//=> 1

// Cached as it's the same argument
memoized('foo');
//=> 1

// Not cached anymore as the arguments changed
memoized('bar');
//=> 2

memoized('bar');
//=> 2
```
*/
function mem(fn, { cacheKey, cache = new Map(), maxAge, } = {}) {
    if (typeof maxAge === 'number') {
        dist(cache);
    }
    const memoized = function (...arguments_) {
        const key = cacheKey ? cacheKey(arguments_) : arguments_[0];
        const cacheItem = cache.get(key);
        if (cacheItem) {
            return cacheItem.data; // eslint-disable-line @typescript-eslint/no-unsafe-return
        }
        const result = fn.apply(this, arguments_);
        cache.set(key, {
            data: result,
            maxAge: maxAge ? Date.now() + maxAge : Number.POSITIVE_INFINITY,
        });
        return result; // eslint-disable-line @typescript-eslint/no-unsafe-return
    };
    mimicFunction(memoized, fn, {
        ignoreNonConfigurable: true,
    });
    cacheStore.set(memoized, cache);
    return memoized;
}
/**
@returns A [decorator](https://github.com/tc39/proposal-decorators) to memoize class methods or static class methods.

@example
```
import {memDecorator} from 'mem';

class Example {
    index = 0

    @memDecorator()
    counter() {
        return ++this.index;
    }
}

class ExampleWithOptions {
    index = 0

    @memDecorator({maxAge: 1000})
    counter() {
        return ++this.index;
    }
}
```
*/
function memDecorator(options = {}) {
    const instanceMap = new WeakMap();
    return (target, propertyKey, descriptor) => {
        const input = target[propertyKey]; // eslint-disable-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
        if (typeof input !== 'function') {
            throw new TypeError('The decorated value must be a function');
        }
        delete descriptor.value;
        delete descriptor.writable;
        descriptor.get = function () {
            if (!instanceMap.has(this)) {
                const value = mem(input, options);
                instanceMap.set(this, value);
                return value;
            }
            return instanceMap.get(this);
        };
    };
}
/**
Clear all cached data of a memoized function.

@param fn - Memoized function.
*/
function memClear(fn) {
    const cache = cacheStore.get(fn);
    if (!cache) {
        throw new TypeError('Can\'t clear a function that was not memoized!');
    }
    if (typeof cache.clear !== 'function') {
        throw new TypeError('The cache Map can\'t be cleared!');
    }
    cache.clear();
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/harmony module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.hmd = (module) => {
/******/ 			module = Object.create(module);
/******/ 			if (!module.children) module.children = [];
/******/ 			Object.defineProperty(module, 'exports', {
/******/ 				enumerable: true,
/******/ 				set: () => {
/******/ 					throw new Error('ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: ' + module.id);
/******/ 				}
/******/ 			});
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			891: 0,
/******/ 			42: 0,
/******/ 			420: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkauthier_web_extension"] = self["webpackChunkauthier_web_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [627,621,533,126,780,222,90,701,286,17,384,451,747,257], () => (__webpack_require__(51087)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;