"use strict";
(self["webpackChunkauthier_web_extension"] = self["webpackChunkauthier_web_extension"] || []).push([[257],{

/***/ 50257:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const accessTokenExtension_1 = __webpack_require__(27690);
const react_2 = __importStar(__webpack_require__(27378));
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const Providers_1 = __importDefault(__webpack_require__(62142));
function App({ parent }) {
    const [loading, setLoading] = (0, react_2.useState)(true);
    (0, react_2.useEffect)(() => {
        function token() {
            return __awaiter(this, void 0, void 0, function* () {
                const s = yield webextension_polyfill_1.default.storage.local.get('access-token');
                (0, accessTokenExtension_1.setAccessToken)(s['access-token']);
                setLoading(false);
            });
        }
        token();
    }, []);
    if (loading) {
        return (0, jsx_runtime_1.jsx)(react_1.Flex, { children: "Loading..." });
    }
    return (0, jsx_runtime_1.jsx)(Providers_1.default, { parent: parent });
}
exports["default"] = App;


/***/ }),

/***/ 43932:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthLinkPage = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const layout_1 = __webpack_require__(64178);
const react_2 = __webpack_require__(53159);
const react_3 = __webpack_require__(53159);
const react_4 = __importDefault(__webpack_require__(27378));
const io_1 = __webpack_require__(51649);
function AuthLinkPage() {
    return (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsx)(layout_1.Box, Object.assign({ width: "315px", p: 30 }, { children: (0, jsx_runtime_1.jsxs)(react_2.Center, { children: [(0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "sm" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Open vault to login or sign up" }) })), (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: /*i18n*/ core_1.i18n._("Open vault"), "aria-label": /*i18n*/ core_1.i18n._("Open vault") }, { children: (0, jsx_runtime_1.jsx)(react_3.IconButton, { size: "md", ml: "2", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(io_1.IoMdArchive, {}), onClick: () => __awaiter(this, void 0, void 0, function* () {
                                chrome.tabs.create({
                                    url: 'vault.html'
                                });
                            }) }) }))] }) })) });
}
exports.AuthLinkPage = AuthLinkPage;


/***/ }),

/***/ 77430:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(27378);
const AuthLinkPage_1 = __webpack_require__(43932);
const VaultUnlockVerification_1 = __webpack_require__(56972);
const Popup_1 = __webpack_require__(9731);
const DeviceStateProvider_1 = __webpack_require__(58311);
const debug_1 = __importDefault(__webpack_require__(96292));
const log = (0, debug_1.default)('au:popupRoutes');
function PopupRoutes() {
    const { device, deviceState } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    log('deviceState', deviceState);
    log({
        device
    });
    if (device.lockedState) {
        return (0, jsx_runtime_1.jsx)(VaultUnlockVerification_1.VaultUnlockVerification, {});
    }
    if (deviceState === null) {
        return (0, jsx_runtime_1.jsx)(AuthLinkPage_1.AuthLinkPage, {});
    }
    return (0, jsx_runtime_1.jsx)(Popup_1.Popup, {});
}
exports["default"] = PopupRoutes;


/***/ }),

/***/ 62142:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.chakraCustomTheme = exports.toast = exports.ToastContainer = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_2 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const UserProvider_1 = __webpack_require__(59871);
const PopupRoutes_1 = __importDefault(__webpack_require__(77430));
const chakraRawTheme_1 = __webpack_require__(15485);
const DeviceStateProvider_1 = __webpack_require__(58311);
const messages_1 = __webpack_require__(81676);
const VaultRouter_1 = __webpack_require__(67735);
_a = (0, react_1.createStandaloneToast)({
    theme: chakraRawTheme_1.chakraRawTheme
}), exports.ToastContainer = _a.ToastContainer, exports.toast = _a.toast;
core_1.i18n.load('en', messages_1.messages);
core_1.i18n.activate('en');
exports.chakraCustomTheme = (0, react_1.extendTheme)(chakraRawTheme_1.chakraRawTheme);
function Providers({ parent }) {
    return (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsx)(react_1.ChakraProvider, Object.assign({ theme: exports.chakraCustomTheme }, { children: (0, jsx_runtime_1.jsx)(DeviceStateProvider_1.DeviceStateProvider, { children: (0, jsx_runtime_1.jsx)(UserProvider_1.UserProvider, { children: (0, jsx_runtime_1.jsx)(react_2.I18nProvider, Object.assign({ i18n: core_1.i18n }, { children: parent === 'vault' ? (0, jsx_runtime_1.jsx)(VaultRouter_1.VaultRouter, {}) : (0, jsx_runtime_1.jsx)(PopupRoutes_1.default, {}) })) }) }) })) });
}
exports["default"] = Providers;


/***/ }),

/***/ 77348:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.apolloClient = exports.API_URL = void 0;
const client_1 = __webpack_require__(17547);
const context_1 = __webpack_require__(37865);
const accessTokenExtension_1 = __webpack_require__(27690);
const errorLink_1 = __webpack_require__(40729);
const tokenRefresh_1 = __webpack_require__(95391);
const apollo_link_serialize_1 = __importDefault(__webpack_require__(97615));
exports.API_URL = "http://localhost:5051/graphql";
const httpLink = (0, client_1.createHttpLink)({
    uri: exports.API_URL,
    credentials: 'include'
});
const serializingLink = new apollo_link_serialize_1.default();
const authLink = (0, context_1.setContext)((_, { headers }) => __awaiter(void 0, void 0, void 0, function* () {
    //get the authentication token
    const accessToken = yield (0, accessTokenExtension_1.getTokenFromLocalStorage)();
    //return the headers to the context so httpLink can read them
    return {
        headers: Object.assign(Object.assign({}, headers), { authorization: accessToken ? `bearer ${accessToken}` : '' })
    };
}));
exports.apolloClient = new client_1.ApolloClient({
    link: client_1.ApolloLink.from([tokenRefresh_1.tokenRefresh,
        //FIX: Remove any
        errorLink_1.errorLink, serializingLink, authLink, httpLink]),
    cache: new client_1.InMemoryCache(),
    queryDeduplication: true
});


/***/ }),

/***/ 95391:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.tokenRefresh = void 0;
const accessTokenExtension_1 = __webpack_require__(27690);
const apollo_link_token_refresh_1 = __webpack_require__(48032);
const jwt_decode_1 = __importDefault(__webpack_require__(26601));
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const apolloClient_1 = __webpack_require__(77348);
const ExtensionDevice_1 = __webpack_require__(2247);
exports.tokenRefresh = new apollo_link_token_refresh_1.TokenRefreshLink({
    accessTokenField: 'accessToken',
    isTokenValidOrUndefined: () => {
        //Get token from local storage
        if (!accessTokenExtension_1.accessToken) {
            return false;
        }
        try {
            const { exp } = (0, jwt_decode_1.default)(accessTokenExtension_1.accessToken);
            if (Date.now() >= exp * 1000) {
                return false;
            }
            else {
                return true;
            }
        }
        catch (error) {
            return false;
        }
    },
    fetchAccessToken: () => __awaiter(void 0, void 0, void 0, function* () {
        return yield fetch(`${apolloClient_1.API_URL === null || apolloClient_1.API_URL === void 0 ? void 0 : apolloClient_1.API_URL.replace('/graphql', '')}/refresh_token`, {
            method: 'POST',
            credentials: 'include'
        });
    }),
    handleFetch: (accessToken) => __awaiter(void 0, void 0, void 0, function* () {
        yield webextension_polyfill_1.default.storage.local.set({
            'access-token': accessToken
        });
        (0, accessTokenExtension_1.setAccessToken)(accessToken);
    }),
    handleError: (err) => __awaiter(void 0, void 0, void 0, function* () {
        console.warn('Your refresh token is invalid. You must login again', err);
        yield (0, accessTokenExtension_1.removeToken)();
        yield ExtensionDevice_1.device.clearLocalStorage();
        ExtensionDevice_1.device.rerenderViews();
    })
});


/***/ }),

/***/ 2247:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.device = exports.DeviceState = exports.getDecryptedSecretProp = exports.isRunningInBgPage = exports.extensionDeviceTrpc = exports.log = void 0;
const debug_1 = __importDefault(__webpack_require__(96292));
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const bowser_1 = __importDefault(__webpack_require__(23630));
const accessTokenExtension_1 = __webpack_require__(27690);
const graphqlBaseTypes_1 = __webpack_require__(89931);
const apolloClient_1 = __webpack_require__(77348);
const ExtensionDevice_codegen_1 = __webpack_require__(79982);
const loginCredentialsSchema_1 = __webpack_require__(80245);
const generateEncryptionKey_1 = __webpack_require__(44038);
const Providers_1 = __webpack_require__(62142);
const client_1 = __webpack_require__(22490);
const link_1 = __webpack_require__(2554);
exports.log = (0, debug_1.default)('au:Device');
const port = chrome.runtime.connect();
exports.extensionDeviceTrpc = (0, client_1.createTRPCProxyClient)({
    links: [(0, link_1.chromeLink)({
            port
        })]
});
const getTldPart = url => {
    const host = new URL(url !== null && url !== void 0 ? url : '').hostname;
    const parts = host.split('.');
    return `${parts[parts.length - 2]}.${parts[parts.length - 1]}`;
};
function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
}
const browserInfo = bowser_1.default.getParser(navigator.userAgent);
exports.isRunningInBgPage = location.href.includes('_generated_background_page.html');
const isVault = location.href.includes('vault.html');
const isPopup = location.href.includes('popup.html');
function rerenderViewInThisRuntime() {
    return __awaiter(this, void 0, void 0, function* () {
        if (isVault) {
            const index = yield Promise.resolve().then(() => __importStar(__webpack_require__(84161)));
            index.renderVault();
        }
        else if (isPopup) {
            const index = yield Promise.resolve().then(() => __importStar(__webpack_require__(22729)));
            index.renderPopup();
        }
    });
}
const isLoginSecret = secret => 'loginCredentials' in secret;
const isTotpSecret = secret => 'totp' in secret;
const getDecryptedSecretProp = (secret, prop) => {
    var _a;
    return (_a = (secret.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP ? secret.totp[prop] : secret.loginCredentials[prop])) !== null && _a !== void 0 ? _a : '';
};
exports.getDecryptedSecretProp = getDecryptedSecretProp;
class DeviceState {
    constructor(parameters) {
        Object.assign(this, parameters);
        //log('device state created', this)
        webextension_polyfill_1.default.storage.onChanged.addListener(this.onStorageChange);
        this.initialize();
    }
    onStorageChange(changes, areaName) {
        (0, exports.log)('storage changed', changes, areaName);
        if (areaName === 'local' && changes.backgroundState && exports.device.state) {
            Object.assign(exports.device.state, changes.backgroundState.newValue);
        }
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            this.decryptedSecrets = yield this.getAllSecretsDecrypted();
        });
    }
    setMasterEncryptionKey(masterPassword) {
        return __awaiter(this, void 0, void 0, function* () {
            const key = yield (0, generateEncryptionKey_1.generateEncryptionKey)(masterPassword, (0, generateEncryptionKey_1.base64_to_buf)(this.encryptionSalt));
            this.masterEncryptionKey = yield (0, generateEncryptionKey_1.cryptoKeyToString)(key);
            this.save();
        });
    }
    /**
     * @returns string in base64
     */
    encrypt(stringToEncrypt) {
        return __awaiter(this, void 0, void 0, function* () {
            const cryptoKey = yield (0, generateEncryptionKey_1.abToCryptoKey)((0, generateEncryptionKey_1.base64_to_buf)(this.masterEncryptionKey));
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const salt = (0, generateEncryptionKey_1.base64_to_buf)(this.encryptionSalt);
            const encrypted = yield window.crypto.subtle.encrypt({
                name: 'AES-GCM',
                iv
            }, cryptoKey, generateEncryptionKey_1.enc.encode(stringToEncrypt));
            return (0, generateEncryptionKey_1.encryptedBuf_to_base64)(encrypted, iv, salt);
        });
    }
    /**
     * @param encrypted in base64
     * @returns pure string
     */
    decrypt(encrypted) {
        return __awaiter(this, void 0, void 0, function* () {
            const cryptoKey = yield (0, generateEncryptionKey_1.abToCryptoKey)((0, generateEncryptionKey_1.base64_to_buf)(this.masterEncryptionKey));
            const encryptedDataBuff = (0, generateEncryptionKey_1.base64_to_buf)(encrypted);
            const iv = encryptedDataBuff.slice(16, 16 + 12);
            const data = encryptedDataBuff.slice(16 + 12);
            const decrypted = yield window.crypto.subtle.decrypt({
                name: 'AES-GCM',
                iv
            }, cryptoKey, data);
            return generateEncryptionKey_1.dec.decode(decrypted);
        });
    }
    save() {
        return __awaiter(this, void 0, void 0, function* () {
            webextension_polyfill_1.default.storage.onChanged.removeListener(this.onStorageChange);
            exports.device.lockedState = null;
            this.decryptedSecrets = yield this.getAllSecretsDecrypted();
            (0, exports.log)('SAVE DEVICE STATE', this.decryptedSecrets);
            yield webextension_polyfill_1.default.storage.local.set({
                backgroundState: this,
                lockedState: null
            });
            webextension_polyfill_1.default.storage.onChanged.addListener(this.onStorageChange);
        });
    }
    getSecretDecryptedById(id) {
        const secret = this.decryptedSecrets.find(secret => secret.id === id);
        if (secret) {
            return this.decryptSecret(secret);
        }
    }
    getSecretsDecryptedByHostname(host) {
        return __awaiter(this, void 0, void 0, function* () {
            let secrets = this.decryptedSecrets.filter(secret => {
                var _a;
                return host === new URL((_a = (0, exports.getDecryptedSecretProp)(secret, 'url')) !== null && _a !== void 0 ? _a : '').hostname;
            });
            if (secrets.length === 0) {
                secrets = this.decryptedSecrets.filter(secret => { var _a; return host.endsWith(getTldPart((_a = (0, exports.getDecryptedSecretProp)(secret, 'url')) !== null && _a !== void 0 ? _a : '')); });
            }
            return Promise.all(secrets.map(secret => {
                return this.decryptSecret(secret);
            }));
        });
    }
    getAllSecretsDecrypted() {
        return Promise.all(this.secrets.map(secret => {
            return this.decryptSecret(secret);
        }));
    }
    decryptSecret(secret) {
        return __awaiter(this, void 0, void 0, function* () {
            const decrypted = yield this.decrypt(secret.encrypted);
            let secretDecrypted;
            if (secret.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP) {
                secretDecrypted = Object.assign(Object.assign({}, secret), { totp: JSON.parse(decrypted) });
            }
            else if (secret.kind === graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS) {
                const parsed = JSON.parse(decrypted);
                try {
                    loginCredentialsSchema_1.loginCredentialsSchema.parse(parsed);
                    secretDecrypted = Object.assign({ loginCredentials: parsed }, secret);
                }
                catch (err) {
                    secretDecrypted = Object.assign(Object.assign({}, secret), { loginCredentials: {
                            username: '',
                            password: '',
                            parseError: err,
                            label: parsed.label,
                            url: parsed.url
                        } });
                }
            }
            else {
                throw new Error('Unknown secret type');
            }
            return secretDecrypted;
        });
    }
    /**
     * fetches newly added/deleted/updated secrets from the backend and updates the device state
     */
    backendSync() {
        return __awaiter(this, void 0, void 0, function* () {
            const { data } = yield apolloClient_1.apolloClient.query({
                query: ExtensionDevice_codegen_1.SyncEncryptedSecretsDocument,
                fetchPolicy: 'no-cache'
            });
            if (data) {
                const deviceState = exports.device.state;
                if (data && deviceState) {
                    const backendRemovedSecrets = data.currentDevice.encryptedSecretsToSync.filter(({ deletedAt }) => deletedAt);
                    const newAndUpdatedSecrets = data.currentDevice.encryptedSecretsToSync.filter(({ deletedAt }) => !deletedAt);
                    const secretsBeforeSync = deviceState.secrets;
                    const unchangedSecrets = secretsBeforeSync.filter(({ id }) => !backendRemovedSecrets.find(removedSecret => id === removedSecret.id) && !newAndUpdatedSecrets.find(updatedSecret => id === updatedSecret.id));
                    deviceState.secrets = [...unchangedSecrets, ...newAndUpdatedSecrets];
                    yield this.save();
                    yield apolloClient_1.apolloClient.mutate({
                        mutation: ExtensionDevice_codegen_1.MarkAsSyncedDocument
                    });
                    const actuallyRemovedOnThisDevice = backendRemovedSecrets.filter(({ id: removedId }) => {
                        return secretsBeforeSync.find(({ id }) => removedId === id);
                    });
                    console.log('~ actuallyRemovedOnThisDevice', actuallyRemovedOnThisDevice);
                    return {
                        removedSecrets: actuallyRemovedOnThisDevice.length,
                        newAndUpdatedSecrets: newAndUpdatedSecrets.length
                    };
                }
            }
        });
    }
    //TODO: type this
    findExistingSecret(secret) {
        return __awaiter(this, void 0, void 0, function* () {
            const existingSecretsOnHostname = yield this.getSecretsDecryptedByHostname(new URL(secret.url).hostname);
            return existingSecretsOnHostname.find(s => { var _a; return isLoginSecret(s) && s.loginCredentials.username === ((_a = secret.loginCredentials) === null || _a === void 0 ? void 0 : _a.username) || isTotpSecret(s) && s.totp === secret.totp; });
        });
    }
    /**
     * invokes the backend mutation and pushes the new secret to the bgState
     * @param secrets
     * @returns the added secret in base64
     */
    addSecrets(secrets) {
        return __awaiter(this, void 0, void 0, function* () {
            const encryptedSecrets = yield Promise.all(secrets.map((secret) => __awaiter(this, void 0, void 0, function* () {
                const stringToEncrypt = secret.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP ? JSON.stringify(secret.totp) : JSON.stringify(secret.loginCredentials);
                const encrypted = yield this.encrypt(stringToEncrypt);
                return {
                    encrypted,
                    kind: secret.kind
                };
            })));
            const { data, errors } = yield apolloClient_1.apolloClient.mutate({
                mutation: ExtensionDevice_codegen_1.AddEncryptedSecretsDocument,
                variables: {
                    secrets: encryptedSecrets
                }
            });
            if (errors) {
                console.log('errors', errors);
                throw new Error('Erorror adding secret');
            }
            if (!data) {
                throw new Error('failed to save secret');
            }
            const secretsAdded = data.me.addEncryptedSecrets;
            this.secrets.push(...secretsAdded);
            yield this.save();
            return secretsAdded;
        });
    }
    removeSecret(secretId) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            webextension_polyfill_1.default.storage.local.set({
                backgroundState: Object.assign(Object.assign({}, exports.device.state), { secrets: (_a = exports.device.state) === null || _a === void 0 ? void 0 : _a.secrets.filter(s => s.id !== secretId) })
            });
            this.secrets = this.secrets.filter(s => s.id !== secretId);
            this.save();
        });
    }
    destroy() {
        webextension_polyfill_1.default.storage.onChanged.removeListener(this.onStorageChange);
    }
}
exports.DeviceState = DeviceState;
class ExtensionDevice {
    constructor() {
        this.state = null;
        this.fireToken = null;
        this.lockedState = null;
        this.id = null;
    }
    startLockInterval(lockTime) {
        return __awaiter(this, void 0, void 0, function* () {
            yield exports.extensionDeviceTrpc.setLockInterval.mutate({
                time: lockTime
            });
        });
    }
    clearLockInterval() {
        return __awaiter(this, void 0, void 0, function* () {
            yield exports.extensionDeviceTrpc.clearLockInterval.mutate();
        });
    }
    get platform() {
        return browserInfo.getOSName();
    }
    /**
     * runs on startup
     */
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            (0, exports.log)('Extension device initializing');
            this.id = yield this.getDeviceId();
            let storedState = null;
            const storage = yield webextension_polyfill_1.default.storage.local.get();
            if (storage.backgroundState) {
                storedState = storage.backgroundState;
                (0, exports.log)('device state init from storage', storedState);
            }
            else if (storage.lockedState) {
                this.lockedState = storage.lockedState;
                (0, exports.log)('device state locked', this.lockedState);
            }
            if (storedState) {
                this.state = new DeviceState(storedState);
                this.name = storedState.deviceName;
                this.state.save();
            }
            else {
                this.name = this.generateDeviceName();
                this.listenForUserLogin();
            }
            if (this.state) {
                this.startLockInterval(this.state.lockTime);
            }
            // const fireToken = await generateFireToken()
            const fireToken = 'aaaa';
            this.fireToken = fireToken;
            this.rerenderViews(); // for letting vault/popup know that the state has changed
        });
    }
    listenForUserLogin() {
        this.state = null;
        const onStorageChangeLogin = (changes, areaName) => {
            (0, exports.log)('storage change UL', changes, areaName);
            if (areaName === 'local' && changes.backgroundState) {
                this.state = new DeviceState(changes.backgroundState.newValue);
                webextension_polyfill_1.default.storage.onChanged.removeListener(onStorageChangeLogin);
            }
            else if (areaName === 'local' && changes.lockedState) {
                this.lockedState = changes.lockedState.newValue;
                webextension_polyfill_1.default.storage.onChanged.removeListener(onStorageChangeLogin);
            }
        };
        webextension_polyfill_1.default.storage.onChanged.addListener(onStorageChangeLogin);
    }
    rerenderViews() {
        if (exports.isRunningInBgPage === false) {
            rerenderViewInThisRuntime();
            // browser.runtime.sendMessage({
            //   action: BackgroundMessageType.rerenderViews
            // })
        }
    }
    generateDeviceName() {
        return `${browserInfo.getOSName()} ${browserInfo.getBrowserName()} extension`;
    }
    clearLocalStorage() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const deviceId = yield this.getDeviceId();
            (_a = this.state) === null || _a === void 0 ? void 0 : _a.destroy();
            yield webextension_polyfill_1.default.storage.local.clear();
            this.state = null;
            yield webextension_polyfill_1.default.storage.local.set({
                deviceId: deviceId
            }); // restore deviceId so that we keep it even after logout
        });
    }
    /**
     * @returns a stored deviceId or a new UUID if the extension was just installed
     */
    getDeviceId() {
        return __awaiter(this, void 0, void 0, function* () {
            const storage = yield webextension_polyfill_1.default.storage.local.get('deviceId');
            if (!storage.deviceId) {
                const deviceId = crypto.randomUUID();
                yield webextension_polyfill_1.default.storage.local.set({
                    deviceId: deviceId
                });
                (0, exports.log)('Creating new deviceID', deviceId);
                return deviceId;
            }
            else {
                (0, exports.log)('Got deviceID', storage.deviceId);
                return storage.deviceId;
            }
        });
    }
    generateBackendSecret() {
        const lengthMultiplier = getRandomInt(1, 10);
        let secret = '';
        for (let i = 0; i < lengthMultiplier; i++) {
            secret += Math.random().toString(36).substr(2, 20);
        }
        return secret;
    }
    /**
     * @returns strings in base64
     */
    initLocalDeviceAuthSecret(masterEncryptionKey, salt) {
        return __awaiter(this, void 0, void 0, function* () {
            const authSecret = this.generateBackendSecret();
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const addDeviceSecretAb = yield window.crypto.subtle.encrypt({
                name: 'AES-GCM',
                iv
            }, masterEncryptionKey, generateEncryptionKey_1.enc.encode(authSecret));
            const addDeviceSecretEncrypted = (0, generateEncryptionKey_1.encryptedBuf_to_base64)(addDeviceSecretAb, iv, salt);
            return {
                addDeviceSecret: authSecret,
                addDeviceSecretEncrypted: addDeviceSecretEncrypted
            };
        });
    }
    lock() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.state) {
                throw new Error('no state to lock');
            }
            this.clearLockInterval();
            (0, exports.log)('locking device');
            const { email, userId, secrets, encryptionSalt, lockTime, syncTOTP, autofill, language, theme, authSecret, authSecretEncrypted } = this.state;
            this.lockedState = {
                email,
                userId,
                secrets,
                deviceName: this.name,
                encryptionSalt,
                authSecret,
                authSecretEncrypted,
                lockTime,
                syncTOTP,
                autofill,
                language,
                theme
            };
            yield webextension_polyfill_1.default.storage.local.set({
                lockedState: this.lockedState,
                backgroundState: null
            }); // restore deviceId so that we keep it even after logout
            this.state.destroy();
            this.state = null;
            this.rerenderViews();
        });
    }
    clearAndReload() {
        return __awaiter(this, void 0, void 0, function* () {
            yield (0, accessTokenExtension_1.removeToken)();
            yield exports.device.clearLocalStorage();
            exports.device.rerenderViews(); // TODO figure out if we can have logout without full extensions reload
            exports.device.listenForUserLogin();
            webextension_polyfill_1.default.runtime.reload();
        });
    }
    logout() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield apolloClient_1.apolloClient.mutate({
                    mutation: ExtensionDevice_codegen_1.LogoutDocument
                });
            }
            catch (err) {
                (0, Providers_1.toast)({
                    title: `There was an error logging out: ${err.message} \n., you will need to deauthorize the device manually in device management.`,
                    status: 'error',
                    onCloseComplete: () => {
                        this.clearAndReload();
                    }
                });
            }
            finally {
                yield this.clearAndReload();
            }
            yield this.clearAndReload();
        });
    }
    serializeSecrets(secrets, newPsw) {
        return __awaiter(this, void 0, void 0, function* () {
            const state = this.state;
            if (!state) {
                throw new Error('device not initialized');
            }
            return Promise.all(secrets.map((secret) => __awaiter(this, void 0, void 0, function* () {
                const { id, encrypted, kind } = secret;
                const decr = yield state.decrypt(encrypted);
                (0, exports.log)('decrypted secret', decr);
                yield state.setMasterEncryptionKey(newPsw);
                const enc = yield state.encrypt(decr);
                (0, exports.log)('encrypted secret', enc, state.masterEncryptionKey);
                return {
                    id,
                    encrypted: enc,
                    kind
                };
            })));
        });
    }
    syncSettings(config) {
        var _a;
        if (this.state) {
            this.state.autofill = config.autofill;
            this.state.lockTime = config.vaultLockTimeoutSeconds;
            this.state.syncTOTP = config.syncTOTP;
            this.state.language = config.language;
            this.state.theme = (_a = config.theme) !== null && _a !== void 0 ? _a : 'dark';
        }
    }
    save(deviceState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.state = new DeviceState(deviceState);
            this.state.save();
            this.rerenderViews();
        });
    }
}
(0, exports.log)('Extension device started');
exports.device = new ExtensionDevice();
exports.device.initialize();
// @ts-expect-error TODO fix types
window.extensionDevice = exports.device;


/***/ }),

/***/ 28620:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ColorModeButton = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const fi_1 = __webpack_require__(86893);
const ColorModeButton = () => {
    const { toggleColorMode } = (0, react_1.useColorMode)();
    return (0, jsx_runtime_1.jsx)(react_1.IconButton, { size: "lg", variant: "ghost", "aria-label": "change color mode", icon: (0, jsx_runtime_1.jsx)(fi_1.FiMoon, {}), onClick: () => __awaiter(void 0, void 0, void 0, function* () {
            toggleColorMode();
        }), mt: "auto" });
};
exports.ColorModeButton = ColorModeButton;


/***/ }),

/***/ 54016:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NavBar = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const core_1 = __webpack_require__(20905);
const react_1 = __importStar(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const icons_1 = __webpack_require__(26765);
const wouter_1 = __webpack_require__(17331);
const NavMenu_1 = __webpack_require__(24186);
const UserNavMenu_1 = __webpack_require__(70419);
const io_1 = __webpack_require__(51649);
const RefreshSecretsButton_1 = __webpack_require__(5843);
const NavBar = () => {
    const { isOpen: isNavMenuOpen, onOpen: onNavMenuOpen, onClose: onNavMenuClose } = (0, react_2.useDisclosure)();
    const { isOpen: isUserMenuOpen, onOpen: onUserMenuOpen, onClose: onUserMenuClose } = (0, react_2.useDisclosure)();
    const [location, setLocation] = (0, wouter_1.useLocation)();
    const [lastPage, SetLastPage] = (0, react_1.useState)('/');
    const ActiveLink = props => {
        const [isActive] = (0, wouter_1.useRoute)(props.href);
        return (0, jsx_runtime_1.jsx)(wouter_1.Link, Object.assign({}, props, { children: (0, jsx_runtime_1.jsx)("a", Object.assign({ className: isActive ? 'active' : '' }, { children: props.children })) }));
    };
    const bg = (0, react_2.useColorModeValue)('gray.100', 'gray.800');
    (0, react_1.useEffect)(() => {
        SetLastPage(location);
    }, []);
    return (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDir: "column", position: "fixed", top: "0", w: "100%", backgroundColor: bg, zIndex: 2 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ p: 1, textAlign: "center", fontSize: "16px", borderBottom: "1px", borderBottomColor: "gray.300", width: "100%" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ mr: "auto" }, { children: [isNavMenuOpen ? (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.CloseIcon, {}), onClick: () => {
                                    onNavMenuClose();
                                } }) : (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.HamburgerIcon, {}), onClick: () => {
                                    onNavMenuOpen();
                                    onUserMenuClose();
                                } }), (0, jsx_runtime_1.jsx)(RefreshSecretsButton_1.RefreshSecretsButton, {}), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: /*i18n*/ core_1.i18n._("Open vault"), "aria-label": /*i18n*/ core_1.i18n._("Open vault") }, { children: (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", ml: "2", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(io_1.IoMdArchive, {}), onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                        chrome.tabs.create({
                                            url: 'vault.html'
                                        });
                                    }) }) }))] })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ ml: "auto" }, { children: isUserMenuOpen ? (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.CloseIcon, {}), onClick: () => {
                                onUserMenuClose();
                            } }) : (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.LockIcon, {}), onClick: () => {
                                onUserMenuOpen();
                                onNavMenuClose();
                            } }) }))] })), isNavMenuOpen && (0, jsx_runtime_1.jsx)(NavMenu_1.NavMenu, {}), isUserMenuOpen && (0, jsx_runtime_1.jsx)(UserNavMenu_1.UserNavMenu, {})] }));
};
exports.NavBar = NavBar;


/***/ }),

/***/ 5843:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RefreshSecretsButton = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const react_2 = __webpack_require__(27378);
const react_3 = __webpack_require__(53159);
const io_1 = __webpack_require__(51649);
const ExtensionDevice_1 = __webpack_require__(2247);
function RefreshSecretsButton() {
    const [isSyncing, setIsSyncing] = (0, react_2.useState)(false);
    const toast = (0, react_3.useToast)();
    return (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Synchronize vault" }), "aria-label": /*i18n*/ core_1.i18n._("Synchronize vault") }, { children: (0, jsx_runtime_1.jsx)(react_3.IconButton, { size: "md", ml: "2", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(io_1.IoMdRefreshCircle, {}), disabled: isSyncing, onClick: () => __awaiter(this, void 0, void 0, function* () {
                var _a;
                setIsSyncing(true);
                let res;
                try {
                    res = yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.backendSync());
                }
                catch (error) {
                    setIsSyncing(false);
                    return;
                }
                toast({
                    title: /*i18n*/ core_1.i18n._("Sync successful"),
                    description: `added/updated ${res === null || res === void 0 ? void 0 : res.newAndUpdatedSecrets}, removed ${res === null || res === void 0 ? void 0 : res.removedSecrets}`,
                    status: 'success',
                    position: 'bottom',
                    isClosable: true
                });
                setIsSyncing(false);
            }) }) }));
}
exports.RefreshSecretsButton = RefreshSecretsButton;


/***/ }),

/***/ 77033:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SecretItemIcon = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importDefault(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const bi_1 = __webpack_require__(47516);
function SecretItemIcon(props) {
    let hostname;
    if (props.iconUrl) {
        return (0, jsx_runtime_1.jsx)(react_2.Image, { src: props.iconUrl, maxW: "30px", boxSize: "30px" });
    }
    if (props.url) {
        try {
            hostname = new URL(props.url).hostname;
            return (0, jsx_runtime_1.jsx)(react_2.Image, { src: `https://icons.duckduckgo.com/ip3/${hostname}.ico` // https://stackoverflow.com/a/10796141
                , maxW: "30px", boxSize: "30px" });
        }
        catch (err) {
            return (0, jsx_runtime_1.jsx)(bi_1.BiFileBlank, {});
        }
    }
    return (0, jsx_runtime_1.jsx)(bi_1.BiFileBlank, {});
}
exports.SecretItemIcon = SecretItemIcon;


/***/ }),

/***/ 11687:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokenSecretFromQrCode = exports.AddTOTPSecretButton = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const react_2 = __webpack_require__(53159);
const executeScriptInCurrentTab_1 = __webpack_require__(79565);
const react_3 = __webpack_require__(27378);
const uuid_1 = __webpack_require__(32286);
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const query_string_1 = __importDefault(__webpack_require__(68891));
const DeviceStateProvider_1 = __webpack_require__(58311);
const ExtensionDevice_1 = __webpack_require__(2247);
const getQrCodeFromUrl_1 = __webpack_require__(10285);
const graphqlBaseTypes_1 = __webpack_require__(89931);
const AccountLimits_codegen_1 = __webpack_require__(54417);
const Providers_1 = __webpack_require__(62142);
const AddTOTPSecretButton = () => {
    const { deviceState, TOTPSecrets } = (0, react_3.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { data } = (0, AccountLimits_codegen_1.useMeExtensionQuery)();
    const addToTOTPs = (qr) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        const tab = yield (0, executeScriptInCurrentTab_1.getCurrentTab)();
        const TOTPCount = (_b = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.secrets.filter(s => s.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP).length) !== null && _b !== void 0 ? _b : 0;
        const TOTPLimit = (_d = (_c = data === null || data === void 0 ? void 0 : data.me) === null || _c === void 0 ? void 0 : _c.TOTPlimit) !== null && _d !== void 0 ? _d : 0;
        console.log('TOTPCount', TOTPCount, 'TOTPLimit', TOTPLimit);
        if (TOTPCount >= TOTPLimit) {
            (0, Providers_1.toast)({
                title: /*i18n*/ core_1.i18n._("You have reached your password limit. Please upgrade your account to add more passwords."),
                status: 'error',
                isClosable: true
            });
            console.log('You have reached your password limit. Please upgrade your account to add more passwords.');
            return;
        }
        if (!tab || !deviceState) {
            return;
        }
        const newTotpSecret = yield getTokenSecretFromQrCode(qr, tab);
        const existingTotpSecret = TOTPSecrets.find(({ totp }) => newTotpSecret.totp.secret === totp.secret);
        if (existingTotpSecret) {
            (0, Providers_1.toast)({
                title: /*i18n*/ core_1.i18n._("This TOTP secret is already in your vault"),
                status: 'success',
                isClosable: true
            });
        }
        else {
            yield ((_e = ExtensionDevice_1.device.state) === null || _e === void 0 ? void 0 : _e.addSecrets([newTotpSecret]));
            (0, Providers_1.toast)({
                title: /*i18n*/ core_1.i18n._("Successfully added TOTP for {0}", {
                    0: newTotpSecret.totp.label
                }),
                status: 'success',
                isClosable: true
            });
        }
    });
    return (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ className: "btn btn-block btn-outline-dark", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
            const src = yield webextension_polyfill_1.default.tabs.captureVisibleTab();
            const qr = yield (0, getQrCodeFromUrl_1.getQrCodeFromUrl)(src);
            if (qr) {
                addToTOTPs(qr);
            }
            else {
                (0, Providers_1.toast)({
                    title: /*i18n*/ core_1.i18n._("could not find any QR code on this page. Make sure QR code is visible."),
                    status: 'error',
                    isClosable: true
                });
            }
        }) }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Add QR TOTP" }) }));
};
exports.AddTOTPSecretButton = AddTOTPSecretButton;
function getTokenSecretFromQrCode(qr, tab) {
    var _a, _b;
    return __awaiter(this, void 0, void 0, function* () {
        const parsedQuery = query_string_1.default.parseUrl(qr.data);
        const secret = parsedQuery.query.secret;
        if (!secret) {
            console.error('QR code does not have any secret', qr.data);
            throw new Error('QR code does not have any secret');
        }
        let encrypted = yield ExtensionDevice_1.device.state.encrypt(secret);
        return {
            id: (0, uuid_1.v4)(),
            kind: graphqlBaseTypes_1.EncryptedSecretType.TOTP,
            totp: {
                secret: secret,
                digits: 6,
                period: 30,
                iconUrl: (_a = tab.favIconUrl) !== null && _a !== void 0 ? _a : null,
                label: (_b = parsedQuery.query.issuer) !== null && _b !== void 0 ? _b : decodeURIComponent(parsedQuery.url.replace('otpauth://totp/', '')),
                url: tab.url
            },
            createdAt: new Date().toJSON(),
            encrypted
        };
    });
}
exports.getTokenSecretFromQrCode = getTokenSecretFromQrCode;


/***/ }),

/***/ 81906:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useAddOtpEventMutation = exports.AddOtpEventDocument = void 0;
const client_1 = __webpack_require__(17547);
const Apollo = __importStar(__webpack_require__(17547));
const defaultOptions = {};
exports.AddOtpEventDocument = (0, client_1.gql) `
    mutation addOTPEvent($event: SecretUsageEventInput!) {
  me {
    createSecretUsageEvent(event: $event) {
      id
    }
  }
}
    `;
/**
 * __useAddOtpEventMutation__
 *
 * To run a mutation, you first call `useAddOtpEventMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAddOtpEventMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [addOtpEventMutation, { data, loading, error }] = useAddOtpEventMutation({
 *   variables: {
 *      event: // value for 'event'
 *   },
 * });
 */
function useAddOtpEventMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.AddOtpEventDocument, options);
}
exports.useAddOtpEventMutation = useAddOtpEventMutation;


/***/ }),

/***/ 19427:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthsList = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const core_1 = __webpack_require__(20905);
const react_1 = __importStar(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const otplib_1 = __webpack_require__(77778);
const icons_1 = __webpack_require__(26765);
const react_3 = __webpack_require__(53159);
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const DeviceStateProvider_1 = __webpack_require__(58311);
const debug_1 = __importDefault(__webpack_require__(96292));
const SecretItemIcon_1 = __webpack_require__(77033);
const extractHostname_1 = __webpack_require__(53557);
const AuthList_codegen_1 = __webpack_require__(81906);
const log = (0, debug_1.default)('au:AuthsList');
const OtpCode = ({ totpSecret }) => {
    const [addOTPEvent, { data, error }] = (0, AuthList_codegen_1.useAddOtpEventMutation)(); //ignore results??
    // const otpCode = '1111'
    const otpCode = otplib_1.authenticator.generate(totpSecret.totp.secret);
    const [showWhole, setShowWhole] = (0, react_1.useState)(false);
    const { onCopy } = (0, react_2.useClipboard)(otpCode);
    (0, react_1.useEffect)(() => {
        setShowWhole(false);
    }, [otpCode]);
    return (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ p: "3", m: 1, rounded: "md", bg: (0, react_2.useColorModeValue)('gray.100', 'gray.700'), minW: "300px" }, { children: (0, jsx_runtime_1.jsx)(react_2.Stat, Object.assign({ maxW: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ justify: "space-between", align: "center", w: "100%" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: (0, jsx_runtime_1.jsx)(SecretItemIcon_1.SecretItemIcon, Object.assign({}, totpSecret.totp)) })), (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ ml: 4, mr: "auto" }, { children: [(0, jsx_runtime_1.jsx)(react_2.StatLabel, { children: totpSecret.totp.label }), (0, jsx_runtime_1.jsx)(react_2.StatNumber, Object.assign({ onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                    setShowWhole(!showWhole);
                                    if (!showWhole) {
                                        // CHECK
                                        const tabs = yield webextension_polyfill_1.default.tabs.query({
                                            active: true
                                        });
                                        const url = tabs[0].url;
                                        yield addOTPEvent({
                                            variables: {
                                                event: {
                                                    kind: 'show OTP',
                                                    url: url,
                                                    secretId: totpSecret.id
                                                }
                                            }
                                        });
                                        log(data, error);
                                    }
                                }) }, { children: showWhole ? otpCode : (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: /*i18n*/ core_1.i18n._("Click to show the whole") }, { children: otpCode.substr(0, 3) + '***' })) }))] })), (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: /*i18n*/ core_1.i18n._("Copy TOTP") }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ size: "md", ml: 2, variant: "solid", colorScheme: 'cyan', onClick: () => {
                                onCopy();
                                // TODO log usage of this token to backend
                            } }, { children: (0, jsx_runtime_1.jsx)(icons_1.CopyIcon, {}) })) }))] })) })) }));
};
const LoginCredentialsListItem = ({ loginSecret }) => {
    const { loginCredentials } = loginSecret;
    const { onCopy } = (0, react_2.useClipboard)(loginCredentials.password);
    return (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ boxShadow: "xl", m: 2 }, { children: (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ p: "3", rounded: "md", bg: (0, react_2.useColorModeValue)('gray.100', 'gray.700') }, { children: (0, jsx_runtime_1.jsx)(react_2.Stat, Object.assign({ maxW: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ justify: "space-between", align: "center", w: "100%" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: (0, jsx_runtime_1.jsx)(SecretItemIcon_1.SecretItemIcon, Object.assign({}, loginCredentials)) })), (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ ml: 2, mr: "auto", maxW: "200px" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "sm", whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }, { children: loginCredentials.label })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "sm", whiteSpace: "nowrap" }, { children: loginCredentials.username.replace(/http:\/\/|https:\/\//, '') }))] })), (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: /*i18n*/ core_1.i18n._("Copy password") }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ size: "md", ml: "auto", boxShadow: "md", variant: "solid", color: 'green.700', bgColor: 'green.200', onClick: () => {
                                    onCopy();
                                    // TODO log usage of this token to backend
                                } }, { children: (0, jsx_runtime_1.jsx)(icons_1.CopyIcon, {}) })) }))] })) })) }), loginCredentials.url) }));
};
const AuthsList = ({ filterByTLD }) => {
    const { deviceState, TOTPSecrets, loginCredentials, currentURL } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    if (!deviceState) {
        return null;
    }
    const TOTPForCurrentDomain = TOTPSecrets.filter(({ totp }) => {
        if (!currentURL || !totp.url) {
            return true;
        }
        return (0, extractHostname_1.extractHostname)(totp.url) === (0, extractHostname_1.extractHostname)(currentURL);
    });
    const loginCredentialForCurrentDomain = loginCredentials.filter(({ loginCredentials }) => {
        if (!loginCredentials.url) {
            return false; // for example TOTP secrets do not have any URL after import from authy
        }
        if (!currentURL) {
            return true;
        }
        return (0, extractHostname_1.extractHostname)(loginCredentials.url) === (0, extractHostname_1.extractHostname)(currentURL);
    });
    const hasNoSecrets = deviceState.secrets.length === 0;
    const getRecentlyUsed = secrets => {
        return secrets.sort((a, b) => { var _a, _b; return ((_a = a.lastUsedAt) !== null && _a !== void 0 ? _a : a.createdAt) >= ((_b = b.lastUsedAt) !== null && _b !== void 0 ? _b : b.createdAt) ? 1 : -1; }).slice(0, 20); // we get items
    };
    return (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: [hasNoSecrets === false && filterByTLD && TOTPForCurrentDomain.length === 0 && loginCredentialForCurrentDomain.length === 0 && (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_2.Text, { children: [(0, jsx_runtime_1.jsx)(icons_1.NotAllowedIcon, {}), "There are no stored secrets for current domain."] }) }), filterByTLD ? (0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [TOTPForCurrentDomain.map((auth, i) => {
                            return (0, jsx_runtime_1.jsx)(OtpCode, { totpSecret: auth }, auth.totp.label + i);
                        }), loginCredentialForCurrentDomain.map((credentials, i) => {
                            console.log('credentials', credentials);
                            return (0, jsx_runtime_1.jsx)(LoginCredentialsListItem, { loginSecret: credentials }, credentials.loginCredentials.label + i);
                        })] }) : [getRecentlyUsed(TOTPSecrets).map((auth, i) => {
                        return (0, jsx_runtime_1.jsx)(OtpCode, { totpSecret: auth }, auth.totp.label + i);
                    }), getRecentlyUsed(loginCredentials).map((psw, i) => {
                        // console.log(psw.loginCredentials.url)
                        return (0, jsx_runtime_1.jsx)(LoginCredentialsListItem, { loginSecret: psw }, psw.loginCredentials.label + i);
                    })], hasNoSecrets &&
                    // TODO login form illustration
                    (0, jsx_runtime_1.jsx)(react_2.Text, { children: "Start by adding a secret by logging onto any website or by adding a TOTP code" })] })) });
};
exports.AuthsList = AuthsList;


/***/ }),

/***/ 23961:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NbSp = void 0;
/**
 *  just non breaking space for JSX from https://stackoverflow.com/a/54485712/671457
 *  JSX is weird with &nbsp; even though people claim otherwise
 */
const NbSp = () => '\u00A0';
exports.NbSp = NbSp;


/***/ }),

/***/ 34605:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DeleteAlert = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_2 = __importDefault(__webpack_require__(27378));
function DeleteAlert({ isOpen, onClose, deleteItem }) {
    const cancelRef = react_2.default.useRef();
    return (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_1.AlertDialog, Object.assign({ motionPreset: "slideInBottom", 
            //@ts-expect-error
            leastDestructiveRef: cancelRef, onClose: onClose, isOpen: isOpen, isCentered: true }, { children: [(0, jsx_runtime_1.jsx)(react_1.AlertDialogOverlay, {}), (0, jsx_runtime_1.jsxs)(react_1.AlertDialogContent, { children: [(0, jsx_runtime_1.jsx)(react_1.AlertDialogHeader, { children: "Delete confirmation" }), (0, jsx_runtime_1.jsx)(react_1.AlertDialogCloseButton, {}), (0, jsx_runtime_1.jsx)(react_1.AlertDialogBody, Object.assign({ fontSize: 20 }, { children: "Are you sure you want to delete this item?" })), (0, jsx_runtime_1.jsxs)(react_1.AlertDialogFooter, { children: [(0, jsx_runtime_1.jsx)(react_1.Button
                                //@ts-expect-error
                                , Object.assign({ 
                                    //@ts-expect-error
                                    ref: cancelRef, onClick: onClose }, { children: "No" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ colorScheme: "red", ml: 3, onClick: () => {
                                        onClose();
                                        deleteItem();
                                    } }, { children: "Yes" }))] })] })] })) });
}
exports.DeleteAlert = DeleteAlert;


/***/ }),

/***/ 47529:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DeviceDeleteAlert = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_2 = __webpack_require__(53159);
const icons_1 = __webpack_require__(26765);
const react_3 = __importStar(__webpack_require__(27378));
const react_4 = __webpack_require__(53159);
const AccountDevices_codegen_1 = __webpack_require__(8756);
function DeviceDeleteAlert({ isOpen, id, onClose }) {
    const { refetch: devicesRefetch } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    const cancelRef = (0, react_3.useRef)();
    const [remove, setRemove] = (0, react_3.useState)(false);
    const [logoutDevice] = (0, AccountDevices_codegen_1.useLogoutDeviceMutation)({
        variables: {
            id: id
        }
    });
    const [removeDevice] = (0, AccountDevices_codegen_1.useRemoveDeviceMutation)({
        variables: {
            id: id
        }
    });
    return (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_2.AlertDialog, Object.assign({ motionPreset: "slideInBottom", 
            //@ts-expect-error TODO: fix this
            leastDestructiveRef: cancelRef, onClose: onClose, isOpen: isOpen, isCentered: true }, { children: [(0, jsx_runtime_1.jsx)(react_2.AlertDialogOverlay, {}), (0, jsx_runtime_1.jsxs)(react_2.AlertDialogContent, { children: [(0, jsx_runtime_1.jsx)(react_2.AlertDialogHeader, { children: "Logout confirmation" }), (0, jsx_runtime_1.jsx)(react_2.AlertDialogCloseButton, {}), (0, jsx_runtime_1.jsxs)(react_2.AlertDialogBody, Object.assign({ fontSize: 20 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, { children: "Are you sure you want to logout this device?" }), (0, jsx_runtime_1.jsxs)(react_4.HStack, { children: [(0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({ isChecked: remove, onChange: () => setRemove(!remove) }, { children: "Remove device from list" })), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: "You will have to confirm login", fontSize: "sm" }, { children: (0, jsx_runtime_1.jsx)(icons_1.QuestionOutlineIcon, {}) }))] })] })), (0, jsx_runtime_1.jsxs)(react_2.AlertDialogFooter, { children: [(0, jsx_runtime_1.jsx)(react_2.Button
                                //@ts-expect-error TODO: fix this
                                , Object.assign({ 
                                    //@ts-expect-error TODO: fix this
                                    ref: cancelRef, onClick: onClose }, { children: "No" })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ colorScheme: "red", ml: 3, onClick: () => __awaiter(this, void 0, void 0, function* () {
                                        if (remove) {
                                            yield removeDevice();
                                        }
                                        else {
                                            yield logoutDevice();
                                        }
                                        onClose();
                                        devicesRefetch();
                                    }) }, { children: "Yes" }))] })] })] })) });
}
exports.DeviceDeleteAlert = DeviceDeleteAlert;


/***/ }),

/***/ 12235:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ExportLoginCredentialsToCsvButton = exports.ExportTOTPToCsvButton = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __webpack_require__(53159);
const react_3 = __importStar(__webpack_require__(27378));
const papaparse_1 = __importDefault(__webpack_require__(46381));
const downloadAsFile_1 = __webpack_require__(24282);
const DeviceStateProvider_1 = __webpack_require__(58311);
const ExportTOTPToCsvButton = () => {
    const { TOTPSecrets } = (0, react_3.useContext)(DeviceStateProvider_1.DeviceStateContext);
    return (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ mt: 4, minW: "300px", colorScheme: "teal", type: "submit", onClick: () => {
            const csv = papaparse_1.default.unparse(TOTPSecrets);
            (0, downloadAsFile_1.downloadAsFile)(csv, 'totp');
        } }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Export TOTP to CSV" }) }));
};
exports.ExportTOTPToCsvButton = ExportTOTPToCsvButton;
const ExportLoginCredentialsToCsvButton = () => {
    const { loginCredentials: LoginCredentials } = (0, react_3.useContext)(DeviceStateProvider_1.DeviceStateContext);
    return (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ mt: 4, minW: "300px", colorScheme: "teal", type: "submit", onClick: () => {
            // Call here export mutation for export notification
            const csv = papaparse_1.default.unparse(LoginCredentials.map(({ id, loginCredentials }) => ({
                id,
                url: loginCredentials.url,
                label: loginCredentials.label,
                username: loginCredentials.username,
                password: loginCredentials.password
            })));
            (0, downloadAsFile_1.downloadAsFile)(csv, 'credentials');
        } }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Export Login Credentials to CSV" }) }));
};
exports.ExportLoginCredentialsToCsvButton = ExportLoginCredentialsToCsvButton;


/***/ }),

/***/ 37251:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ImportFromFile = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importDefault(__webpack_require__(27378));
const react_2 = __webpack_require__(27378);
const react_dropzone_1 = __webpack_require__(14265);
const react_3 = __webpack_require__(53159);
const ai_1 = __webpack_require__(8193);
function ImportFromFile({ onFileAccepted }) {
    const onDrop = (0, react_2.useCallback)(acceptedFiles => {
        onFileAccepted(acceptedFiles[0]);
    }, [onFileAccepted]);
    const { getRootProps, getInputProps, isDragActive } = (0, react_dropzone_1.useDropzone)({
        onDrop,
        accept: {
            'text/*': ['.csv', '.json']
        },
        maxFiles: 1,
        multiple: false
    });
    const dropText = isDragActive ? 'Drop the files here ...' : "Drag 'n' drop .csv, json file here, or click to select files";
    const activeBg = (0, react_3.useColorModeValue)('gray.100', 'gray.600');
    const borderColor = (0, react_3.useColorModeValue)(isDragActive ? 'teal.300' : 'gray.300', isDragActive ? 'teal.500' : 'gray.500');
    return (0, jsx_runtime_1.jsxs)(react_3.Center, Object.assign({ p: 10, cursor: "pointer", bg: isDragActive ? activeBg : 'transparent', _hover: {
            bg: activeBg
        }, transition: "background-color 0.2s ease", borderRadius: 4, border: "3px dashed", borderColor: borderColor }, getRootProps(), { children: [(0, jsx_runtime_1.jsx)("input", Object.assign({}, getInputProps())), (0, jsx_runtime_1.jsx)(react_3.Icon, { as: ai_1.AiFillFileAdd, mr: 2, boxSize: 20 }), (0, jsx_runtime_1.jsx)("p", { children: dropText })] }));
}
exports.ImportFromFile = ImportFromFile;


/***/ }),

/***/ 78073:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VaultItemSettings = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __webpack_require__(53159);
const react_3 = __webpack_require__(27378);
const react_router_dom_1 = __webpack_require__(36634);
const check_password_strength_1 = __webpack_require__(64702);
const icons_1 = __webpack_require__(26765);
const PasswordGenerator_1 = __webpack_require__(53883);
const ExtensionDevice_1 = __webpack_require__(2247);
const EncryptedSecrets_codegen_1 = __webpack_require__(98533);
const formik_1 = __webpack_require__(99590);
const framer_motion_1 = __webpack_require__(10238);
const formikSharedTypes_1 = __webpack_require__(28091);
const TOTPSecret = secretProps => {
    const { totp } = secretProps;
    const navigate = (0, react_router_dom_1.useNavigate)();
    const [updateSecret] = (0, EncryptedSecrets_codegen_1.useUpdateEncryptedSecretMutation)();
    const [show, setShow] = (0, react_3.useState)(false);
    const bg = (0, react_2.useColorModeValue)('white', 'gray.800');
    return (0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: {
            opacity: 1
        }, initial: {
            opacity: 0
        }, exit: {
            opacity: 0
        }, transition: {
            duration: 0.35
        }, style: {
            width: '80%',
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ width: {
                base: '90%',
                sm: '70%',
                md: '60%',
                lg: '40%',
                xl: '30%'
            }, mt: 4, flexDirection: "column", boxShadow: '2xl', rounded: 'md', overflow: 'hidden', m: "auto", alignItems: 'center', bg: bg }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                    secret: totp.secret,
                    url: totp.url,
                    label: totp.label,
                    digits: totp.digits,
                    period: totp.period
                }, validationSchema: formikSharedTypes_1.TOTPSchema, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                    var _a, _b;
                    const secret = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.secrets.find(({ id }) => id === secretProps.id);
                    if (secret && ExtensionDevice_1.device.state) {
                        secret.encrypted = yield ExtensionDevice_1.device.state.encrypt(JSON.stringify(Object.assign(Object.assign({}, values), { iconUrl: '', digits: 6, period: 30 })));
                        yield updateSecret({
                            variables: {
                                id: secret.id,
                                patch: {
                                    encrypted: secret.encrypted,
                                    kind: secret.kind
                                }
                            }
                        });
                        yield ((_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.save());
                        setSubmitting(false);
                    }
                }) }, { children: ({ isSubmitting, dirty, handleSubmit, errors, touched }) => (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ width: '80%', mt: 5 }, { children: (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.secret && touched.secret }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "secret" }, { children: "Secret:" })), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { id: "secret", pr: "4.5rem", type: show ? 'text' : 'password', as: react_2.Input, name: "secret" }), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShow(!show) }, { children: show ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.secret })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.digits && touched.digits }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "digits" }, { children: "Digits:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "digits", name: "digits" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.digits })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.period && touched.period }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "period" }, { children: "Period:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "period", name: "period" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.period })] })), (0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ _focus: {
                                                bg: 'gray.200'
                                            }, fontSize: 'sm', size: "sm", onClick: () => navigate(-1) }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                                bg: 'blue.500'
                                            }, _focus: {
                                                bg: 'blue.500'
                                            }, "aria-label": "Save" }, { children: "Save" }))] }))] })) })) })) })) })) }));
};
const LoginSecret = secretProps => {
    const navigate = (0, react_router_dom_1.useNavigate)();
    const [show, setShow] = (0, react_3.useState)(false);
    const { isOpen, onToggle } = (0, react_2.useDisclosure)();
    const handleClick = () => setShow(!show);
    const [initPassword, setInitPassword] = (0, react_3.useState)('');
    const [updateSecret] = (0, EncryptedSecrets_codegen_1.useUpdateEncryptedSecretMutation)();
    return (0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: {
            opacity: 1
        }, initial: {
            opacity: 0
        }, exit: {
            opacity: 0
        }, transition: {
            duration: 0.35
        }, style: {
            width: '80%',
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ width: {
                base: '90%',
                sm: '70%',
                md: '60%',
                lg: '40%',
                xl: '30%'
            }, mt: 4, flexDirection: "column", boxShadow: '2xl', rounded: 'md', overflow: 'hidden', m: "auto", alignItems: 'center', bg: (0, react_2.useColorModeValue)('white', 'gray.800') }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ enableReinitialize: true, initialValues: {
                        url: secretProps.loginCredentials.url,
                        password: initPassword === '' ? secretProps.loginCredentials.password : initPassword,
                        label: secretProps.loginCredentials.label,
                        username: secretProps.loginCredentials.username
                    }, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                        var _a, _b;
                        const secret = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.secrets.find(({ id }) => id === secretProps.id);
                        if (secret && ExtensionDevice_1.device.state) {
                            secret.encrypted = yield ExtensionDevice_1.device.state.encrypt(JSON.stringify({
                                password: values.password,
                                username: values.username,
                                url: values.url,
                                label: values.label,
                                iconUrl: null
                            }));
                            yield updateSecret({
                                variables: {
                                    id: secretProps.id,
                                    patch: {
                                        encrypted: secret.encrypted,
                                        kind: secretProps.kind
                                    }
                                }
                            });
                            yield ((_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.save());
                            setSubmitting(false);
                        }
                    }) }, { children: ({ values, isSubmitting, dirty, handleSubmit, errors, touched }) => {
                        const levelOfPsw = (0, check_password_strength_1.passwordStrength)(values.password);
                        return (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ w: '80%' }, { children: (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ mt: 3, flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.username && touched.username }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "username" }, { children: "Username:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "username", name: "username" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.username })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.password && touched.password }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password:" })), (0, jsx_runtime_1.jsx)(react_2.Progress, { value: levelOfPsw.id, size: "xs", colorScheme: "green", max: 3, min: 0, mb: 1 }), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "password", name: "password", pr: "4.5rem", type: show ? 'text' : 'password' }), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: handleClick }, { children: show ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.password })] })), secretProps.loginCredentials.parseError && (0, jsx_runtime_1.jsxs)(react_2.Alert, Object.assign({ status: "error", mt: 4 }, { children: [(0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Failed to parse this secret:" }), JSON.stringify(secretProps.loginCredentials.parseError)] })), (0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ _focus: {
                                                        bg: 'gray.200'
                                                    }, fontSize: 'sm', size: "sm", onClick: () => navigate(-1) }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                                        bg: 'blue.500'
                                                    }, _focus: {
                                                        bg: 'blue.500'
                                                    }, "aria-label": "Save" }, { children: "Save" }))] }))] })) })) }));
                    } })), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: "Password generator" }, { children: (0, jsx_runtime_1.jsx)(react_2.IconButton, { w: "min-content", "aria-label": "Open password generator", icon: isOpen ? (0, jsx_runtime_1.jsx)(icons_1.ChevronUpIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ChevronDownIcon, {}), onClick: onToggle, m: 3 }) })), (0, jsx_runtime_1.jsx)(PasswordGenerator_1.PasswordGenerator, { isOpen: isOpen, setInitPassword: setInitPassword })] })) }));
};
const VaultItemSettings = () => {
    const [secret, setSecret] = (0, react_3.useState)(null);
    const params = (0, react_router_dom_1.useParams)();
    (0, react_3.useEffect)(() => {
        function loadSecret() {
            var _a;
            return __awaiter(this, void 0, void 0, function* () {
                const secret = yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.getSecretDecryptedById(params.secretId));
                setSecret(secret);
            });
        }
        loadSecret();
    }, []);
    if (!ExtensionDevice_1.device.state && !secret) {
        return (0, jsx_runtime_1.jsx)(react_2.Spinner, {});
    }
    if (!secret) {
        return (0, jsx_runtime_1.jsx)(react_2.Alert, { children: "Could not find this secret, it may be deleted" });
    }
    console.log('secret', secret);
    if (secret.kind === 'TOTP') {
        return (0, jsx_runtime_1.jsx)(TOTPSecret, Object.assign({}, secret));
    }
    else if (secret.kind === 'LOGIN_CREDENTIALS') {
        return (0, jsx_runtime_1.jsx)(LoginSecret, Object.assign({}, secret));
    }
    return null;
};
exports.VaultItemSettings = VaultItemSettings;


/***/ }),

/***/ 53883:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PasswordGenerator = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importDefault(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const generate_password_1 = __webpack_require__(77725);
const formik_1 = __webpack_require__(99590);
const PasswordGenerator = ({ isOpen, setInitPassword }) => {
    return (
    //@ts-ignore TODO: fix this
    (0, jsx_runtime_1.jsx)(react_2.Collapse, Object.assign({ in: isOpen, animateOpacity: true }, { children: (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: "column", justifyContent: "center", alignItems: "center", m: 2 }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                    numbers: false,
                    symbols: false,
                    uppercase: true,
                    lowercase: true,
                    length: 8
                }, onSubmit: (values, { setSubmitting }) => {
                    setInitPassword((0, generate_password_1.generate)(Object.assign({}, values)));
                    setSubmitting(false);
                } }, { children: ({ isSubmitting }) => (0, jsx_runtime_1.jsx)(formik_1.Form, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ justifyContent: "center", flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.HStack, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "numbers" }, { children: ({ field }) => (0, jsx_runtime_1.jsx)(react_2.Checkbox, Object.assign({ id: "numbers", name: "numbers" }, field, { children: "numbers" })) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "symbols" }, { children: ({ field }) => (0, jsx_runtime_1.jsx)(react_2.Checkbox, Object.assign({ id: "symbols", name: "symbols" }, field, { children: "symbols" })) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "uppercase" }, { children: ({ field }) => (0, jsx_runtime_1.jsx)(react_2.Checkbox, Object.assign({ id: "uppercase", name: "uppercase" }, field, { defaultChecked: true }, { children: "uppercase" })) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "lowercase" }, { children: ({ field }) => (0, jsx_runtime_1.jsx)(react_2.Checkbox, Object.assign({ id: "lowercase", name: "lowercase" }, field, { defaultChecked: true }, { children: "lowercase" })) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "length" }, { children: ({ field, form }) => (0, jsx_runtime_1.jsxs)(react_2.NumberInput, Object.assign({ id: "length", name: "length", size: "md", maxW: 20, defaultValue: 8, min: 5, onChange: val => {
                                                form.setFieldValue(field.name, parseInt(val));
                                            } }, { children: [(0, jsx_runtime_1.jsx)(react_2.NumberInputField, {}), (0, jsx_runtime_1.jsxs)(react_2.NumberInputStepper, { children: [(0, jsx_runtime_1.jsx)(react_2.NumberIncrementStepper, {}), (0, jsx_runtime_1.jsx)(react_2.NumberDecrementStepper, {})] })] })) }))] }), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ w: 150, alignSelf: "center", mt: 4, colorScheme: "teal", isLoading: isSubmitting, type: "submit" }, { children: "Generate" }))] })) }) })) })) })));
};
exports.PasswordGenerator = PasswordGenerator;


/***/ }),

/***/ 22356:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importDefault(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const ExtensionDevice_1 = __webpack_require__(2247);
const crypto_js_1 = __webpack_require__(76679);
const page_url = "http://localhost:5450/";
function ProfileCard() {
    var _a;
    const email = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.email;
    return (0, jsx_runtime_1.jsx)(react_2.Center, Object.assign({ py: 6 }, { children: (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ maxW: '320px', w: 'full', bg: (0, react_2.useColorModeValue)('white', 'gray.800'), boxShadow: '2xl', rounded: 'lg', p: 6, textAlign: 'center' }, { children: [(0, jsx_runtime_1.jsx)(react_2.Avatar, { size: 'xl', src: `https://www.gravatar.com/avatar/${(0, crypto_js_1.MD5)(email)}}`, mb: 4, pos: 'relative', _after: {
                        content: '""',
                        w: 4,
                        h: 4,
                        bg: 'green.300',
                        border: '2px solid white',
                        rounded: 'full',
                        pos: 'absolute',
                        bottom: 0,
                        right: 3
                    } }), (0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ fontSize: '2xl', fontFamily: 'body' }, { children: email })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ onClick: () => chrome.tabs.create({
                        url: `${page_url}/pricing?portal=true`
                    }), mt: 8, flex: 1, fontSize: 'sm', rounded: 'full', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                        bg: 'blue.500'
                    }, _focus: {
                        bg: 'blue.500'
                    } }, { children: "Subscriptions" }))] })) }));
}
exports["default"] = ProfileCard;


/***/ }),

/***/ 86111:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RefreshDeviceButton = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const react_2 = __importStar(__webpack_require__(27378));
const react_3 = __webpack_require__(53159);
const io_1 = __webpack_require__(51649);
const react_toastify_1 = __webpack_require__(21779);
const AccountDevices_codegen_1 = __webpack_require__(8756);
function RefreshDeviceButton() {
    const [isSyncing, setIsSyncing] = (0, react_2.useState)(false);
    const { refetch: devicesRequestsRefetch } = (0, AccountDevices_codegen_1.useDevicesRequestsQuery)();
    const { refetch: devicesRefetch } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    return (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Synchronize devices" }), "aria-label": /*i18n*/ core_1.i18n._("Synchronize devices") }, { children: (0, jsx_runtime_1.jsx)(react_3.IconButton, { size: "md", ml: "2", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(io_1.IoMdRefreshCircle, {}), disabled: isSyncing, onClick: () => __awaiter(this, void 0, void 0, function* () {
                setIsSyncing(true);
                devicesRefetch();
                devicesRequestsRefetch();
                setIsSyncing(false);
                react_toastify_1.toast.success(/*i18n*/ core_1.i18n._("Sync successful"));
            }) }) }));
}
exports.RefreshDeviceButton = RefreshDeviceButton;


/***/ }),

/***/ 4883:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __importDefault(__webpack_require__(27378));
const react_3 = __webpack_require__(53159);
const fi_1 = __webpack_require__(86893);
const react_router_dom_1 = __webpack_require__(36634);
const ExtensionDevice_1 = __webpack_require__(2247);
const md5_1 = __importDefault(__webpack_require__(74678));
const icons_1 = __webpack_require__(26765);
const ColorModeButton_1 = __webpack_require__(28620);
const LinkItems = [{
        title: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Vault" }),
        icon: fi_1.FiHome,
        path: '/'
    }, {
        title: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Settings" }),
        icon: fi_1.FiSettings,
        path: '/settings/account'
    }, {
        title: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Account Limits" }),
        icon: fi_1.FiStar,
        path: '/account-limits'
    }, {
        title: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Devices" }),
        icon: fi_1.FiHardDrive,
        path: '/devices'
    }, {
        title: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Import & Export" }),
        icon: fi_1.FiDisc,
        path: '/import-export'
    }];
function SidebarWithHeader({ children }) {
    const { isOpen, onOpen, onClose } = (0, react_3.useDisclosure)();
    return (0, jsx_runtime_1.jsxs)(react_3.Box, Object.assign({ minH: "100vh", bg: (0, react_3.useColorModeValue)('gray.50', 'gray.900') }, { children: [(0, jsx_runtime_1.jsx)(SidebarContent, { onClose: () => onClose, display: {
                    base: 'none',
                    md: 'block'
                } }), (0, jsx_runtime_1.jsx)(react_3.Drawer, Object.assign({ autoFocus: false, isOpen: isOpen, placement: "left", onClose: onClose, returnFocusOnClose: false, onOverlayClick: onClose, size: "full" }, { children: (0, jsx_runtime_1.jsx)(react_3.DrawerContent, { children: (0, jsx_runtime_1.jsx)(SidebarContent, { onClose: onClose }) }) })), (0, jsx_runtime_1.jsx)(MobileNav, { display: {
                    base: 'flex',
                    md: 'none'
                }, onOpen: onOpen }), (0, jsx_runtime_1.jsx)(react_3.Box, Object.assign({ ml: {
                    base: 0,
                    md: 60
                }, p: "7" }, { children: children }))] }));
}
exports["default"] = SidebarWithHeader;
const SidebarContent = (_a) => {
    var _b;
    var { onClose } = _a, rest = __rest(_a, ["onClose"]);
    const email = (_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.email;
    if (!email) {
        return (0, jsx_runtime_1.jsx)(react_3.Spinner, {});
    }
    return (0, jsx_runtime_1.jsx)(react_3.Flex, Object.assign({ transition: "1s ease", bg: (0, react_3.useColorModeValue)('white', 'gray.800'), borderRight: "1px", borderRightColor: (0, react_3.useColorModeValue)('gray.200', 'gray.700'), w: {
            base: 'full',
            md: 60
        }, pos: "fixed", h: "full", flexDirection: "column", alignItems: "center" }, rest, { children: (0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ justifyContent: 'flex-end', flexDirection: "column", height: "inherit" }, { children: [(0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ h: "20", alignItems: "center", mx: "8", justifyContent: "space-between" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ fontSize: "2xl", fontFamily: "monospace", fontWeight: "bold" }, { children: "Authier" })), (0, jsx_runtime_1.jsx)(react_3.CloseButton, { display: {
                                base: 'flex',
                                md: 'none'
                            }, onClick: onClose })] })), (0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ flexDirection: "column", height: "100%" }, { children: [LinkItems.map((link, i) => (0, jsx_runtime_1.jsx)(NavItem, Object.assign({ icon: link.icon, path: link.path }, { children: link.title }), i)), (0, jsx_runtime_1.jsx)(ColorModeButton_1.ColorModeButton, {})] })), (0, jsx_runtime_1.jsx)(react_3.HStack, Object.assign({ spacing: {
                        base: '0',
                        md: '6'
                    }, w: "80%", m: 4 }, { children: (0, jsx_runtime_1.jsx)(react_3.Flex, Object.assign({ alignItems: 'center', w: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_3.Menu, { children: [(0, jsx_runtime_1.jsx)(react_3.MenuButton, Object.assign({ py: 2, transition: "all 0.3s", _focus: {
                                        boxShadow: 'none'
                                    }, w: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ w: "100%" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Avatar, { size: 'sm', src: `https://www.gravatar.com/avatar/${(0, md5_1.default)(email)}}` }), (0, jsx_runtime_1.jsxs)(react_3.VStack, Object.assign({ display: {
                                                    base: 'none',
                                                    md: 'flex'
                                                }, alignItems: "flex-start", spacing: "1px", ml: "2", mr: "auto" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ fontSize: "sm" }, { children: email })), (0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ fontSize: "xs", color: "gray.600" }, { children: "Admin" }))] })), (0, jsx_runtime_1.jsx)(react_3.Box, Object.assign({ display: {
                                                    base: 'none',
                                                    md: 'flex'
                                                }, ml: "auto" }, { children: (0, jsx_runtime_1.jsx)(icons_1.ChevronDownIcon, { boxSize: 19 }) }))] })) })), (0, jsx_runtime_1.jsxs)(react_3.MenuList, Object.assign({ bg: (0, react_3.useColorModeValue)('white', 'gray.900'), borderColor: (0, react_3.useColorModeValue)('gray.200', 'gray.700') }, { children: [(0, jsx_runtime_1.jsx)(react_3.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/settings/account" }, { children: (0, jsx_runtime_1.jsx)(react_3.MenuItem, { children: "Settings" }) })), (0, jsx_runtime_1.jsx)(react_3.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/account-limits" }, { children: (0, jsx_runtime_1.jsx)(react_3.MenuItem, { children: "Billing" }) })), (0, jsx_runtime_1.jsx)(react_3.MenuDivider, {}), (0, jsx_runtime_1.jsx)(react_3.MenuItem, Object.assign({ backgroundColor: "red.500", _hover: {
                                                backgroundColor: (0, react_3.useColorModeValue)('red.200', 'red.400')
                                            }, onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                                yield ExtensionDevice_1.device.logout();
                                            }) }, { children: "Logout" }))] }))] }) })) }))] })) }));
};
const NavItem = (_a) => {
    var { icon, path, children } = _a, rest = __rest(_a, ["icon", "path", "children"]);
    return (0, jsx_runtime_1.jsx)(react_3.Link, Object.assign({ as: react_router_dom_1.NavLink, to: path, style: {
            textDecoration: 'none'
        }, _activeLink: {
            bg: 'teal.700' // TODO fix
        } }, { children: (0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ align: "center", p: "4", mx: "4", borderRadius: "lg", role: "group", cursor: "pointer", _hover: {
                bg: 'orange.300',
                color: 'orange.800'
            } }, rest, { children: [icon && (0, jsx_runtime_1.jsx)(react_3.Icon, { mr: "4", fontSize: "16", _groupHover: {
                        color: 'gray.400'
                    }, as: icon }), children] })) }));
};
const MobileNav = (_a) => {
    var _b;
    var { onOpen } = _a, rest = __rest(_a, ["onOpen"]);
    const email = (_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.email;
    return (0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ ml: {
            base: 0,
            md: 60
        }, px: {
            base: 4,
            md: 4
        }, height: "20", alignItems: "center", bg: (0, react_3.useColorModeValue)('white', 'gray.900'), borderBottomWidth: "1px", borderBottomColor: (0, react_3.useColorModeValue)('gray.200', 'gray.700'), justifyContent: {
            base: 'space-between',
            md: 'flex-end'
        } }, rest, { children: [(0, jsx_runtime_1.jsx)(react_3.IconButton, { display: {
                    base: 'flex',
                    md: 'none'
                }, onClick: onOpen, variant: "outline", "aria-label": "open menu", icon: (0, jsx_runtime_1.jsx)(fi_1.FiMenu, {}) }), (0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ display: {
                    base: 'flex',
                    md: 'none'
                }, fontSize: "2xl", fontFamily: "monospace", fontWeight: "bold" }, { children: "Logo" })), (0, jsx_runtime_1.jsxs)(react_3.HStack, Object.assign({ spacing: {
                    base: '0',
                    md: '6'
                } }, { children: [(0, jsx_runtime_1.jsx)(ColorModeButton_1.ColorModeButton, {}), (0, jsx_runtime_1.jsx)(react_3.Flex, Object.assign({ alignItems: 'center' }, { children: (0, jsx_runtime_1.jsxs)(react_3.Menu, { children: [(0, jsx_runtime_1.jsx)(react_3.MenuButton, Object.assign({ py: 2, transition: "all 0.3s", _focus: {
                                        boxShadow: 'none'
                                    } }, { children: (0, jsx_runtime_1.jsxs)(react_3.HStack, { children: [(0, jsx_runtime_1.jsx)(react_3.Avatar, { size: 'sm', src: `https://www.gravatar.com/avatar/${(0, md5_1.default)(email)}}` }), (0, jsx_runtime_1.jsxs)(react_3.VStack, Object.assign({ display: {
                                                    base: 'none',
                                                    md: 'flex'
                                                }, alignItems: "flex-start", spacing: "1px", ml: "2" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ fontSize: "sm" }, { children: email })), (0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ fontSize: "xs", color: "gray.600" }, { children: "Admin" }))] })), (0, jsx_runtime_1.jsx)(react_3.Box, Object.assign({ display: {
                                                    base: 'none',
                                                    md: 'flex'
                                                } }, { children: (0, jsx_runtime_1.jsx)(fi_1.FiChevronDown, {}) }))] }) })), (0, jsx_runtime_1.jsxs)(react_3.MenuList, Object.assign({ bg: (0, react_3.useColorModeValue)('white', 'gray.900'), borderColor: (0, react_3.useColorModeValue)('gray.200', 'gray.700') }, { children: [(0, jsx_runtime_1.jsx)(react_3.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/settings/account" }, { children: (0, jsx_runtime_1.jsx)(react_3.MenuItem, { children: "Settings" }) })), (0, jsx_runtime_1.jsx)(react_3.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/account-limits" }, { children: (0, jsx_runtime_1.jsx)(react_3.MenuItem, { children: "Billing" }) })), (0, jsx_runtime_1.jsx)(react_3.MenuDivider, {}), (0, jsx_runtime_1.jsx)(react_3.MenuItem, Object.assign({ backgroundColor: "red.400", onClick: () => {
                                                ExtensionDevice_1.device.logout();
                                            } }, { children: "Logout" }))] }))] }) }))] }))] }));
};


/***/ }),

/***/ 82084:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VirtualizedList = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(27378);
const DeviceStateProvider_1 = __webpack_require__(58311);
const react_2 = __webpack_require__(53159);
const react_virtualized_1 = __webpack_require__(81934);
const VaultList_1 = __webpack_require__(24099);
const useDebounce_1 = __webpack_require__(75128);
const graphqlBaseTypes_1 = __webpack_require__(89931);
const ExtensionDevice_1 = __webpack_require__(2247);
//Inspiration => https://plnkr.co/edit/zjCwNeRZ7XtmFp1PDBsc?p=preview&preview
const VirtualizedList = ({ filter }) => {
    const debouncedSearchTerm = (0, useDebounce_1.useDebounce)(filter, 400);
    const { loginCredentials: LoginCredentials, TOTPSecrets } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const filteredItems = [...LoginCredentials, ...TOTPSecrets].filter(item => {
        var _a;
        console.log('item', {
            item
        });
        const label = (_a = (item.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP ? item.totp.label : item.loginCredentials.label)) !== null && _a !== void 0 ? _a : '';
        const url = (0, ExtensionDevice_1.getDecryptedSecretProp)(item, 'url');
        return label.includes(debouncedSearchTerm) || url.includes(debouncedSearchTerm);
    });
    const ITEMS_COUNT = filteredItems.length;
    const ITEM_SIZE = 270;
    return (0, jsx_runtime_1.jsx)(react_virtualized_1.AutoSizer, { children: ({ height, width }) => {
            const itemsPerRow = Math.floor(width / ITEM_SIZE);
            const rowCount = Math.ceil(ITEMS_COUNT / itemsPerRow);
            return (0, jsx_runtime_1.jsx)(react_virtualized_1.List, { className: "List", width: width, height: height, rowCount: rowCount, rowHeight: ITEM_SIZE, rowRenderer: ({ index, key, style }) => {
                    const items = [];
                    const fromIndex = index * itemsPerRow;
                    const toIndex = Math.min(fromIndex + itemsPerRow, ITEMS_COUNT);
                    for (let i = fromIndex; i < toIndex; i++) {
                        items.push((0, jsx_runtime_1.jsx)(VaultList_1.VaultListItem, { secret: filteredItems[i] }, filteredItems[i].id));
                    }
                    return (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: 'row', justifyContent: "center", alignItems: 'center', w: '100%', h: "100%", className: "Row", style: style }, { children: items }), key);
                } });
        } });
};
exports.VirtualizedList = VirtualizedList;


/***/ }),

/***/ 84051:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AddLogin = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_2 = __webpack_require__(27378);
const react_router_dom_1 = __webpack_require__(36634);
const check_password_strength_1 = __webpack_require__(64702);
const PasswordGenerator_1 = __webpack_require__(53883);
const formik_1 = __webpack_require__(99590);
const icons_1 = __webpack_require__(26765);
const ExtensionDevice_1 = __webpack_require__(2247);
const loginCredentialsSchema_1 = __webpack_require__(80245);
const graphqlBaseTypes_1 = __webpack_require__(89931);
const formikSharedTypes_1 = __webpack_require__(28091);
const AddLogin = () => {
    const navigate = (0, react_router_dom_1.useNavigate)();
    const [show, setShow] = (0, react_2.useState)(false);
    const [initPassword, setInitPassword] = (0, react_2.useState)('');
    const { isOpen, onToggle } = (0, react_1.useDisclosure)();
    const handleClick = () => setShow(!show);
    return (0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ width: {
            base: '90%',
            sm: '70%',
            lg: '60%',
            xl: '70%'
        } }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ enableReinitialize: true, initialValues: {
                    url: '',
                    password: initPassword,
                    label: '',
                    username: ''
                }, validationSchema: formikSharedTypes_1.PasswordSchema, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                    var _a;
                    const namePassPair = {
                        password: values.password,
                        username: values.username,
                        url: values.url,
                        label: values.label,
                        iconUrl: null
                    };
                    loginCredentialsSchema_1.loginCredentialsSchema.parse(namePassPair);
                    yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.addSecrets([{
                            kind: graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS,
                            loginCredentials: namePassPair,
                            encrypted: yield ExtensionDevice_1.device.state.encrypt(JSON.stringify(namePassPair)),
                            createdAt: new Date().toJSON()
                        }]));
                    setSubmitting(false);
                    navigate(-1);
                }) }, { children: ({ values, isSubmitting, dirty, handleSubmit, errors, touched }) => {
                    const levelOfPsw = (0, check_password_strength_1.passwordStrength)(values.password);
                    return (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ p: 5, flexDirection: "column", w: "inherit" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.username && touched.username }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "username" }, { children: "Username:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "username", name: "username" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.username })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.password && touched.password }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password:" })), (0, jsx_runtime_1.jsx)(react_1.Progress, { value: levelOfPsw.id, size: "xs", colorScheme: "green", max: 3, min: 0, mb: 1 }), (0, jsx_runtime_1.jsxs)(react_1.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "password", name: "password", pr: "4.5rem", type: show ? 'text' : 'password' }), (0, jsx_runtime_1.jsx)(react_1.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: handleClick }, { children: show ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.password })] })), (0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ _focus: {
                                                bg: 'gray.200'
                                            }, fontSize: 'sm', size: "sm", onClick: () => navigate('/') }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                                bg: 'blue.500'
                                            }, _focus: {
                                                bg: 'blue.500'
                                            }, "aria-label": "Create" }, { children: "Create" }))] }))] })) }));
                } })), (0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ label: "Password generator" }, { children: (0, jsx_runtime_1.jsx)(react_1.IconButton, { w: "min-content", "aria-label": "Open password generator", icon: isOpen ? (0, jsx_runtime_1.jsx)(icons_1.ChevronUpIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ChevronDownIcon, {}), onClick: onToggle, m: 3 }) })), (0, jsx_runtime_1.jsx)(PasswordGenerator_1.PasswordGenerator, { isOpen: isOpen, setInitPassword: setInitPassword })] }));
};
exports.AddLogin = AddLogin;


/***/ }),

/***/ 43736:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AddTOTP = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_2 = __importDefault(__webpack_require__(27378));
const formik_1 = __webpack_require__(99590);
const ExtensionDevice_1 = __webpack_require__(2247);
const graphqlBaseTypes_1 = __webpack_require__(9114);
const react_router_dom_1 = __webpack_require__(36634);
const formikSharedTypes_1 = __webpack_require__(28091);
const AddTOTP = () => {
    const navigate = (0, react_router_dom_1.useNavigate)();
    return (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ width: {
            base: '90%',
            sm: '70%',
            lg: '60%',
            xl: '70%'
        } }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ enableReinitialize: true, initialValues: {
                url: '',
                secret: '',
                label: '',
                iconUrl: '',
                digits: 6,
                period: 30
            }, validationSchema: formikSharedTypes_1.TOTPSchema, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                var _a;
                yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.addSecrets([{
                        kind: graphqlBaseTypes_1.EncryptedSecretsType.TOTP,
                        totp: values,
                        encrypted: yield ExtensionDevice_1.device.state.encrypt(JSON.stringify(values)),
                        createdAt: new Date().toJSON()
                    }]));
                setSubmitting(false);
                navigate(-1);
            }) }, { children: ({ isSubmitting, handleSubmit, dirty, errors, touched }) => {
                return (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ p: 5, flexDirection: "column", w: "inherit" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.secret && touched.secret }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "secret" }, { children: "Secret:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "secret", name: "secret" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.secret })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.digits && touched.digits }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "digits" }, { children: "Digits:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "digits", name: "digits" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.digits })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.period && touched.period }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "period" }, { children: "Period:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "period", name: "period" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.period })] })), (0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ _focus: {
                                            bg: 'gray.200'
                                        }, fontSize: 'sm', size: "sm", onClick: () => navigate('/') }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                            bg: 'blue.500'
                                        }, _focus: {
                                            bg: 'blue.500'
                                        }, "aria-label": "Create" }, { children: "Create" }))] }))] })) }));
            } })) }));
};
exports.AddTOTP = AddTOTP;


/***/ }),

/***/ 45343:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useResendEmailVerificationMutation = exports.ResendEmailVerificationDocument = exports.useAccountLazyQuery = exports.useAccountQuery = exports.AccountDocument = exports.useChangeMasterPasswordMutation = exports.ChangeMasterPasswordDocument = void 0;
const client_1 = __webpack_require__(17547);
const Apollo = __importStar(__webpack_require__(17547));
const defaultOptions = {};
exports.ChangeMasterPasswordDocument = (0, client_1.gql) `
    mutation changeMasterPassword($secrets: [EncryptedSecretPatchInput!]!, $addDeviceSecret: NonEmptyString!, $addDeviceSecretEncrypted: NonEmptyString!, $decryptionChallengeId: PositiveInt!) {
  me {
    changeMasterPassword(
      input: {secrets: $secrets, addDeviceSecret: $addDeviceSecret, addDeviceSecretEncrypted: $addDeviceSecretEncrypted, decryptionChallengeId: $decryptionChallengeId}
    )
  }
}
    `;
/**
 * __useChangeMasterPasswordMutation__
 *
 * To run a mutation, you first call `useChangeMasterPasswordMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useChangeMasterPasswordMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [changeMasterPasswordMutation, { data, loading, error }] = useChangeMasterPasswordMutation({
 *   variables: {
 *      secrets: // value for 'secrets'
 *      addDeviceSecret: // value for 'addDeviceSecret'
 *      addDeviceSecretEncrypted: // value for 'addDeviceSecretEncrypted'
 *      decryptionChallengeId: // value for 'decryptionChallengeId'
 *   },
 * });
 */
function useChangeMasterPasswordMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.ChangeMasterPasswordDocument, options);
}
exports.useChangeMasterPasswordMutation = useChangeMasterPasswordMutation;
exports.AccountDocument = (0, client_1.gql) `
    query Account {
  me {
    id
    deviceRecoveryCooldownMinutes
    primaryEmailVerification {
      createdAt
      verifiedAt
    }
  }
}
    `;
/**
 * __useAccountQuery__
 *
 * To run a query within a React component, call `useAccountQuery` and pass it any options that fit your needs.
 * When your component renders, `useAccountQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useAccountQuery({
 *   variables: {
 *   },
 * });
 */
function useAccountQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.AccountDocument, options);
}
exports.useAccountQuery = useAccountQuery;
function useAccountLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.AccountDocument, options);
}
exports.useAccountLazyQuery = useAccountLazyQuery;
exports.ResendEmailVerificationDocument = (0, client_1.gql) `
    mutation resendEmailVerification {
  me {
    sendEmailVerification
  }
}
    `;
/**
 * __useResendEmailVerificationMutation__
 *
 * To run a mutation, you first call `useResendEmailVerificationMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useResendEmailVerificationMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [resendEmailVerificationMutation, { data, loading, error }] = useResendEmailVerificationMutation({
 *   variables: {
 *   },
 * });
 */
function useResendEmailVerificationMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.ResendEmailVerificationDocument, options);
}
exports.useResendEmailVerificationMutation = useResendEmailVerificationMutation;


/***/ }),

/***/ 99161:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __webpack_require__(53159);
const formik_1 = __webpack_require__(99590);
const ExtensionDevice_1 = __webpack_require__(2247);
const react_3 = __importStar(__webpack_require__(27378));
const framer_motion_1 = __webpack_require__(10238);
const Account_codegen_1 = __webpack_require__(45343);
const Login_codegen_1 = __webpack_require__(81950);
const react_toastify_1 = __webpack_require__(21779);
const icons_1 = __webpack_require__(26765);
const NbSp_1 = __webpack_require__(23961);
const react_4 = __webpack_require__(53159);
function Account() {
    var _a;
    const email = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.email;
    const [showCurr, setShowCurr] = (0, react_3.useState)(false);
    const [showNew, setShownNew] = (0, react_3.useState)(false);
    const [showPass, setShowPass] = (0, react_3.useState)(false);
    const [changePassword] = (0, Account_codegen_1.useChangeMasterPasswordMutation)();
    const [deviceDecryptionChallenge] = (0, Login_codegen_1.useDeviceDecryptionChallengeMutation)();
    const { data } = (0, Account_codegen_1.useAccountQuery)();
    if (!email) {
        return (0, jsx_runtime_1.jsx)(react_2.Spinner, {});
    }
    return (0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: {
            opacity: 1,
            y: 0
        }, initial: {
            opacity: 0,
            y: 20
        }, exit: {
            opacity: 0,
            y: -20
        }, transition: {
            duration: 0.35
        }, style: {
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ width: '70%', maxW: "600px", alignItems: 'normal', spacing: 20, rounded: 'lg', boxShadow: 'lg', p: 30, bg: (0, react_2.useColorModeValue)('white', 'gray.800') }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, { children: [(0, jsx_runtime_1.jsx)(react_4.Heading, Object.assign({ as: "h3", size: "lg", mb: 5 }, { children: "Change master password" })), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                                email: email,
                                currPassword: '',
                                newPassword: '',
                                confirmPassword: ''
                            }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                                var _b, _c, _d;
                                console.log(values.newPassword);
                                if (values.newPassword === values.confirmPassword && values.currPassword === ((_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.masterEncryptionKey)) {
                                    const decryptionChallenge = yield deviceDecryptionChallenge({
                                        variables: {
                                            deviceInput: {
                                                id: ExtensionDevice_1.device.id,
                                                name: ExtensionDevice_1.device.name,
                                                platform: ExtensionDevice_1.device.platform
                                            },
                                            email: values.email
                                        }
                                    });
                                    const secrets = ExtensionDevice_1.device.state.secrets;
                                    const { state } = ExtensionDevice_1.device;
                                    yield changePassword({
                                        variables: {
                                            secrets: yield ExtensionDevice_1.device.serializeSecrets(secrets, values.newPassword),
                                            addDeviceSecret: state.authSecret,
                                            addDeviceSecretEncrypted: state.authSecretEncrypted,
                                            decryptionChallengeId: (_d = (_c = decryptionChallenge.data) === null || _c === void 0 ? void 0 : _c.deviceDecryptionChallenge) === null || _d === void 0 ? void 0 : _d.id
                                        }
                                    });
                                    yield ExtensionDevice_1.device.logout();
                                }
                                else {
                                    react_toastify_1.toast.warning('Wrong password');
                                }
                                setSubmitting(false);
                                return false;
                            }) }, { children: ({ isSubmitting, dirty, touched, handleSubmit, errors }) => {
                                var _a, _b;
                                return (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ spacing: 4, align: "flex-start" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.email && touched.email }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormLabel, Object.assign({ htmlFor: "email" }, { children: ["Email", (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), ((_b = (_a = data === null || data === void 0 ? void 0 : data.me) === null || _a === void 0 ? void 0 : _a.primaryEmailVerification) === null || _b === void 0 ? void 0 : _b.verifiedAt) ? (0, jsx_runtime_1.jsx)(icons_1.CheckIcon, { boxSize: 18 }) : (0, jsx_runtime_1.jsx)(icons_1.WarningIcon, { boxSize: 18 })] })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, id: "email", name: "email", type: "email" }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.email })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.currPassword && touched.currPassword }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "currPassword" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Current password" }) })), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, pr: "4.5rem", type: showCurr ? 'text' : 'password', placeholder: "Master password", id: "currPassword", name: "currPassword" }), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShowCurr(!showCurr) }, { children: showCurr ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.currPassword })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.newPassword && touched.newPassword }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "newPassword", whiteSpace: 'nowrap' }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Set new Master password" }) })), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, pr: "4.5rem", type: showNew ? 'text' : 'password', placeholder: "New master password", id: "newPassword", name: "newPassword" }), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShownNew(!showNew) }, { children: showNew ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.newPassword })] })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.confirmPassword && touched.confirmPassword }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "confirmPassword", whiteSpace: 'nowrap' }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Confirm new password" }) })), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_2.Input, pr: "4.5rem", type: showPass ? 'text' : 'password', placeholder: "Confirm password", id: "confirmPassword", name: "confirmPassword" }), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShowPass(!showPass) }, { children: showPass ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: errors.confirmPassword })] })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ mt: 4, colorScheme: "teal", disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Set master password" }) }))] })) }));
                            } }))] }), (0, jsx_runtime_1.jsxs)(react_2.Box, { children: [(0, jsx_runtime_1.jsx)(react_4.Heading, Object.assign({ as: "h3", size: "lg", color: 'red', mb: 5 }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Danger zone" }) })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ colorScheme: 'red' }, { children: "Delete your account" }))] })] })) }));
}
exports["default"] = Account;


/***/ }),

/***/ 56452:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __webpack_require__(53159);
const formik_1 = __webpack_require__(99590);
const react_3 = __webpack_require__(27378);
const framer_motion_1 = __webpack_require__(10238);
const DeviceStateProvider_1 = __webpack_require__(58311);
const Settings_codegen_1 = __webpack_require__(95403);
function VaultConfig() {
    const { setSecuritySettings, device } = (0, react_3.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const [updateSettings] = (0, Settings_codegen_1.useUpdateSettingsMutation)({
        refetchQueries: [{
                query: Settings_codegen_1.SyncSettingsDocument,
                variables: {}
            }]
    });
    // Split to container component to avoid rewriting the same code twice (Account and VaultConfig)
    if (device.state) {
        return (0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: {
                opacity: 1,
                y: 0
            }, initial: {
                opacity: 0,
                y: 20
            }, exit: {
                opacity: 0,
                y: -20
            }, transition: {
                duration: 0.35
            }, style: {
                display: 'contents'
            } }, { children: (0, jsx_runtime_1.jsx)(react_2.VStack, Object.assign({ width: '70%', maxW: "600px", alignItems: 'normal', spacing: 20, rounded: 'lg', boxShadow: 'lg', p: 30, bg: (0, react_2.useColorModeValue)('white', 'gray.800') }, { children: (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ textAlign: "start" }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                            autofill: device.state.autofill,
                            language: device.state.language,
                            syncTOTP: device.state.syncTOTP,
                            vaultLockTimeoutSeconds: device.state.lockTime
                        }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                            const config = Object.assign(Object.assign({}, values), { vaultLockTimeoutSeconds: parseInt(values.vaultLockTimeoutSeconds.toString()) });
                            yield updateSettings({
                                variables: {
                                    config
                                }
                            });
                            setSecuritySettings(config);
                            setSubmitting(false);
                        }) }, { children: ({ dirty, handleSubmit, errors, touched, values, isSubmitting, submitForm, resetForm }) => (0, jsx_runtime_1.jsx)("form", Object.assign({ onBlur: () => __awaiter(this, void 0, void 0, function* () {
                                if (dirty) {
                                    yield submitForm();
                                    resetForm({
                                        values
                                    });
                                }
                            }), onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ spacing: 4, align: "flex-start" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.vaultLockTimeoutSeconds && touched.vaultLockTimeoutSeconds }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "vaultLockTimeoutSeconds" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Lock time" }) })), (0, jsx_runtime_1.jsxs)(formik_1.Field, Object.assign({ as: react_2.Select, id: "vaultLockTimeoutSeconds", name: "vaultLockTimeoutSeconds" }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ value: 20 }, { children: "1 minute" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 120 }, { children: "2 minutes" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 3600 }, { children: "1 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 14400 }, { children: "4 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 28800 }, { children: "8 hours" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 86400 }, { children: "1 day" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 604800 }, { children: "1 week" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 2592000 }, { children: "1 month" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 0 }, { children: "Never" }))] })), (0, jsx_runtime_1.jsx)(react_2.FormHelperText, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Automatically locks vault after chosen period of time" }) })] })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "syncTOTP" }, { children: ({ field, form }) => {
                                            const { onChange } = field, rest = __rest(field, ["onChange"]);
                                            return (0, jsx_runtime_1.jsx)(react_2.FormControl, Object.assign({ id: "syncTOTP", isInvalid: !!form.errors['syncTOTP'] && !!form.touched['syncTOTP'] }, { children: (0, jsx_runtime_1.jsx)(react_2.Checkbox, Object.assign({}, rest, { id: "syncTOTP", onChange: onChange, defaultChecked: values.syncTOTP }, { children: "2FA" })) }));
                                        } })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "autofill" }, { children: ({ field, form }) => {
                                            const { onChange } = field, rest = __rest(field, ["onChange"]);
                                            return (0, jsx_runtime_1.jsx)(react_2.FormControl, Object.assign({ id: "autofill", isInvalid: !!form.errors['autofill'] && !!form.touched['autofill'] }, { children: (0, jsx_runtime_1.jsx)(react_2.Checkbox, Object.assign({}, rest, { id: "autofill", onChange: onChange, defaultChecked: values.autofill }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Autofill" }) })) }));
                                        } })), (0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.language && touched.language }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "language" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Language" }) })), (0, jsx_runtime_1.jsxs)(formik_1.Field, Object.assign({ as: react_2.Select, id: "language", name: "language" }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ value: "en" }, { children: "English" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: "cz" }, { children: "\u010Ce\u0161tina" }))] }))] })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ mt: 4, colorScheme: "teal", disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Save" }) }))] })) })) })) })) })) }));
    }
    return null;
}
exports["default"] = VaultConfig;


/***/ }),

/***/ 9114:
/***/ ((__unused_webpack_module, exports) => {


/** All built-in and custom scalars, mapped to their actual values */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.EncryptedSecretsType = void 0;
(function (EncryptedSecretsType) {
    EncryptedSecretsType["TOTP"] = "TOTP";
    EncryptedSecretsType["LOGIN_CREDENTIALS"] = "LOGIN_CREDENTIALS";
})(exports.EncryptedSecretsType || (exports.EncryptedSecretsType = {}));


/***/ }),

/***/ 81676:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.messages = void 0;
/*eslint-disable*/ exports.messages = {
    'Account Limits': 'Account Limits',
    'Add QR TOTP': 'Add QR TOTP',
    All: 'All',
    'Already have an account?': 'Already have an account?',
    'Approve device "{deviceName}" in your device management in the vault on another device.': ['Approve device "', ['deviceName'], '" in your device management in the vault on another device.'],
    'Click to show the whole': 'Click to show the whole',
    Config: 'Config',
    'Confirm new password': 'Confirm new password',
    'Copy TOTP': 'Copy TOTP',
    'Copy password': 'Copy password',
    'Current domain': 'Current domain',
    'Current password': 'Current password',
    Deauthorize: 'Deauthorize',
    Devices: 'Devices',
    "Don't have account?": "Don't have account?",
    'Export Login Credentials to CSV': 'Export Login Credentials to CSV',
    'Export TOTP to CSV': 'Export TOTP to CSV',
    'Failed to parse this secret:': 'Failed to parse this secret:',
    'Import & Export': 'Import & Export',
    'Import another': 'Import another',
    'Incorrect password': 'Incorrect password',
    'Lock vault': 'Lock vault',
    'Logged in': 'Logged in',
    'Logged out': 'Logged out',
    Login: 'Login',
    'Login failed, check your username': 'Login failed, check your username',
    'Login failed, check your username and password': 'Login failed, check your username and password',
    Logout: 'Logout',
    'Open vault': 'Open vault',
    Save: 'Save',
    'Search for device': 'Search for device',
    'Search vault': 'Search vault',
    'Set master password': 'Set master password',
    'Set new Master password': 'Set new Master password',
    Settings: 'Settings',
    'Successfully added TOTP for {0}': ['Successfully added TOTP for ', ['0']],
    'Successfully added {0}, skipped {1}': ['Successfully added ', ['0'], ', skipped ', ['1']],
    'Synchronize vault': 'Synchronize vault',
    'TOTP & Login credentials': 'TOTP & Login credentials',
    'This TOTP secret is already in your vault': 'This TOTP secret is already in your vault',
    'Unlock vault': 'Unlock vault',
    Vault: 'Vault',
    'Version: {0}': ['Version: ', ['0']],
    "We support importing from <0>csv</0> files. Lastpass/Bitwarden will fork fine, file exported from other password managers might work as well, but it's not guaranteed.": "We support importing from <0>csv</0> files. Lastpass/Bitwarden will fork fine, file exported from other password managers might work as well, but it's not guaranteed.",
    'could not find any QR code on this page. Make sure QR code is visible.': 'could not find any QR code on this page. Make sure QR code is visible.'
};


/***/ }),

/***/ 54417:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useMeExtensionLazyQuery = exports.useMeExtensionQuery = exports.MeExtensionDocument = void 0;
const client_1 = __webpack_require__(17547);
const Apollo = __importStar(__webpack_require__(17547));
const defaultOptions = {};
exports.MeExtensionDocument = (0, client_1.gql) `
    query meExtension {
  me {
    id
    encryptedSecrets {
      kind
    }
    PasswordLimits
    TOTPlimit
  }
}
    `;
/**
 * __useMeExtensionQuery__
 *
 * To run a query within a React component, call `useMeExtensionQuery` and pass it any options that fit your needs.
 * When your component renders, `useMeExtensionQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useMeExtensionQuery({
 *   variables: {
 *   },
 * });
 */
function useMeExtensionQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.MeExtensionDocument, options);
}
exports.useMeExtensionQuery = useMeExtensionQuery;
function useMeExtensionLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.MeExtensionDocument, options);
}
exports.useMeExtensionLazyQuery = useMeExtensionLazyQuery;


/***/ }),

/***/ 7401:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AccountLimits = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importDefault(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const fa_1 = __webpack_require__(89583);
const AccountLimits_codegen_1 = __webpack_require__(54417);
const ProfileCard_1 = __importDefault(__webpack_require__(22356));
function PriceWrapper({ children }) {
    return (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ mb: 4, shadow: "base", borderWidth: "1px", alignSelf: {
            base: 'center',
            lg: 'flex-start'
        }, borderColor: (0, react_2.useColorModeValue)('gray.200', 'gray.500'), borderRadius: 'xl', rounded: 'xl', boxShadow: 'lg', bg: (0, react_2.useColorModeValue)('white', 'gray.900') }, { children: children }));
}
const page_url = "http://localhost:5450/";
const pricingPlan = {
    Credentials: 'prod_LquWXgjk6kl5sM',
    TOTP: 'prod_LquVrkwfsXjTAL',
    TOTP_Credentials: 'prod_Lp3NU9UcNWduBm'
};
const AccountLimits = () => {
    const { data } = (0, AccountLimits_codegen_1.useMeExtensionQuery)({
        fetchPolicy: 'network-only'
    });
    return (0, jsx_runtime_1.jsxs)(react_2.Box, { children: [(0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ spacing: 10, justifyContent: "center", alignItems: 'center' }, { children: [(0, jsx_runtime_1.jsx)(ProfileCard_1.default, {}), (0, jsx_runtime_1.jsx)(react_2.TableContainer, { children: (0, jsx_runtime_1.jsxs)(react_2.Table, Object.assign({ size: "lg" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Thead, { children: (0, jsx_runtime_1.jsxs)(react_2.Tr, { children: [(0, jsx_runtime_1.jsx)(react_2.Th, { children: "Type" }), (0, jsx_runtime_1.jsx)(react_2.Th, Object.assign({ isNumeric: true }, { children: "Current count" })), (0, jsx_runtime_1.jsx)(react_2.Th, Object.assign({ isNumeric: true }, { children: "Your limit" }))] }) }), (0, jsx_runtime_1.jsxs)(react_2.Tbody, { children: [(0, jsx_runtime_1.jsxs)(react_2.Tr, { children: [(0, jsx_runtime_1.jsx)(react_2.Td, { children: "Credentials" }), (0, jsx_runtime_1.jsx)(react_2.Td, Object.assign({ isNumeric: true }, { children: data === null || data === void 0 ? void 0 : data.me.encryptedSecrets.filter(i => i.kind === 'LOGIN_CREDENTIALS').length })), (0, jsx_runtime_1.jsx)(react_2.Td, Object.assign({ isNumeric: true }, { children: data === null || data === void 0 ? void 0 : data.me.PasswordLimits }))] }), (0, jsx_runtime_1.jsxs)(react_2.Tr, { children: [(0, jsx_runtime_1.jsx)(react_2.Td, { children: "TOTP" }), (0, jsx_runtime_1.jsx)(react_2.Td, Object.assign({ isNumeric: true }, { children: data === null || data === void 0 ? void 0 : data.me.encryptedSecrets.filter(i => i.kind === 'TOTP').length })), (0, jsx_runtime_1.jsx)(react_2.Td, Object.assign({ isNumeric: true }, { children: data === null || data === void 0 ? void 0 : data.me.TOTPlimit }))] })] })] })) })] })), (0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ direction: {
                    base: 'column',
                    md: 'row'
                }, textAlign: "center", justify: "center", spacing: {
                    base: 4,
                    lg: 10
                }, py: 10 }, { children: [(0, jsx_runtime_1.jsxs)(PriceWrapper, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "Free tier" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "0" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsxs)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheckCircle, color: "green.500" }), "3 TOTP secrets"] }), (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheckCircle, color: "green.500" }), "40 login secrets"] })] })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ w: "80%", pt: 7 }, { children: "Always free" }))] }))] }), (0, jsx_runtime_1.jsxs)(PriceWrapper, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 4, px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "Credentials" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "1" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsx)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheckCircle, color: "green.500" }), "additional 60 login secrets"] }) })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ disabled: !(data === null || data === void 0 ? void 0 : data.me.id), w: "80%", colorScheme: "red", onClick: () => chrome.tabs.create({
                                            url: `${page_url}/pricing?product=${pricingPlan.Credentials}`
                                        }) }, { children: "Buy" }))] }))] }), (0, jsx_runtime_1.jsxs)(PriceWrapper, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 4, px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "TOTP" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "1" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsx)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheckCircle, color: "green.500" }), "additional 20 TOTP secrets"] }) })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ disabled: !(data === null || data === void 0 ? void 0 : data.me.id), w: "80%", colorScheme: "red", onClick: () => chrome.tabs.create({
                                            url: `${page_url}/pricing?product=${pricingPlan.TOTP}`
                                        }) }, { children: "Buy" }))] }))] }), (0, jsx_runtime_1.jsx)(PriceWrapper, { children: (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ position: "relative" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ position: "absolute", top: "-16px", left: "50%", style: {
                                        transform: 'translate(-50%)'
                                    } }, { children: (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ textTransform: "uppercase", noOfLines: 1, bg: (0, react_2.useColorModeValue)('red.300', 'red.700'), px: 3, py: 1, color: (0, react_2.useColorModeValue)('white', 'gray.100'), fontSize: "sm", fontWeight: "600", rounded: "xl" }, { children: "Most Popular" })) })), (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 4, px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "TOTP and Credentials" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "2" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsxs)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheckCircle, color: "green.500" }), "additional 60 login secrets"] }), (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheckCircle, color: "green.500" }), "additional 20 TOTP secrets"] })] })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ disabled: !(data === null || data === void 0 ? void 0 : data.me.id), w: "80%", colorScheme: "red", onClick: () => chrome.tabs.create({
                                                url: `${page_url}/pricing?product=${pricingPlan.TOTP_Credentials}`
                                            }) }, { children: "Buy" }))] }))] })) })] }))] });
};
exports.AccountLimits = AccountLimits;


/***/ }),

/***/ 87573:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AddItem = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_2 = __importStar(__webpack_require__(27378));
const framer_motion_1 = __webpack_require__(10238);
const AddLogin_1 = __webpack_require__(84051);
const AddTOTP_1 = __webpack_require__(43736);
const AccountLimits_codegen_1 = __webpack_require__(54417);
const DeviceStateProvider_1 = __webpack_require__(58311);
const AddItem = () => {
    const [type, setType] = (0, react_2.useState)(null);
    const { loginCredentials: LoginCredentials, TOTPSecrets } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { data, loading } = (0, AccountLimits_codegen_1.useMeExtensionQuery)({
        fetchPolicy: 'network-only'
    });
    const bg = (0, react_1.useColorModeValue)('white', 'gray.800');
    if (loading) {
        return (0, jsx_runtime_1.jsx)(react_1.Spinner, {});
    }
    const totpCond = data.me.TOTPlimit <= TOTPSecrets.length;
    const pswCond = data.me.PasswordLimits <= LoginCredentials.length;
    return (0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: {
            opacity: 1
        }, initial: {
            opacity: 0
        }, exit: {
            opacity: 0
        }, transition: {
            duration: 0.25
        }, style: {
            width: '80%',
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ width: {
                base: '90%',
                sm: '70%',
                lg: '60%',
                xl: '50%',
                '2xl': '40%'
            }, flexDirection: "column", boxShadow: '2xl', rounded: 'md', overflow: 'hidden', m: "auto", alignItems: 'center', bg: bg }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Select, Object.assign({ onChange: e => setType(e.target.value), defaultValue: undefined, placeholder: "Select type", w: '50%', mt: 5 }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ disabled: totpCond, value: "TOTP" }, { children: "TOTP" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ disabled: pswCond, value: "Login" }, { children: "Login" }))] })), type === 'Login' ? (0, jsx_runtime_1.jsx)(AddLogin_1.AddLogin, {}) : type === 'TOTP' ? (0, jsx_runtime_1.jsx)(AddTOTP_1.AddTOTP, {}) : (0, jsx_runtime_1.jsx)(react_1.Box, { children: (0, jsx_runtime_1.jsx)(react_1.Text, { children: "Select a type" }) })] })) }));
};
exports.AddItem = AddItem;


/***/ }),

/***/ 14952:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const icons_1 = __webpack_require__(26765);
const react_2 = __webpack_require__(53159);
const NbSp_1 = __webpack_require__(23961);
const formik_1 = __webpack_require__(99590);
const react_3 = __webpack_require__(27378);
const fi_1 = __webpack_require__(86893);
const AccountDevices_codegen_1 = __webpack_require__(8756);
const date_fns_1 = __webpack_require__(66446);
const DeviceDeleteAlert_1 = __webpack_require__(47529);
const ExtensionDevice_1 = __webpack_require__(2247);
const RefreshDeviceButton_1 = __webpack_require__(86111);
const react_router_dom_1 = __webpack_require__(36634);
const NewDeviceApproval_1 = __webpack_require__(49271);
const DeviceListItem = ({ deviceInfo, masterDeviceId }) => {
    var _a, _b;
    const [changeMasterDeviceMutation] = (0, AccountDevices_codegen_1.useChangeMasterDeviceMutation)();
    const [isConfigOpen, setIsConfigOpen] = (0, react_3.useState)(false);
    const { isOpen, onOpen, onClose } = (0, react_2.useDisclosure)();
    const navigate = (0, react_router_dom_1.useNavigate)();
    return (0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ py: 6, m: 5 }, { children: (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ w: "350px", bg: (0, react_2.useColorModeValue)('white', 'gray.800'), boxShadow: '2xl', rounded: 'lg', p: 6 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ justifyContent: "space-between", direction: 'row', spacing: 3, alignItems: 'baseline', lineHeight: '6' }, { children: [(0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ mb: 2, spacing: 3 }, { children: [deviceInfo.id === ExtensionDevice_1.device.id && (0, jsx_runtime_1.jsx)(react_2.Badge, Object.assign({ height: "min-content", colorScheme: "yellow" }, { children: "Current" })), deviceInfo.id === masterDeviceId && (0, jsx_runtime_1.jsx)(react_2.Badge, Object.assign({ height: "min-content", colorScheme: "purple" }, { children: "Master" })), deviceInfo.logoutAt ? (0, jsx_runtime_1.jsx)(react_2.Badge, Object.assign({ height: "min-content", colorScheme: "red" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Logged out" }) })) : (0, jsx_runtime_1.jsx)(react_2.Badge, Object.assign({ height: "min-content", colorScheme: "green" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Logged in" }) }))] })), (0, jsx_runtime_1.jsxs)(react_2.Menu, { children: [(0, jsx_runtime_1.jsx)(react_2.MenuButton, { as: react_2.IconButton, size: "xs", variant: "unstyled", "aria-label": "Favourite", fontSize: "15px", icon: (0, jsx_runtime_1.jsx)(icons_1.SettingsIcon, { color: 'white' }) }), (0, jsx_runtime_1.jsxs)(react_2.MenuList, { children: [masterDeviceId !== deviceInfo.id ? (0, jsx_runtime_1.jsxs)(react_2.MenuItem, Object.assign({ onClick: () => changeMasterDeviceMutation({
                                                    variables: {
                                                        newMasterDeviceId: deviceInfo.id
                                                    }
                                                }) }, { children: [(0, jsx_runtime_1.jsx)(fi_1.FiStar, {}), (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Set on master device" })] })) : null, (0, jsx_runtime_1.jsxs)(react_2.MenuItem, Object.assign({ onClick: () => onOpen() }, { children: [(0, jsx_runtime_1.jsx)(fi_1.FiLogOut, {}), (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Logout" })] })), (0, jsx_runtime_1.jsx)(DeviceDeleteAlert_1.DeviceDeleteAlert, { id: deviceInfo.id, isOpen: isOpen, onClose: onClose }), (0, jsx_runtime_1.jsxs)(react_2.MenuItem, Object.assign({ onClick: () => {
                                                    if (deviceInfo.id === ExtensionDevice_1.device.id) {
                                                        navigate('/settings/security');
                                                    }
                                                    else {
                                                        setIsConfigOpen(!isConfigOpen);
                                                    }
                                                } }, { children: [(0, jsx_runtime_1.jsx)(fi_1.FiSettings, {}), (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Config" })] }))] })] })] })), (0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ fontSize: 'xl', fontFamily: 'body' }, { children: deviceInfo.name })), isConfigOpen ? (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ mt: 5 }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                                lockTime: deviceInfo.vaultLockTimeoutSeconds,
                                twoFA: deviceInfo.syncTOTP
                            }, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                                console.log(values);
                                setSubmitting(false);
                            }) }, { children: ({ isSubmitting, dirty, handleSubmit, errors, touched, values }) => (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ spacing: 4, align: "flex-start" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: !!errors.lockTime && touched.lockTime }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "lockTime" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Lock time" }) })), (0, jsx_runtime_1.jsxs)(formik_1.Field, Object.assign({ as: react_2.Select, id: "lockTime", name: "lockTime" }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ value: 60 }, { children: "1 minute" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 120 }, { children: "2 minutes" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 3600 }, { children: "1 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 14400 }, { children: "4 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 28800 }, { children: "8 hours" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 86400 }, { children: "1 day" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 604800 }, { children: "1 week" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 2592000 }, { children: "1 month" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 0 }, { children: "Never" }))] })), (0, jsx_runtime_1.jsx)(react_2.FormHelperText, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Automatically locks vault after chosen period of time" }) })] })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "twoFA" }, { children: ({ field, form }) => {
                                                const { onChange } = field, rest = __rest(field, ["onChange"]);
                                                return (0, jsx_runtime_1.jsx)(react_2.FormControl, Object.assign({ id: "twoFA", isInvalid: !!form.errors['twoFA'] && !!form.touched['twoFA'] }, { children: (0, jsx_runtime_1.jsx)(react_2.Checkbox, Object.assign({}, rest, { id: "twoFA", onChange: onChange, defaultChecked: values.twoFA }, { children: "2FA" })) }));
                                            } })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ mt: 4, colorScheme: "teal", disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Save" }) }))] })) })) })) })) : (0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ mt: 6, spacing: 4 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: 600, color: 'gray.500', fontSize: 'md' }, { children: "Last IP Address" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: 'xl' }, { children: deviceInfo.lastIpAddress }))] }), (0, jsx_runtime_1.jsxs)(react_2.Box, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: 600, color: 'gray.500', fontSize: 'md' }, { children: "Geolocation" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: 'xl' }, { children: deviceInfo.lastGeoLocation }))] }), (0, jsx_runtime_1.jsxs)(react_2.Box, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: 600, color: 'gray.500', fontSize: 'md' }, { children: "Added" })), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: (0, date_fns_1.intlFormat)(new Date((_a = deviceInfo.createdAt) !== null && _a !== void 0 ? _a : ''), {
                                            weekday: 'long',
                                            year: 'numeric',
                                            month: 'long',
                                            day: 'numeric'
                                        }) }, { children: (0, jsx_runtime_1.jsxs)(react_2.Text, Object.assign({ fontSize: 'xl' }, { children: [(0, date_fns_1.formatDistance)(new Date((_b = deviceInfo.createdAt) !== null && _b !== void 0 ? _b : ''), new Date()), "ago"] })) }))] })] }))] })) })) });
};
function Devices() {
    var _a, _b, _c;
    const { data, loading, refetch: devicesRefetch } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    const [filterBy, setFilterBy] = (0, react_3.useState)('');
    return (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Center, { children: [(0, jsx_runtime_1.jsx)(react_2.Input, { w: ['300px', '350px', '400px', '500px'], placeholder: /*i18n*/ core_1.i18n._("Search for device"), m: "auto", onChange: ev => {
                            setFilterBy(ev.target.value);
                        } }), (0, jsx_runtime_1.jsxs)(react_2.Center, Object.assign({ px: 3 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Stat, Object.assign({ ml: "auto", whiteSpace: 'nowrap' }, { children: [(_a = data === null || data === void 0 ? void 0 : data.me) === null || _a === void 0 ? void 0 : _a.devices.length, " ", /*i18n*/ core_1.i18n._("devices")] })), (0, jsx_runtime_1.jsx)(RefreshDeviceButton_1.RefreshDeviceButton, {})] }))] }), (0, jsx_runtime_1.jsx)(NewDeviceApproval_1.NewDevicesApprovalStack, {}), (0, jsx_runtime_1.jsx)(react_2.Center, Object.assign({ justifyContent: ['flex-end', 'center', 'center'] }, { children: (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: "row", flexWrap: "wrap", m: "auto" }, { children: loading ? (0, jsx_runtime_1.jsx)(react_2.Center, Object.assign({ pt: 5 }, { children: (0, jsx_runtime_1.jsx)(react_2.Spinner, { size: "lg" }) })) : (_c = (_b = data === null || data === void 0 ? void 0 : data.me) === null || _b === void 0 ? void 0 : _b.devices) === null || _c === void 0 ? void 0 : _c.filter(({ name }) => {
                            return name.includes(filterBy);
                        }).map((el, i) => {
                            return (0, jsx_runtime_1.jsx)(DeviceListItem, { deviceInfo: el, masterDeviceId: data.me.masterDeviceId }, i);
                        }) })) })) }))] }));
}
exports["default"] = Devices;


/***/ }),

/***/ 61556:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LoginContext = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __importStar(__webpack_require__(27378));
const react_3 = __webpack_require__(53159);
const formik_1 = __webpack_require__(99590);
const icons_1 = __webpack_require__(26765);
const debug_1 = __importDefault(__webpack_require__(96292));
const ExtensionDevice_1 = __webpack_require__(2247);
const LoginAwaitingApproval_1 = __webpack_require__(44188);
const react_router_dom_1 = __webpack_require__(36634);
const log = (0, debug_1.default)('au:Login');
// @ts-expect-error TODO: fix types
exports.LoginContext = react_2.default.createContext();
// export const isRunningInVault = location.href.includes('/vault.html#')
function Login() {
    const [showPassword, setShowPassword] = (0, react_2.useState)(false);
    const [formState, setFormState] = (0, react_2.useState)(null);
    if (!ExtensionDevice_1.device.id) {
        return (0, jsx_runtime_1.jsx)(react_3.Spinner, {});
    }
    if (formState) {
        return (0, jsx_runtime_1.jsx)(exports.LoginContext.Provider, Object.assign({ value: {
                formState,
                setFormState
            } }, { children: (0, jsx_runtime_1.jsx)(LoginAwaitingApproval_1.LoginAwaitingApproval, {}) }));
    }
    return (0, jsx_runtime_1.jsxs)(react_3.Box, Object.assign({ p: 8, borderWidth: 1, borderRadius: 6, boxShadow: "lg", minW: "400px" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Flex, Object.assign({ alignItems: "center", justifyContent: "center" }, { children: (0, jsx_runtime_1.jsx)(react_3.Heading, Object.assign({ size: "lg" }, { children: "Login" })) })), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                    email: 'bob@bob.com',
                    password: 'bob'
                }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                    setFormState(values);
                    setSubmitting(false);
                }) }, { children: props => (0, jsx_runtime_1.jsxs)(formik_1.Form, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "email" }, { children: ({ field, form }) => (0, jsx_runtime_1.jsxs)(react_3.FormControl, Object.assign({ isInvalid: form.errors.email && form.touched.email, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_3.FormLabel, Object.assign({ htmlFor: "email" }, { children: "Email" })), (0, jsx_runtime_1.jsx)(react_3.Input, Object.assign({}, field, { id: "Email", placeholder: "bob@bob.com" })), (0, jsx_runtime_1.jsx)(react_3.FormErrorMessage, { children: form.errors.email })] })) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "password" }, { children: ({ field, form }) => (0, jsx_runtime_1.jsxs)(react_3.FormControl, Object.assign({ isInvalid: form.errors.password && form.touched.password, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_3.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password" })), (0, jsx_runtime_1.jsxs)(react_3.InputGroup, { children: [(0, jsx_runtime_1.jsx)(react_3.Input, Object.assign({}, field, { type: showPassword ? 'text' : 'password', placeholder: "*******" })), (0, jsx_runtime_1.jsx)(react_3.InputRightElement, Object.assign({ width: "3rem" }, { children: (0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ h: "1.5rem", size: "sm", onClick: () => setShowPassword(!showPassword) }, { children: showPassword ? (0, jsx_runtime_1.jsx)(icons_1.ViewOffIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ViewIcon, {}) })) }))] }), (0, jsx_runtime_1.jsx)(react_3.FormErrorMessage, { children: form.errors.password })] })) })), (0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ colorScheme: "teal", variant: "outline", type: "submit", width: "full", mt: 4, isLoading: props.isSubmitting }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Login" }) }))] }) })), (0, jsx_runtime_1.jsx)(react_3.Flex, { children: (0, jsx_runtime_1.jsx)(react_router_dom_1.Link, Object.assign({ to: "/signup" }, { children: (0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ pt: 3 }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Don't have account?" }) })) })) })] }));
}
exports["default"] = Login;


/***/ }),

/***/ 44188:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LoginAwaitingApproval = exports.useLogin = exports.log = exports.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const ExtensionDevice_1 = __webpack_require__(2247);
const UserProvider_1 = __webpack_require__(59871);
const react_2 = __importStar(__webpack_require__(27378));
const Login_1 = __webpack_require__(61556);
const Login_codegen_1 = __webpack_require__(81950);
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const accessTokenExtension_1 = __webpack_require__(27690);
const react_3 = __webpack_require__(53159);
const date_fns_1 = __webpack_require__(66446);
const icons_1 = __webpack_require__(26765);
const debug_1 = __importDefault(__webpack_require__(96292));
const generateEncryptionKey_1 = __webpack_require__(44038);
const Providers_1 = __webpack_require__(62142);
exports.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL = 6000;
exports.log = (0, debug_1.default)('au:LoginAwaitingApproval');
const useLogin = props => {
    const { formState, setFormState } = (0, react_2.useContext)(Login_1.LoginContext);
    const { setUserId } = (0, react_2.useContext)(UserProvider_1.UserContext);
    const [addNewDevice, { loading, error }] = (0, Login_codegen_1.useAddNewDeviceForUserMutation)();
    const [getDeviceDecryptionChallenge, { data: decryptionData, error: decrChallError }] = (0, Login_codegen_1.useDeviceDecryptionChallengeMutation)({
        variables: {
            deviceInput: {
                id: ExtensionDevice_1.device.id,
                name: props.deviceName,
                platform: ExtensionDevice_1.device.platform
            },
            email: formState.email
        }
    });
    (0, react_2.useEffect)(() => {
        if (error || decrChallError) {
            setFormState(null);
        }
    }, [error, decrChallError]);
    (0, react_3.useInterval)(() => {
        getDeviceDecryptionChallenge();
    }, exports.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL);
    const deviceDecryptionChallenge = decryptionData === null || decryptionData === void 0 ? void 0 : decryptionData.deviceDecryptionChallenge;
    (0, react_2.useEffect)(() => {
        console.log('~ decryptionData', decryptionData);
        const { fireToken } = ExtensionDevice_1.device;
        if ((deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.__typename) === 'DecryptionChallengeApproved' && fireToken) {
            ;
            (() => __awaiter(void 0, void 0, void 0, function* () {
                var _a, _b, _c;
                const addDeviceSecretEncrypted = deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.addDeviceSecretEncrypted;
                const userId = deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.userId;
                if (!addDeviceSecretEncrypted || !userId) {
                    (0, Providers_1.toast)({
                        title: /*i18n*/ core_1.i18n._("Login failed, check your email or password"),
                        status: 'error',
                        isClosable: true
                    });
                    return;
                }
                if (!(deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.id)) {
                    (0, Providers_1.toast)({
                        title: 'Failed to create decryption challenge',
                        status: 'error',
                        isClosable: true
                    });
                    return;
                }
                const encryptionSalt = deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.encryptionSalt;
                const masterEncryptionKey = yield (0, generateEncryptionKey_1.generateEncryptionKey)(formState.password, (0, generateEncryptionKey_1.base64_to_buf)(encryptionSalt));
                let currentAddDeviceSecret;
                try {
                    const encryptedDataBuff = (0, generateEncryptionKey_1.base64_to_buf)(addDeviceSecretEncrypted);
                    const iv = encryptedDataBuff.slice(16, 16 + 12);
                    const data = encryptedDataBuff.slice(16 + 12);
                    const decryptedContent = yield window.crypto.subtle.decrypt({
                        name: 'AES-GCM',
                        iv
                    }, masterEncryptionKey, data);
                    currentAddDeviceSecret = generateEncryptionKey_1.dec.decode(decryptedContent);
                }
                catch (error) {
                    console.error(error);
                }
                (0, exports.log)('~ currentAddDeviceSecret', currentAddDeviceSecret);
                if (!currentAddDeviceSecret) {
                    (0, Providers_1.toast)({
                        title: /*i18n*/ core_1.i18n._("Login failed, check your email or password"),
                        status: 'error',
                        isClosable: true
                    });
                    setFormState(null);
                    return;
                }
                const newParams = yield ExtensionDevice_1.device.initLocalDeviceAuthSecret(masterEncryptionKey, (0, generateEncryptionKey_1.base64_to_buf)(encryptionSalt));
                const response = yield addNewDevice({
                    variables: {
                        email: formState.email,
                        deviceInput: {
                            id: ExtensionDevice_1.device.id,
                            name: props.deviceName,
                            platform: ExtensionDevice_1.device.platform
                        },
                        input: {
                            addDeviceSecret: newParams.addDeviceSecret,
                            addDeviceSecretEncrypted: newParams.addDeviceSecretEncrypted,
                            firebaseToken: fireToken,
                            devicePlatform: ExtensionDevice_1.device.platform,
                            //WARNING: Has to be the same all the time
                            encryptionSalt
                        },
                        currentAddDeviceSecret: currentAddDeviceSecret
                    }
                });
                yield webextension_polyfill_1.default.storage.local.set({
                    addDeviceSecretEncrypted,
                    currentAddDeviceSecret
                });
                const addNewDeviceForUser = ((_b = (_a = response.data) === null || _a === void 0 ? void 0 : _a.deviceDecryptionChallenge) === null || _b === void 0 ? void 0 : _b.__typename) === 'DecryptionChallengeApproved' ? (_c = response.data) === null || _c === void 0 ? void 0 : _c.deviceDecryptionChallenge.addNewDeviceForUser : null;
                if (addNewDeviceForUser === null || addNewDeviceForUser === void 0 ? void 0 : addNewDeviceForUser.accessToken) {
                    (0, accessTokenExtension_1.setAccessToken)(addNewDeviceForUser === null || addNewDeviceForUser === void 0 ? void 0 : addNewDeviceForUser.accessToken);
                    const decodedToken = yield (0, accessTokenExtension_1.getUserFromToken)();
                    const EncryptedSecrets = addNewDeviceForUser.user.EncryptedSecrets;
                    const deviceState = {
                        masterEncryptionKey: yield (0, generateEncryptionKey_1.cryptoKeyToString)(masterEncryptionKey),
                        userId: userId,
                        secrets: EncryptedSecrets,
                        email: formState.email,
                        encryptionSalt,
                        deviceName: props.deviceName,
                        authSecret: newParams.addDeviceSecret,
                        authSecretEncrypted: newParams.addDeviceSecretEncrypted,
                        lockTime: 28800,
                        autofill: true,
                        language: 'en',
                        syncTOTP: false,
                        theme: 'dark'
                    };
                    setUserId(decodedToken.userId);
                    ExtensionDevice_1.device.save(deviceState);
                    (0, Providers_1.toast)({
                        title: /*i18n*/ core_1.i18n._("Device approved at {0}", {
                            0: (0, date_fns_1.formatRelative)(new Date(), new Date(deviceDecryptionChallenge.approvedAt))
                        }),
                        status: 'success',
                        isClosable: true
                    });
                }
                else {
                    (0, Providers_1.toast)({
                        title: /*i18n*/ core_1.i18n._("Login failed, check your username or password"),
                        status: 'error',
                        isClosable: true
                    });
                }
            }))();
        }
        else if (!deviceDecryptionChallenge) {
            getDeviceDecryptionChallenge();
        }
    }, [deviceDecryptionChallenge]);
    return {
        deviceDecryptionChallenge,
        loading
    };
};
exports.useLogin = useLogin;
const LoginAwaitingApproval = () => {
    const [deviceName] = (0, react_2.useState)(ExtensionDevice_1.device.generateDeviceName());
    const { deviceDecryptionChallenge } = (0, exports.useLogin)({
        deviceName
    });
    if (!deviceDecryptionChallenge) {
        return (0, jsx_runtime_1.jsx)(react_3.Spinner, {});
    }
    if (!deviceDecryptionChallenge || (deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.id) && deviceDecryptionChallenge.__typename === 'DecryptionChallengeForApproval') {
        return (0, jsx_runtime_1.jsxs)(react_3.Card, Object.assign({ p: 8, borderWidth: 1, borderRadius: 6, boxShadow: "lg", minW: "600px" }, { children: [(0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ align: 'center' }, { children: [(0, jsx_runtime_1.jsx)(icons_1.WarningIcon, { mr: 2, boxSize: 30 }), (0, jsx_runtime_1.jsx)(react_3.Heading, Object.assign({ size: "md", mr: 4 }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Device:" }) })), (0, jsx_runtime_1.jsx)(react_3.Heading, Object.assign({ size: "sm" }, { children: deviceName }))] })), (0, jsx_runtime_1.jsx)(react_3.Flex, { children: (0, jsx_runtime_1.jsx)(react_3.Center, Object.assign({ mt: 3 }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Approve this device in your device management in the vault on your master device in order to finish adding new device. Afterwards your vault will open automatically in this tab." }) })) })] }));
    }
    else {
        return null;
    }
};
exports.LoginAwaitingApproval = LoginAwaitingApproval;


/***/ }),

/***/ 49271:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NewDevicesApprovalStack = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __webpack_require__(53159);
const AccountDevices_codegen_1 = __webpack_require__(8756);
const date_fns_1 = __webpack_require__(66446);
const LoginAwaitingApproval_1 = __webpack_require__(44188);
const NewDevicesApprovalStack = () => {
    var _a;
    const { refetch: devicesRefetch } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    const { data: devicesRequests, refetch } = (0, AccountDevices_codegen_1.useDevicesRequestsQuery)();
    const [reject] = (0, AccountDevices_codegen_1.useRejectChallengeMutation)();
    const [approve] = (0, AccountDevices_codegen_1.useApproveChallengeMutation)();
    return (0, jsx_runtime_1.jsx)(react_2.VStack, Object.assign({ mt: 3 }, { children: (_a = devicesRequests === null || devicesRequests === void 0 ? void 0 : devicesRequests.me) === null || _a === void 0 ? void 0 : _a.decryptionChallengesWaiting.map(challengeToApprove => {
            return (0, jsx_runtime_1.jsxs)(react_2.Alert, Object.assign({ minW: "90%", status: "warning", display: "grid", rounded: 4, gridRowGap: 1, maxW: 500 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Center, { children: ["New device \"", challengeToApprove.deviceName, "\" trying to login", ' ', (0, date_fns_1.formatRelative)(new Date(challengeToApprove.createdAt), new Date()), ": from IP ", challengeToApprove.ipAddress, " (", challengeToApprove.ipGeoLocation.city, ",", ' ', challengeToApprove.ipGeoLocation.country_name, ")"] }), (0, jsx_runtime_1.jsxs)(react_2.Grid, Object.assign({ gridGap: 1, autoFlow: "row", templateColumns: "repeat(auto-fit, 49%)" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Center, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ w: "50%", colorScheme: "red", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                        yield reject({
                                            variables: {
                                                id: challengeToApprove.id
                                            }
                                        });
                                        yield refetch();
                                    }) }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Reject" }) })) }), (0, jsx_runtime_1.jsx)(react_2.Center, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ w: "50%", colorScheme: "green", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                        yield approve({
                                            variables: {
                                                id: challengeToApprove.id
                                            }
                                        });
                                        yield refetch();
                                        setTimeout(() => {
                                            devicesRefetch();
                                        }, LoginAwaitingApproval_1.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL); // this is needed, because it takes time one the client side to do the decryption challenge
                                    }) }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Approve" }) })) })] }))] }), challengeToApprove.id);
        }) }));
};
exports.NewDevicesApprovalStack = NewDevicesApprovalStack;


/***/ }),

/***/ 6974:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __webpack_require__(27378);
const react_3 = __webpack_require__(53159);
const icons_1 = __webpack_require__(26765);
const formik_1 = __webpack_require__(99590);
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const accessTokenExtension_1 = __webpack_require__(27690);
const ExtensionDevice_1 = __webpack_require__(2247);
const generateEncryptionKey_1 = __webpack_require__(44038);
const registerNewUser_codegen_1 = __webpack_require__(5970);
const react_router_dom_1 = __webpack_require__(36634);
function Register() {
    const [showPassword, setShowPassword] = (0, react_2.useState)(false);
    const [register] = (0, registerNewUser_codegen_1.useRegisterNewUserMutation)();
    const navigate = (0, react_router_dom_1.useNavigate)();
    const { fireToken } = ExtensionDevice_1.device;
    if (!fireToken) {
        return (0, jsx_runtime_1.jsx)(react_3.Spinner, {});
    }
    return (0, jsx_runtime_1.jsxs)(react_3.Box, Object.assign({ p: 8, borderWidth: 1, borderRadius: 6, boxShadow: "lg", minW: "400px" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Flex, Object.assign({ alignItems: "center", justifyContent: "center" }, { children: (0, jsx_runtime_1.jsx)(react_3.Heading, { children: "Create account" }) })), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                    email: '',
                    password: ''
                }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                    var _a, _b;
                    const userId = crypto.randomUUID();
                    const deviceId = yield ExtensionDevice_1.device.getDeviceId();
                    const encryptionSalt = window.crypto.getRandomValues(new Uint8Array(16));
                    const masterEncryptionKey = yield (0, generateEncryptionKey_1.generateEncryptionKey)(values.password, encryptionSalt);
                    const params = yield ExtensionDevice_1.device.initLocalDeviceAuthSecret(masterEncryptionKey, encryptionSalt);
                    const res = yield register({
                        variables: {
                            userId,
                            input: Object.assign(Object.assign({ encryptionSalt: (0, generateEncryptionKey_1.buff_to_base64)(encryptionSalt), email: values.email }, params), { deviceId, devicePlatform: ExtensionDevice_1.device.platform, deviceName: ExtensionDevice_1.device.generateDeviceName(), firebaseToken: fireToken })
                        }
                    });
                    const registerResult = (_a = res.data) === null || _a === void 0 ? void 0 : _a.registerNewUser;
                    if (registerResult === null || registerResult === void 0 ? void 0 : registerResult.accessToken) {
                        //FIX: is this right, maybe someone could use proxy and send random string
                        yield webextension_polyfill_1.default.storage.local.set({
                            'access-token': (_b = res.data) === null || _b === void 0 ? void 0 : _b.registerNewUser.accessToken
                        });
                        (0, accessTokenExtension_1.setAccessToken)(registerResult.accessToken);
                        const stringKey = yield (0, generateEncryptionKey_1.cryptoKeyToString)(masterEncryptionKey);
                        const deviceState = {
                            masterEncryptionKey: stringKey,
                            userId: userId,
                            secrets: [],
                            email: values.email,
                            deviceName: ExtensionDevice_1.device.name,
                            encryptionSalt: (0, generateEncryptionKey_1.buff_to_base64)(encryptionSalt),
                            authSecret: params.addDeviceSecret,
                            authSecretEncrypted: params.addDeviceSecretEncrypted,
                            lockTime: 28800,
                            autofill: true,
                            language: 'en',
                            syncTOTP: false,
                            theme: 'dark'
                        };
                        ExtensionDevice_1.device.save(deviceState);
                        navigate('/');
                        setSubmitting(false);
                    }
                }) }, { children: props => (0, jsx_runtime_1.jsxs)(formik_1.Form, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "email" }, { children: ({ field, form }) => (0, jsx_runtime_1.jsxs)(react_3.FormControl, Object.assign({ isInvalid: form.errors.email && form.touched.email, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_3.FormLabel, Object.assign({ htmlFor: "email" }, { children: "Email" })), (0, jsx_runtime_1.jsx)(react_3.Input, Object.assign({}, field, { id: "Email", placeholder: "bob@bob.com" })), (0, jsx_runtime_1.jsx)(react_3.FormErrorMessage, { children: form.errors.email })] })) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "password" }, { children: ({ field, form }) => (0, jsx_runtime_1.jsxs)(react_3.FormControl, Object.assign({ isInvalid: form.errors.password && form.touched.password, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_3.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password" })), (0, jsx_runtime_1.jsxs)(react_3.InputGroup, { children: [(0, jsx_runtime_1.jsx)(react_3.Input, Object.assign({}, field, { type: showPassword ? 'text' : 'password', placeholder: "*******" })), (0, jsx_runtime_1.jsx)(react_3.InputRightElement, Object.assign({ width: "3rem" }, { children: (0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ h: "1.5rem", size: "sm", onClick: () => setShowPassword(!showPassword) }, { children: showPassword ? (0, jsx_runtime_1.jsx)(icons_1.ViewOffIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ViewIcon, {}) })) }))] }), (0, jsx_runtime_1.jsx)(react_3.FormErrorMessage, { children: form.errors.password })] })) })), (0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ colorScheme: "teal", variant: "outline", type: "submit", width: "full", mt: 4, isLoading: props.isSubmitting }, { children: "Register" })), (0, jsx_runtime_1.jsxs)(react_3.chakra.p, Object.assign({ p: 2, fontSize: "xs", textAlign: "center", color: "gray.600" }, { children: ["By signing up you agree to our", ' ', (0, jsx_runtime_1.jsx)(react_3.chakra.a, Object.assign({ color: "brand.500" }, { children: "Terms of Service" }))] }))] }) })), (0, jsx_runtime_1.jsx)(react_router_dom_1.Link, Object.assign({ to: "/" }, { children: (0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ pt: 3 }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Already have an account?" }) })) }))] }));
}
exports["default"] = Register;


/***/ }),

/***/ 33659:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VaultImportExport = exports.onJsonFileAccepted = exports.onCSVFileAccepted = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __webpack_require__(53159);
const ExportCsvButtons_1 = __webpack_require__(12235);
const ImportFromFile_1 = __webpack_require__(37251);
const react_3 = __importDefault(__webpack_require__(27378));
const papaparse_1 = __importDefault(__webpack_require__(46381));
const ExtensionDevice_1 = __webpack_require__(2247);
const graphqlBaseTypes_1 = __webpack_require__(89931);
const AccountLimits_codegen_1 = __webpack_require__(54417);
const Providers_1 = __webpack_require__(62142);
// const csvHeaderNames = {
//   password: [
//     'password',
//     'login_password'
//   ],
//   url: [
//     'url', // lastpass
//     'login_uri' // bitwarden
//   ]
// }
const mapCsvToLoginCredentials = csv => {
    const [header] = csv;
    const indexUsername = header.findIndex(x => x.match(/username/i));
    const indexLabel = header.findIndex(x => x === 'name');
    const indexPassword = header.findIndex(x => x.match(/password/i));
    const indexUrl = header.findIndex(x => {
        return x === 'url' || x === 'login_uri';
    });
    if (indexUsername === -1 || indexLabel === -1 || indexPassword === -1 || indexUrl === -1) {
        return [];
    }
    return csv.slice(1).filter(row => row[indexUrl] && row[indexUsername] && row[indexPassword]).map(row => ({
        label: row[indexLabel],
        url: row[indexUrl],
        username: row[indexUsername],
        password: row[indexPassword],
        iconUrl: null // TODO add icon Url if it is in the CSV
    }));
};
/**
 * should support lastpass and bitwarden for now, TODO write e2e specs
 */
const onCSVFileAccepted = (file, pswCount) => {
    return new Promise(resolve => {
        papaparse_1.default.parse(file, {
            complete: (results) => __awaiter(void 0, void 0, void 0, function* () {
                var _a, _b;
                if (!results.data) {
                    (0, Providers_1.toast)({
                        title: 'failed to parse',
                        status: 'error',
                        isClosable: true
                    });
                }
                const mapped = mapCsvToLoginCredentials(results.data);
                const state = ExtensionDevice_1.device.state;
                const toAdd = [];
                let skipped = 0;
                let added = 0;
                for (const creds of mapped) {
                    if (((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.decryptedSecrets.length) + added >= pswCount) {
                        (0, Providers_1.toast)({
                            title: 'You have reached your limit of secrets',
                            status: 'error',
                            isClosable: true
                        });
                        break;
                    }
                    let hostname;
                    try {
                        hostname = new URL(creds.url).hostname;
                    }
                    catch (error) {
                        skipped++;
                        break;
                    }
                    const input = {
                        kind: graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS,
                        loginCredentials: creds,
                        url: creds.url,
                        encrypted: yield (state === null || state === void 0 ? void 0 : state.encrypt(JSON.stringify(creds))),
                        createdAt: new Date().toJSON(),
                        iconUrl: null,
                        label: (_b = creds.label) !== null && _b !== void 0 ? _b : `${creds.username}@${hostname}`
                    };
                    if (yield state.findExistingSecret(input)) {
                        skipped++;
                        continue;
                    }
                    toAdd.push(input);
                    added += 1;
                }
                yield state.addSecrets(toAdd);
                resolve({
                    added,
                    skipped
                });
            })
        });
    });
};
exports.onCSVFileAccepted = onCSVFileAccepted;
const onJsonFileAccepted = (file) => __awaiter(void 0, void 0, void 0, function* () {
    const state = ExtensionDevice_1.device.state;
    const parsed = JSON.parse(yield file.text());
    const toAdd = [];
    for (const totp of parsed) {
        if (!totp.originalName) {
            continue; // for some reason authy has secrets without any name. These are not shown in the Authy app, so we are skipping. Nobody would know what these secrets are for anyway
        }
        const totpWithMeta = Object.assign(Object.assign({}, totp), { iconUrl: null, label: totp.originalName });
        toAdd.push({
            kind: graphqlBaseTypes_1.EncryptedSecretType.TOTP,
            totp: totpWithMeta,
            encrypted: yield state.encrypt(JSON.stringify(totpWithMeta)),
            createdAt: new Date().toJSON()
        });
    }
    yield state.addSecrets(toAdd);
    return {
        added: toAdd.length,
        skipped: 0
    };
});
exports.onJsonFileAccepted = onJsonFileAccepted;
const VaultImportExport = () => {
    const [importedStat, setImportedStat] = react_3.default.useState(null);
    const { data } = (0, AccountLimits_codegen_1.useMeExtensionQuery)();
    return (0, jsx_runtime_1.jsx)(react_2.Center, Object.assign({ p: 5 }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ maxW: '1200px', flexDir: 'column' }, { children: [(0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "sm" }, { children: "Import" })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ p: 30, width: "100%" }, { children: !importedStat ? (0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(ImportFromFile_1.ImportFromFile, { onFileAccepted: (f) => __awaiter(void 0, void 0, void 0, function* () {
                                    if (f.type === 'text/csv') {
                                        setImportedStat(yield (0, exports.onCSVFileAccepted)(f, data === null || data === void 0 ? void 0 : data.me.PasswordLimits));
                                    }
                                    else if (f.type === 'application/json') {
                                        setImportedStat(yield (0, exports.onJsonFileAccepted)(f));
                                    }
                                }) }), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: 16, mt: 8, mb: 6 }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "We support importing from <0>csv</0> and <1>json</1> files.<2><3>Lastpass/Bitwarden will work fine, file exported from other password managers might work as well, but it's not guaranteed.</3><4>For JSON, it must be a file exported from <5>authy-desktop-export</5></4></2>", components: {
                                        0: (0, jsx_runtime_1.jsx)("code", {}),
                                        1: (0, jsx_runtime_1.jsx)("code", {}),
                                        2: (0, jsx_runtime_1.jsx)("ul", {}),
                                        3: (0, jsx_runtime_1.jsx)("li", {}),
                                        4: (0, jsx_runtime_1.jsx)("li", {}),
                                        5: (0, jsx_runtime_1.jsx)(react_2.Link, { href: "https://www.npmjs.com/package/authy-desktop-export" })
                                    } }) }))] }) : (0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(react_2.Alert, Object.assign({ status: "success" }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Successfully added {0}, skipped {1}", values: {
                                        0: importedStat.added,
                                        1: importedStat.skipped
                                    } }) })), (0, jsx_runtime_1.jsx)(react_2.Center, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ m: 2, onClick: () => {
                                        setImportedStat(null);
                                    } }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Import another" }) })) })] }) })), (0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "sm" }, { children: "Export" })), (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ m: 8 }, { children: [(0, jsx_runtime_1.jsx)(ExportCsvButtons_1.ExportLoginCredentialsToCsvButton, {}), (0, jsx_runtime_1.jsx)("br", {}), (0, jsx_runtime_1.jsx)(ExportCsvButtons_1.ExportTOTPToCsvButton, {})] }))] })) }));
};
exports.VaultImportExport = VaultImportExport;


/***/ }),

/***/ 24099:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VaultList = exports.VaultListItem = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const core_1 = __webpack_require__(20905);
const button_1 = __webpack_require__(76844);
const color_mode_1 = __webpack_require__(4876);
const icons_1 = __webpack_require__(26765);
const react_1 = __webpack_require__(53159);
const react_2 = __importStar(__webpack_require__(27378));
const DeviceStateProvider_1 = __webpack_require__(58311);
const react_router_dom_1 = __webpack_require__(36634);
const DeleteAlert_1 = __webpack_require__(34605);
const SecretItemIcon_1 = __webpack_require__(77033);
const RefreshSecretsButton_1 = __webpack_require__(5843);
const ExtensionDevice_1 = __webpack_require__(2247);
const EncryptedSecrets_codegen_1 = __webpack_require__(98533);
const Settings_codegen_1 = __webpack_require__(95403);
const VirtualizedList_1 = __webpack_require__(82084);
function VaultListItem({ secret }) {
    const [isVisible, setIsVisible] = (0, react_2.useState)(false);
    const { isOpen, onOpen, onClose } = (0, react_1.useDisclosure)();
    const [deleteEncryptedSecretMutation] = (0, EncryptedSecrets_codegen_1.useDeleteEncryptedSecretMutation)();
    const { deviceState } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    if (!deviceState) {
        return null;
    }
    const secretUrl = (0, ExtensionDevice_1.getDecryptedSecretProp)(secret, 'url');
    return (0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ py: 5, m: ['auto', '3'] }, { children: (0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ w: "250px", h: "195px", bg: (0, color_mode_1.useColorModeValue)('white', 'gray.800'), boxShadow: '2xl', rounded: 'md', overflow: 'hidden', onMouseOver: () => setIsVisible(true), onMouseOut: () => setIsVisible(false) }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ bg: 'gray.100', h: "70%", pos: 'relative' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ h: 130 }, { children: (0, jsx_runtime_1.jsx)(SecretItemIcon_1.SecretItemIcon, { url: secretUrl, iconUrl: (0, ExtensionDevice_1.getDecryptedSecretProp)(secret, 'iconUrl') }) })), (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ display: isVisible ? 'flex' : 'none', alignItems: "center", justifyContent: "center", zIndex: 9, position: "absolute", top: 0, bgColor: "blackAlpha.600", w: "100%", h: "full" }, { children: [secretUrl ? (0, jsx_runtime_1.jsx)(button_1.IconButton, { "aria-label": "open item", colorScheme: "blackAlpha", icon: (0, jsx_runtime_1.jsx)(icons_1.UnlockIcon, {}), onClick: () => chrome.tabs.create({
                                        url: secretUrl
                                    }) }) : null, (0, jsx_runtime_1.jsx)(icons_1.DeleteIcon, { cursor: 'pointer', boxSize: 26, padding: 1.5, overflow: 'visible', backgroundColor: 'red.400', _hover: {
                                        backgroundColor: 'red.500'
                                    }, position: 'absolute', right: "0", top: "inherit", onClick: onOpen }), (0, jsx_runtime_1.jsx)(DeleteAlert_1.DeleteAlert, { isOpen: isOpen, onClose: onClose, deleteItem: () => __awaiter(this, void 0, void 0, function* () {
                                        var _a;
                                        yield deleteEncryptedSecretMutation({
                                            variables: {
                                                id: secret.id
                                            }
                                        });
                                        yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.removeSecret(secret.id));
                                    }) })] }))] })), (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "row", align: "center", justifyContent: "space-between", p: 4 }, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontWeight: 'bold', fontSize: 'lg', noOfLines: 1 }, { children: (0, ExtensionDevice_1.getDecryptedSecretProp)(secret, 'label') })), (0, jsx_runtime_1.jsx)(react_router_dom_1.Link, Object.assign({ to: {
                                pathname: `secret/${secret.id}`
                            }, state: {
                                data: secret
                            } }, { children: (0, jsx_runtime_1.jsx)(button_1.IconButton, { size: "sm", display: isVisible ? 'block' : 'none', "aria-label": "open item", colorScheme: "gray", icon: (0, jsx_runtime_1.jsx)(icons_1.SettingsIcon, {}) }) }))] }))] })) }));
}
exports.VaultListItem = VaultListItem;
const VaultList = () => {
    const { loginCredentials: LoginCredentials, TOTPSecrets } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const [filterBy, setFilterBy] = (0, react_2.useState)('');
    const navigate = (0, react_router_dom_1.useNavigate)();
    const { setSecuritySettings } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { data, loading, error } = (0, Settings_codegen_1.useSyncSettingsQuery)();
    const { colorMode, toggleColorMode } = (0, react_1.useColorMode)();
    // Here is bug wut theme change, this is not ideal
    (0, react_2.useEffect)(() => {
        var _a, _b;
        if (data) {
            if (colorMode !== data.me.theme) {
                toggleColorMode();
            }
            setSecuritySettings({
                autofill: (_a = data.me) === null || _a === void 0 ? void 0 : _a.autofill,
                language: (_b = data.me) === null || _b === void 0 ? void 0 : _b.language,
                syncTOTP: data.currentDevice.syncTOTP,
                vaultLockTimeoutSeconds: data.currentDevice.vaultLockTimeoutSeconds
            });
        }
    }, [data, loading]);
    if (loading && !data) {
        return (0, jsx_runtime_1.jsx)(react_1.Spinner, {});
    }
    console.log(data === null || data === void 0 ? void 0 : data.me.TOTPlimit, ExtensionDevice_1.device.state);
    //TODO: resolve this bullshit
    // const totpCond =
    //   data?.me?.TOTPlimit ??
    //   0 <=
    //     device?.state?.decryptedSecrets.filter((x) => x.kind === 'TOTP').length ??
    //   0
    // const pswCond =
    //   data.me.PasswordLimits ??
    //   0 <=
    //     device.state.decryptedSecrets.filter(
    //       (x) => x.kind === 'LOGIN_CREDENTIALS'
    //     ).length
    return (0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ flexDirection: "column", h: '90vh' }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Center, Object.assign({ justifyContent: 'space-evenly', w: '100%' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Input, { variant: 'filled', color: "grey.600", w: ['300px', '350px', '400px', '500px'], placeholder: /*i18n*/ core_1.i18n._("Search vault"), m: "auto", onChange: ev => {
                            setFilterBy(ev.target.value);
                        } }), (0, jsx_runtime_1.jsxs)(react_1.Center, Object.assign({ px: 3 }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Stat, Object.assign({ ml: "auto", whiteSpace: 'nowrap' }, { children: [LoginCredentials.length + TOTPSecrets.length, " ", /*i18n*/ core_1.i18n._("secrets")] })), (0, jsx_runtime_1.jsx)(RefreshSecretsButton_1.RefreshSecretsButton, {})] })), error ? (0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ shouldWrapChildren: true, label: "You have reached your limit", "aria-label": "A tooltip" }, { children: (0, jsx_runtime_1.jsx)(button_1.IconButton, { disabled: true, "aria-label": "Add item", icon: (0, jsx_runtime_1.jsx)(icons_1.AddIcon, {}), rounded: 'full', onClick: () => __awaiter(void 0, void 0, void 0, function* () { return navigate('/addItem'); }) }) })) : (0, jsx_runtime_1.jsx)(button_1.IconButton, { "aria-label": "Add item", icon: (0, jsx_runtime_1.jsx)(icons_1.AddIcon, {}), rounded: 'full', onClick: () => __awaiter(void 0, void 0, void 0, function* () { return navigate('/addItem'); }) })] })), (0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ w: '95%', h: '95%' }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ style: {
                        flex: '1 1 auto',
                        height: '100%',
                        width: '100%'
                    } }, { children: (0, jsx_runtime_1.jsx)(VirtualizedList_1.VirtualizedList, { filter: filterBy }) })) }))] }));
};
exports.VaultList = VaultList;


/***/ }),

/***/ 67735:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VaultRouter = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(27378);
const SidebarWithHeader_1 = __importDefault(__webpack_require__(4883));
const react_router_dom_1 = __webpack_require__(36634);
const ItemSettings_1 = __webpack_require__(78073);
const VaultSettings_1 = __webpack_require__(60747);
const Login_1 = __importDefault(__webpack_require__(61556));
const react_2 = __webpack_require__(53159);
const Devices_1 = __importDefault(__webpack_require__(14952));
const VaultImportExport_1 = __webpack_require__(33659);
const Register_1 = __importDefault(__webpack_require__(6974));
const AddItem_1 = __webpack_require__(87573);
const DeviceStateProvider_1 = __webpack_require__(58311);
const VaultUnlockVerification_1 = __webpack_require__(56972);
const VaultList_1 = __webpack_require__(24099);
const AccountLimits_1 = __webpack_require__(7401);
function VaultRouter() {
    const { device, deviceState } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const navigate = (0, react_router_dom_1.useNavigate)();
    (0, react_1.useEffect)(() => {
        if (device.lockedState) {
            navigate('verify');
        }
        else {
            navigate('/');
        }
        console.log('VaultRouter: useEffect');
    }, [device.lockedState]);
    if (deviceState === null) {
        return (0, jsx_runtime_1.jsx)(react_2.Center, Object.assign({ marginX: "50%", h: "100vh" }, { children: (0, jsx_runtime_1.jsxs)(react_router_dom_1.Routes, { children: [(0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/", element: (0, jsx_runtime_1.jsx)(Login_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/signup", element: (0, jsx_runtime_1.jsx)(Register_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/verify", element: (0, jsx_runtime_1.jsx)(VaultUnlockVerification_1.VaultUnlockVerification, {}) })] }) }));
    }
    return (0, jsx_runtime_1.jsx)(SidebarWithHeader_1.default, { children: (0, jsx_runtime_1.jsxs)(react_router_dom_1.Routes, { children: [(0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/", element: (0, jsx_runtime_1.jsx)(VaultList_1.VaultList, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/secret/:secretId", element: (0, jsx_runtime_1.jsx)(ItemSettings_1.VaultItemSettings, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/account-limits", element: (0, jsx_runtime_1.jsx)(AccountLimits_1.AccountLimits, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/settings/*", element: (0, jsx_runtime_1.jsx)(VaultSettings_1.VaultSettings, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/devices", element: (0, jsx_runtime_1.jsx)(Devices_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/import-export", element: (0, jsx_runtime_1.jsx)(VaultImportExport_1.VaultImportExport, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/addItem", element: (0, jsx_runtime_1.jsx)(AddItem_1.AddItem, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/devices", element: (0, jsx_runtime_1.jsx)(Devices_1.default, {}) })] }) });
}
exports.VaultRouter = VaultRouter;


/***/ }),

/***/ 60747:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VaultSettings = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_router_dom_1 = __webpack_require__(36634);
const react_2 = __importStar(__webpack_require__(27378));
const Account_1 = __importDefault(__webpack_require__(99161));
const VaultConfig_1 = __importDefault(__webpack_require__(56452));
const framer_motion_1 = __webpack_require__(10238);
const LinkItems = [{
        name: 'Account',
        path: '/account'
    }, {
        name: 'Security',
        path: '/security'
    }];
const NavLink = ({ name, path, handleClick, url, selected }) => {
    return (0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ as: react_router_dom_1.Link, to: url + path, style: {
            textDecoration: 'none'
        } }, { children: (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ verticalAlign: "center", px: 2, py: 1, borderRadius: "lg", role: "group", cursor: "pointer", fontSize: 20, bgColor: selected.name === name ? (0, react_1.useColorModeValue)('gray.100', 'gray.700') : 'transparent', onClick: () => handleClick() }, { children: name })) }));
};
const VaultSettings = () => {
    const location = (0, react_router_dom_1.useLocation)();
    const [selectedTab, setSelectedTab] = (0, react_2.useState)(LinkItems[0]);
    (0, react_2.useEffect)(() => {
        if (location.pathname === '/settings/account') {
            setSelectedTab(LinkItems[0]);
        }
        else if (location.pathname === '/settings/security') {
            setSelectedTab(LinkItems[1]);
        }
    }, [location]);
    return (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ align: 'center', justify: 'center', flexDirection: 'column' }, { children: [(0, jsx_runtime_1.jsx)(react_1.HStack, Object.assign({ as: 'nav', spacing: 4, mb: 10 }, { children: LinkItems.map(link => {
                    const handleClick = () => {
                        setSelectedTab(link);
                    };
                    return (0, jsx_runtime_1.jsx)(NavLink, { path: link.path, selected: selectedTab, handleClick: handleClick, name: link.name, url: '/settings' }, link.name);
                }) })), (0, jsx_runtime_1.jsx)(framer_motion_1.AnimatePresence, Object.assign({ exitBeforeEnter: true }, { children: (0, jsx_runtime_1.jsxs)(react_router_dom_1.Routes, { children: [(0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: '/account', element: (0, jsx_runtime_1.jsx)(Account_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: '/security', element: (0, jsx_runtime_1.jsx)(VaultConfig_1.default, {}) })] }, location.pathname) }))] }));
};
exports.VaultSettings = VaultSettings;


/***/ }),

/***/ 75128:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useDebounce = void 0;
const react_1 = __webpack_require__(27378);
function useDebounce(value, delay) {
    // State and setters for debounced value
    const [debouncedValue, setDebouncedValue] = (0, react_1.useState)(value);
    (0, react_1.useEffect)(() => {
        // Update debounced value after delay
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);
        // Cancel the timeout if value changes (also on delay change or unmount)
        // This is how we prevent debounced value from updating if value is changed ...
        // .. within the delay period. Timeout gets cleared and restarted.
        return () => {
            clearTimeout(handler);
        };
    }, [value, delay] // Only re-call effect if value or delay changes
    );
    return debouncedValue;
}
exports.useDebounce = useDebounce;


/***/ }),

/***/ 85053:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AboutPage = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __importDefault(__webpack_require__(27378));
const package_json_1 = __importDefault(__webpack_require__(4147));
const layout_1 = __webpack_require__(64178);
const react_3 = __webpack_require__(53159);
const AboutPage = () => {
    return (0, jsx_runtime_1.jsx)(layout_1.Center, Object.assign({ m: 2, p: 2 }, { children: (0, jsx_runtime_1.jsxs)(layout_1.Stack, Object.assign({ direction: "column" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Heading, Object.assign({ size: "md" }, { children: "Authier web extension" })), (0, jsx_runtime_1.jsx)(react_3.Text, Object.assign({ fontSize: 'large' }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Version: {0}", values: {
                            0: package_json_1.default.version
                        } }) }))] })) }));
};
exports.AboutPage = AboutPage;


/***/ }),

/***/ 13402:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importDefault(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const icons_1 = __webpack_require__(26765);
const io_1 = __webpack_require__(51649);
const AccountDevices_codegen_1 = __webpack_require__(8756);
function Devices() {
    var _a;
    const { data, loading, error } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    return (0, jsx_runtime_1.jsxs)(react_2.Box, { children: [data && !loading ? (_a = data.me) === null || _a === void 0 ? void 0 : _a.devices.map(device => {
                return (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ boxShadow: "xl", 
                    //bg="white"
                    m: 2, pb: 2, flexDirection: "column", borderWidth: "5px" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ justifyContent: "flex-end", mr: 2 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ hasArrow: true, label: "Main device", fontSize: "sm" }, { children: (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "xs", variant: "unstyled", "aria-label": "Main device", fontSize: "17px", icon: (0, jsx_runtime_1.jsx)(icons_1.StarIcon, { color: "gold" }) }) })), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ hasArrow: true, label: "Remove device", fontSize: "sm" }, { children: (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "xs", variant: "unstyled", "aria-label": "Remove device", fontSize: "17px", icon: (0, jsx_runtime_1.jsx)(icons_1.DeleteIcon, {}) }) }))] })), (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ justify: "flex-start", align: "center", flexDirection: "row" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Icon, { as: io_1.IoIosPhonePortrait, w: 20, h: 20 }), (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDirection: "column", ml: "5px", fontSize: "md" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, { children: device.name }), (0, jsx_runtime_1.jsx)(react_2.Text, { children: device.lastIpAddress }), (0, jsx_runtime_1.jsxs)(react_2.Text, { children: ["Location: ", device.lastGeoLocation] })] }))] }))] }), device.lastIpAddress);
            }) : (0, jsx_runtime_1.jsx)(react_2.Spinner, {}), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ onClick: () => {
                    //setLocation('/qr-code')
                } }, { children: "Add device" }))] });
}
exports["default"] = Devices;


/***/ }),

/***/ 95107:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Home = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importStar(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const otplib_1 = __webpack_require__(77778);
const DeviceStateProvider_1 = __webpack_require__(58311);
const icons_1 = __webpack_require__(26765);
const AuthsList_1 = __webpack_require__(19427);
const Home = () => {
    const [seconds, setRemainingSeconds] = (0, react_1.useState)(otplib_1.authenticator.timeRemaining());
    const { deviceState, TOTPSecrets, currentURL } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    (0, react_2.useInterval)(() => {
        setRemainingSeconds(otplib_1.authenticator.timeRemaining());
    }, 1000);
    const [filterByTLDManual, setFilterByTLD] = (0, react_1.useState)(null); // when in vault or browser config, show all: ;
    const filterByTLD = !currentURL ? true : filterByTLDManual === null ? currentURL.startsWith('http') : filterByTLDManual;
    return (0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ position: "sticky", align: "center", pl: 4, pr: 4, mt: '56px' }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ display: "flex", alignItems: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ mb: "0" }, { children: "Filter by TLD" })), (0, jsx_runtime_1.jsx)(react_2.Switch, { mr: "auto", isChecked: filterByTLD, onChange: enabled => {
                                    setFilterByTLD(enabled.target.checked);
                                } })] })), (0, jsx_runtime_1.jsx)(react_2.IconButton, { mr: 15, colorScheme: "blue", "aria-label": "Add item", icon: (0, jsx_runtime_1.jsx)(icons_1.AddIcon, {}), rounded: 'full', onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                            chrome.tabs.create({
                                url: 'vault.html#/addItem'
                            });
                        }) }), deviceState && TOTPSecrets.length > 0 && (0, jsx_runtime_1.jsx)(react_2.CircularProgress, { min: 1, ml: "auto", max: 30, value: 30 - seconds, valueText: seconds.toString(), size: "40px" })] })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ height: 300, width: 350, pr: 5, pl: 5, mb: 2 }, { children: (0, jsx_runtime_1.jsx)(react_2.Grid, Object.assign({ gap: 3, mb: 5 }, { children: (0, jsx_runtime_1.jsx)(AuthsList_1.AuthsList, { filterByTLD: filterByTLD }) })) }))] });
};
exports.Home = Home;


/***/ }),

/***/ 24186:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.NavMenu = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importDefault(__webpack_require__(27378));
const react_2 = __webpack_require__(53159);
const icons_1 = __webpack_require__(26765);
const wouter_1 = __webpack_require__(17331);
const AddTOTPSecretButton_1 = __webpack_require__(11687);
const NavMenu = () => {
    const bg = (0, react_2.useColorModeValue)('teal.200', 'teal.700');
    return (0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ direction: "row", bgColor: bg, justify: "center", p: "10px" }, { children: [(0, jsx_runtime_1.jsx)(react_2.ButtonGroup, Object.assign({ spacing: 4 }, { children: (0, jsx_runtime_1.jsxs)(react_2.Stack, { children: [(0, jsx_runtime_1.jsx)(wouter_1.Link, Object.assign({ to: "/" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ colorScheme: "teal" }, { children: "Secrets" })) })), (0, jsx_runtime_1.jsx)(AddTOTPSecretButton_1.AddTOTPSecretButton, {})] }) })), (0, jsx_runtime_1.jsx)(react_2.ButtonGroup, Object.assign({ spacing: 4, variant: "solid", m: "10px" }, { children: (0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ direction: "column" }, { children: [(0, jsx_runtime_1.jsx)(wouter_1.Link, Object.assign({ to: "/about" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ leftIcon: (0, jsx_runtime_1.jsx)(icons_1.InfoOutlineIcon, {}) }, { children: "About" })) })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ onClick: () => {
                                chrome.tabs.create({
                                    url: 'vault.html'
                                });
                            } }, { children: "My vault" }))] })) }))] }));
};
exports.NavMenu = NavMenu;


/***/ }),

/***/ 8884:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useDeviceCountLazyQuery = exports.useDeviceCountQuery = exports.DeviceCountDocument = void 0;
const client_1 = __webpack_require__(17547);
const Apollo = __importStar(__webpack_require__(17547));
const defaultOptions = {};
exports.DeviceCountDocument = (0, client_1.gql) `
    query DeviceCount {
  me {
    devicesCount
  }
}
    `;
/**
 * __useDeviceCountQuery__
 *
 * To run a query within a React component, call `useDeviceCountQuery` and pass it any options that fit your needs.
 * When your component renders, `useDeviceCountQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useDeviceCountQuery({
 *   variables: {
 *   },
 * });
 */
function useDeviceCountQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.DeviceCountDocument, options);
}
exports.useDeviceCountQuery = useDeviceCountQuery;
function useDeviceCountLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.DeviceCountDocument, options);
}
exports.useDeviceCountLazyQuery = useDeviceCountLazyQuery;


/***/ }),

/***/ 17612:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.QRCode = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(53159);
const react_2 = __importStar(__webpack_require__(27378));
const react_qr_code_1 = __importDefault(__webpack_require__(1653));
const QRcode_codegen_1 = __webpack_require__(8884);
const wouter_1 = __webpack_require__(17331);
const icons_1 = __webpack_require__(26765);
const UserProvider_1 = __webpack_require__(59871);
function QRCode() {
    const [interval, setInterval] = (0, react_2.useState)(500);
    const [location, setLocation] = (0, wouter_1.useLocation)();
    const [count, setCount] = (0, react_2.useState)(1);
    const { userId } = (0, react_2.useContext)(UserProvider_1.UserContext);
    const { data, error, startPolling, stopPolling } = (0, QRcode_codegen_1.useDeviceCountQuery)();
    (0, react_2.useEffect)(() => {
        startPolling(interval);
    }, []);
    (0, react_2.useEffect)(() => {
        var _a, _b;
        const devicesCount = (_b = (_a = data === null || data === void 0 ? void 0 : data.me) === null || _a === void 0 ? void 0 : _a.devicesCount) !== null && _b !== void 0 ? _b : 0;
        if (typeof count !== undefined && devicesCount > count) {
            stopPolling();
            setLocation('/');
        }
    }, [data]);
    return (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "column", alignItems: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ as: "h3", size: "lg" }, { children: "Scan QR code in app" })), (0, jsx_runtime_1.jsx)(react_qr_code_1.default, { size: 200, value: userId }), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ variant: "outline", onClick: () => {
                    stopPolling();
                    setLocation('/');
                }, leftIcon: (0, jsx_runtime_1.jsx)(icons_1.ArrowForwardIcon, {}) }, { children: "Skip" }))] }));
}
exports.QRCode = QRCode;


/***/ }),

/***/ 70419:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UserNavMenu = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const react_2 = __importDefault(__webpack_require__(27378));
const react_3 = __webpack_require__(53159);
const ExtensionDevice_1 = __webpack_require__(2247);
const UserNavMenu = () => {
    var _a;
    const bg = (0, react_3.useColorModeValue)('teal.200', 'teal.700');
    return (0, jsx_runtime_1.jsxs)(react_3.Stack, Object.assign({ direction: "row", bgColor: bg, justify: "center", p: "10px" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Center, { children: (0, jsx_runtime_1.jsxs)(react_3.Heading, Object.assign({ size: 'sm' }, { children: ["Logged as ", (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.email] })) }), (0, jsx_runtime_1.jsx)(react_3.ButtonGroup, Object.assign({ spacing: 4, variant: "solid", m: "10px" }, { children: (0, jsx_runtime_1.jsxs)(react_3.Stack, Object.assign({ direction: "column" }, { children: [(0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ colorScheme: "yellow", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                ExtensionDevice_1.device.lock();
                            }) }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Lock vault" }) })), (0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ colorScheme: "red", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                ExtensionDevice_1.device.logout();
                            }) }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Logout" }) }))] })) }))] }));
};
exports.UserNavMenu = UserNavMenu;


/***/ }),

/***/ 56972:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.VaultUnlockVerification = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __webpack_require__(62747);
const core_1 = __webpack_require__(20905);
const react_2 = __webpack_require__(27378);
const react_3 = __webpack_require__(53159);
const formik_1 = __webpack_require__(99590);
const icons_1 = __webpack_require__(26765);
const generateEncryptionKey_1 = __webpack_require__(44038);
const DeviceStateProvider_1 = __webpack_require__(58311);
const Providers_1 = __webpack_require__(62142);
function VaultUnlockVerification() {
    const [showPassword, setShowPassword] = (0, react_2.useState)(false);
    const { setDeviceState, device } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { lockedState } = device;
    if (!lockedState) {
        return null;
    }
    return (0, jsx_runtime_1.jsxs)(react_3.Flex, Object.assign({ flexDirection: "column", width: "315px", p: 4 }, { children: [(0, jsx_runtime_1.jsx)(react_3.Center, { children: (0, jsx_runtime_1.jsx)(icons_1.LockIcon, { boxSize: "50px", mx: 20, my: 3 }) }), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                    password: ''
                }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        const masterEncryptionKey = yield (0, generateEncryptionKey_1.generateEncryptionKey)(values.password, (0, generateEncryptionKey_1.base64_to_buf)(lockedState.encryptionSalt));
                        const encryptedDataBuff = (0, generateEncryptionKey_1.base64_to_buf)(lockedState.authSecretEncrypted);
                        const iv = encryptedDataBuff.slice(16, 16 + 12);
                        const data = encryptedDataBuff.slice(16 + 12);
                        const decryptedContent = yield window.crypto.subtle.decrypt({
                            name: 'AES-GCM',
                            iv
                        }, masterEncryptionKey, data);
                        const currentAddDeviceSecret = generateEncryptionKey_1.dec.decode(decryptedContent);
                        if (currentAddDeviceSecret !== lockedState.authSecret) {
                            throw new Error(/*i18n*/ core_1.i18n._("Incorrect password"));
                        }
                        setDeviceState(Object.assign({ masterEncryptionKey: yield (0, generateEncryptionKey_1.cryptoKeyToString)(masterEncryptionKey) }, lockedState));
                        device.startLockInterval(lockedState.lockTime);
                        device.rerenderViews();
                        setSubmitting(false);
                    }
                    catch (err) {
                        console.log(err);
                        (0, Providers_1.toast)({
                            title: err.message,
                            status: 'error',
                            isClosable: true
                        });
                    }
                }) }, { children: props => (0, jsx_runtime_1.jsxs)(formik_1.Form, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "password" }, { children: ({ field, form }) => (0, jsx_runtime_1.jsxs)(react_3.FormControl, Object.assign({ isInvalid: form.errors.password && form.touched.password }, { children: [(0, jsx_runtime_1.jsx)(react_3.FormLabel, Object.assign({ htmlFor: "password" }, { children: (0, jsx_runtime_1.jsx)(react_3.Heading, Object.assign({ size: "md" }, { children: "Re-enter your Master Password" })) })), (0, jsx_runtime_1.jsxs)(react_3.InputGroup, { children: [(0, jsx_runtime_1.jsx)(react_3.Input, Object.assign({}, field, { type: showPassword ? 'text' : 'password' })), (0, jsx_runtime_1.jsx)(react_3.InputRightElement, Object.assign({ width: "3rem" }, { children: (0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ h: "1.5rem", size: "sm", onClick: () => setShowPassword(!showPassword) }, { children: showPassword ? (0, jsx_runtime_1.jsx)(icons_1.ViewOffIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ViewIcon, {}) })) }))] }), (0, jsx_runtime_1.jsx)(react_3.FormErrorMessage, { children: form.errors.password })] })) })), (0, jsx_runtime_1.jsx)(react_3.Button, Object.assign({ colorScheme: "teal", variant: "outline", isDisabled: props.values.password.length < 3, type: "submit", width: "full", mt: 4, isLoading: props.isSubmitting }, { children: (0, jsx_runtime_1.jsx)(react_1.Trans, { id: "Unlock vault" }) }))] }) }))] }));
}
exports.VaultUnlockVerification = VaultUnlockVerification;


/***/ }),

/***/ 9731:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Popup = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const react_1 = __importStar(__webpack_require__(27378));
const wouter_1 = __webpack_require__(17331);
const NavBar_1 = __webpack_require__(54016);
const Home_1 = __webpack_require__(95107);
const core_1 = __webpack_require__(20905);
const QRcode_1 = __webpack_require__(17612);
const Devices_1 = __importDefault(__webpack_require__(13402));
const AboutPage_1 = __webpack_require__(85053);
const debug_1 = __importDefault(__webpack_require__(96292));
const log = (0, debug_1.default)('au:Popup');
core_1.i18n.activate('en');
const Popup = () => {
    const [location, setLocation] = (0, wouter_1.useLocation)();
    (0, react_1.useEffect)(() => {
        setLocation('/');
        //browser.runtime.sendMessage({ popupMounted: true })
    }, []);
    return (0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(NavBar_1.NavBar, {}), (0, jsx_runtime_1.jsxs)(wouter_1.Switch, Object.assign({ location: location }, { children: [(0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/", component: Home_1.Home }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/secrets", component: Home_1.Home }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/popup.html", component: Home_1.Home }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/qr-code", component: QRcode_1.QRCode }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/devices", component: Devices_1.default }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/about", component: AboutPage_1.AboutPage })] }))] });
};
exports.Popup = Popup;


/***/ }),

/***/ 58311:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DeviceStateProvider = exports.DeviceStateContext = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const useDeviceState_1 = __webpack_require__(6169);
const react_1 = __importStar(__webpack_require__(27378));
exports.DeviceStateContext = (0, react_1.createContext)({});
const DeviceStateProvider = ({ children }) => {
    const deviceState = (0, useDeviceState_1.useDeviceState)();
    return (0, jsx_runtime_1.jsx)(exports.DeviceStateContext.Provider, Object.assign({ value: deviceState }, { children: children }));
};
exports.DeviceStateProvider = DeviceStateProvider;


/***/ }),

/***/ 59871:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UserProvider = exports.UserContext = void 0;
const jsx_runtime_1 = __webpack_require__(87800);
const accessTokenExtension_1 = __webpack_require__(27690);
const react_1 = __importStar(__webpack_require__(27378));
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
exports.UserContext = (0, react_1.createContext)({});
const UserProvider = ({ children }) => {
    const [userId, setUserId] = (0, react_1.useState)();
    const [localStorage, setLocalStorage] = (0, react_1.useState)();
    (0, react_1.useEffect)(() => {
        function checkStorage() {
            return __awaiter(this, void 0, void 0, function* () {
                const storage = yield webextension_polyfill_1.default.storage.local.get();
                setLocalStorage(storage.encryptedAuthsMasterPassword);
                return storage;
            });
        }
        checkStorage();
        function getId() {
            return __awaiter(this, void 0, void 0, function* () {
                try {
                    const id = yield (0, accessTokenExtension_1.getUserFromToken)();
                    setUserId(id.userId);
                }
                catch (err) {
                    console.log(err);
                }
            });
        }
        getId();
    }, []);
    const value = {
        setUserId,
        userId,
        localStorage
    };
    return (0, jsx_runtime_1.jsx)(exports.UserContext.Provider, Object.assign({ value: value }, { children: children }));
};
exports.UserProvider = UserProvider;


/***/ }),

/***/ 27690:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getUserFromToken = exports.removeToken = exports.setAccessToken = exports.getTokenFromLocalStorage = exports.accessToken = void 0;
const jwt_decode_1 = __importDefault(__webpack_require__(26601));
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
exports.accessToken = null;
const getTokenFromLocalStorage = () => __awaiter(void 0, void 0, void 0, function* () {
    const storage = yield webextension_polyfill_1.default.storage.local.get('access-token');
    return storage['access-token'];
});
exports.getTokenFromLocalStorage = getTokenFromLocalStorage;
const setAccessToken = (s) => __awaiter(void 0, void 0, void 0, function* () {
    exports.accessToken = s;
    yield webextension_polyfill_1.default.storage.local.set({
        'access-token': s
    });
});
exports.setAccessToken = setAccessToken;
const removeToken = () => __awaiter(void 0, void 0, void 0, function* () {
    yield webextension_polyfill_1.default.storage.local.remove('access-token');
    exports.accessToken = '';
});
exports.removeToken = removeToken;
const getUserFromToken = () => __awaiter(void 0, void 0, void 0, function* () {
    return (0, jwt_decode_1.default)(yield (0, exports.getTokenFromLocalStorage)());
});
exports.getUserFromToken = getUserFromToken;
(() => __awaiter(void 0, void 0, void 0, function* () {
    exports.accessToken = yield (0, exports.getTokenFromLocalStorage)();
}))();


/***/ }),

/***/ 24282:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.downloadAsFile = void 0;
const js_file_download_1 = __importDefault(__webpack_require__(86613));
const slugify_1 = __importDefault(__webpack_require__(61485));
const date_fns_1 = __webpack_require__(66446);
const downloadAsFile = (fileData, prefix, extension = 'csv') => {
    (0, js_file_download_1.default)(fileData, `${prefix}-${(0, slugify_1.default)((0, date_fns_1.formatISO)(new Date()), {
        replacement: '-'
    })}.${extension}`);
};
exports.downloadAsFile = downloadAsFile;


/***/ }),

/***/ 79565:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.executeScriptInCurrentTab = exports.getCurrentTab = void 0;
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
function getCurrentTab() {
    return __awaiter(this, void 0, void 0, function* () {
        const tabs = yield webextension_polyfill_1.default.tabs.query({
            active: true,
            currentWindow: true
        });
        // Pulls current tab from browser.tabs.query response
        const currentTab = tabs[0];
        return currentTab;
    });
}
exports.getCurrentTab = getCurrentTab;
/**
 * Executes a string of Javascript on the current tab
 * @param code The string of code to execute on the current tab
 */
const executeScriptInCurrentTab = (code) => __awaiter(void 0, void 0, void 0, function* () {
    // Query for the active tab in the current window
    const currentTab = yield getCurrentTab();
    // Short circuits function execution is current tab isn't found
    if (!currentTab) {
        return;
    }
    const result = yield webextension_polyfill_1.default.tabs.executeScript(currentTab.id, {
        code
    });
    if (result[0]) {
        console.log('~ resul1t', result);
    }
    return result[0];
    // Executes the script in the current tab
});
exports.executeScriptInCurrentTab = executeScriptInCurrentTab;


/***/ }),

/***/ 53557:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.extractHostname = void 0;
function extractHostname(url) {
    let hostname;
    //find & remove protocol (http, ftp, etc.) and get hostname
    if (url.indexOf('//') > -1) {
        hostname = url.split('/')[2];
    }
    else {
        hostname = url.split('/')[0];
    }
    //find & remove port number
    hostname = hostname.split(':')[0];
    //find & remove "?"
    hostname = hostname.split('?')[0];
    return hostname.toLowerCase();
}
exports.extractHostname = extractHostname;


/***/ }),

/***/ 44038:
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.encryptedBuf_to_base64 = exports.base64_to_buf = exports.buff_to_base64 = exports.generateEncryptionKey = exports.dec = exports.enc = exports.abToCryptoKey = exports.cryptoKeyToString = void 0;
const PBKDF2Iterations = 300000;
/**
 * @returns string in base64
 */
function cryptoKeyToString(key) {
    return __awaiter(this, void 0, void 0, function* () {
        const raw = yield crypto.subtle.exportKey('raw', key);
        return (0, exports.buff_to_base64)(raw);
    });
}
exports.cryptoKeyToString = cryptoKeyToString;
function abToCryptoKey(raw) {
    return __awaiter(this, void 0, void 0, function* () {
        const cryptoKey = yield crypto.subtle.importKey('raw', raw, 'AES-GCM', true, ['decrypt', 'encrypt']);
        return cryptoKey;
    });
}
exports.abToCryptoKey = abToCryptoKey;
exports.enc = new TextEncoder();
exports.dec = new TextDecoder();
/**
 *
 *  Get some key material to use as input to the deriveKey method.
 *  The key material is a password supplied by the user.
 */
function getKeyMaterial(password) {
    return __awaiter(this, void 0, void 0, function* () {
        return window.crypto.subtle.importKey('raw', exports.enc.encode(password), 'PBKDF2', false, ['deriveBits', 'deriveKey']);
    });
}
function generateEncryptionKey(psw, salt) {
    return __awaiter(this, void 0, void 0, function* () {
        const keyMaterial = yield getKeyMaterial(psw);
        const key = yield window.crypto.subtle.deriveKey({
            name: 'PBKDF2',
            salt: salt,
            iterations: PBKDF2Iterations,
            hash: 'SHA-512'
        }, keyMaterial, {
            name: 'AES-GCM',
            length: 256
        }, true, ['encrypt', 'decrypt']);
        return key;
    });
}
exports.generateEncryptionKey = generateEncryptionKey;
const buff_to_base64 = buff => btoa(Array.from(new Uint8Array(buff)).map(b => String.fromCharCode(b)).join(''));
exports.buff_to_base64 = buff_to_base64;
const base64_to_buf = b64 => 
//FIX: What is this
//@ts-expect-error
Uint8Array.from(atob(b64), c => c.charCodeAt(null));
exports.base64_to_buf = base64_to_buf;
const encryptedBuf_to_base64 = (encryptedBuff, iv, salt) => {
    const encryptedContentArr = new Uint8Array(encryptedBuff);
    const newBuff = new Uint8Array(salt.byteLength + iv.byteLength + encryptedContentArr.byteLength);
    newBuff.set(salt, 0);
    newBuff.set(iv, salt.byteLength);
    newBuff.set(encryptedContentArr, salt.byteLength + iv.byteLength);
    return (0, exports.buff_to_base64)(newBuff);
};
exports.encryptedBuf_to_base64 = encryptedBuf_to_base64;


/***/ }),

/***/ 10285:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getQrCodeFromUrl = void 0;
const jsqr_1 = __importDefault(__webpack_require__(86981));
const getQrCodeFromUrl = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    const response = yield fetch(imageUrl);
    const fileBlob = yield response.blob();
    const bitmap = yield createImageBitmap(fileBlob);
    //TODO: Change, this option is limited on Firefox https://github.com/BabylonJS/Spector.js/issues/137#issue-550442024
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    const context = canvas.getContext('2d');
    if (context) {
        //TODO: Solve this error
        context.drawImage(bitmap, 0, 0);
        const imageData = context.getImageData(0, 0, bitmap.width, bitmap.height);
        const result = (0, jsqr_1.default)(imageData.data, imageData.width, imageData.height);
        return result;
    }
});
exports.getQrCodeFromUrl = getQrCodeFromUrl;


/***/ }),

/***/ 80245:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.totpSchema = exports.loginCredentialsSchema = void 0;
const zod_1 = __webpack_require__(78754);
const secretUrlsSchema = zod_1.z.object({
    url: zod_1.z.string().min(1),
    label: zod_1.z.string().min(1),
    androidUri: zod_1.z.string().min(1).nullable().optional(),
    iosUri: zod_1.z.string().min(1).nullable().optional(),
    iconUrl: zod_1.z.string().min(1).nullable()
});
exports.loginCredentialsSchema = secretUrlsSchema.extend({
    username: zod_1.z.string().min(1),
    password: zod_1.z.string().min(1)
});
exports.totpSchema = secretUrlsSchema.extend({
    secret: zod_1.z.string().min(1),
    digits: zod_1.z.number(),
    period: zod_1.z.number(),
    url: zod_1.z.string().min(1).nullish()
});


/***/ }),

/***/ 6169:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useDeviceState = void 0;
const react_1 = __webpack_require__(27378);
const webextension_polyfill_1 = __importDefault(__webpack_require__(39412));
const graphqlBaseTypes_1 = __webpack_require__(89931);
const debug_1 = __importDefault(__webpack_require__(96292));
const ExtensionDevice_1 = __webpack_require__(2247);
const executeScriptInCurrentTab_1 = __webpack_require__(79565);
const client_1 = __webpack_require__(22490);
const link_1 = __webpack_require__(2554);
const port = chrome.runtime.connect();
const trpc = (0, client_1.createTRPCProxyClient)({
    links: [(0, link_1.chromeLink)({
            port
        })]
});
const log = (0, debug_1.default)('au:useDeviceState');
let registered = false; // we need to only register once
function useDeviceState() {
    const [currentTab, setCurrentTab] = (0, react_1.useState)(null);
    const [currentURL, setCurrentURL] = (0, react_1.useState)('');
    const [isFilling, setIsFilling] = (0, react_1.useState)(false);
    const [deviceState, setDeviceState] = (0, react_1.useState)(ExtensionDevice_1.device.state);
    const onStorageChange = (changes, areaName) => __awaiter(this, void 0, void 0, function* () {
        log('onStorageChange useDevice', areaName, changes);
        if (areaName === 'local' && changes.backgroundState) {
            setDeviceState(changes.backgroundState.newValue);
            log('states loaded from storage');
        }
    });
    //TODO move this whole thing into it' own hook
    (0, react_1.useEffect)(() => {
        log('registering storage change listener');
        (0, executeScriptInCurrentTab_1.getCurrentTab)().then(tab => {
            var _a;
            setCurrentTab(tab !== null && tab !== void 0 ? tab : null);
            setCurrentURL((_a = tab === null || tab === void 0 ? void 0 : tab.url) !== null && _a !== void 0 ? _a : '');
        });
        if (registered) {
            return;
        }
        registered = true;
        webextension_polyfill_1.default.storage.onChanged.addListener(onStorageChange);
    }, []);
    const backgroundStateContext = {
        currentURL,
        deviceState,
        currentTab,
        get loginCredentials() {
            var _a;
            return (_a = deviceState === null || deviceState === void 0 ? void 0 : deviceState.decryptedSecrets.filter(({ kind }) => {
                return kind === graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS;
            })) !== null && _a !== void 0 ? _a : [];
        },
        get TOTPSecrets() {
            var _a;
            return (_a = deviceState === null || deviceState === void 0 ? void 0 : deviceState.decryptedSecrets.filter(({ kind }) => {
                return kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP;
            })) !== null && _a !== void 0 ? _a : [];
        },
        setSecuritySettings: (config) => __awaiter(this, void 0, void 0, function* () {
            yield trpc.securitySettings.mutate(config);
        }),
        setDeviceState: (state) => __awaiter(this, void 0, void 0, function* () {
            ExtensionDevice_1.device.save(state);
            yield trpc.setDeviceState.mutate(state);
        }),
        device: ExtensionDevice_1.device,
        isFilling,
        registered
    };
    window['backgroundState'] = backgroundStateContext;
    return backgroundStateContext;
}
exports.useDeviceState = useDeviceState;


/***/ })

}]);