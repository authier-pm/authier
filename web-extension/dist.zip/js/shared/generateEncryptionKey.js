"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.base64_to_buf = exports.buff_to_base64 = exports.generateEncryptionKey = exports.dec = exports.enc = exports.abToCryptoKey = exports.cryptoKeyToString = void 0;
const PBKDF2Iterations = 300000;
/**
 * @returns string in base64
 */
function cryptoKeyToString(key) {
    return __awaiter(this, void 0, void 0, function* () {
        const raw = yield crypto.subtle.exportKey('raw', key);
        return (0, exports.buff_to_base64)(raw);
    });
}
exports.cryptoKeyToString = cryptoKeyToString;
function abToCryptoKey(raw) {
    return __awaiter(this, void 0, void 0, function* () {
        const cryptoKey = yield crypto.subtle.importKey('raw', raw, 'AES-GCM', true, [
            'decrypt',
            'encrypt'
        ]);
        return cryptoKey;
    });
}
exports.abToCryptoKey = abToCryptoKey;
exports.enc = new TextEncoder();
exports.dec = new TextDecoder();
/**
 *
 *  Get some key material to use as input to the deriveKey method.
 *  The key material is a password supplied by the user.
 */
function getKeyMaterial(password) {
    return __awaiter(this, void 0, void 0, function* () {
        return window.crypto.subtle.importKey('raw', exports.enc.encode(password), 'PBKDF2', false, ['deriveBits', 'deriveKey']);
    });
}
function generateEncryptionKey(psw, salt) {
    return __awaiter(this, void 0, void 0, function* () {
        const keyMaterial = yield getKeyMaterial(psw);
        const key = yield window.crypto.subtle.deriveKey({
            name: 'PBKDF2',
            salt: salt,
            iterations: PBKDF2Iterations,
            hash: 'SHA-512'
        }, keyMaterial, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
        return key;
    });
}
exports.generateEncryptionKey = generateEncryptionKey;
const buff_to_base64 = (buff) => btoa(new Uint8Array(buff).reduce(function (data, byte) {
    return data + String.fromCharCode(byte);
}, ''));
exports.buff_to_base64 = buff_to_base64;
const base64_to_buf = (b64) => 
//FIX: What is this
//@ts-expect-error
Uint8Array.from(atob(b64), (c) => c.charCodeAt(null));
exports.base64_to_buf = base64_to_buf;
//# sourceMappingURL=generateEncryptionKey.js.map