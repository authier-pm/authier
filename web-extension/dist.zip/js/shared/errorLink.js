"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorLink = void 0;
const error_1 = require("@apollo/client/link/error");
const graphql_1 = require("graphql");
//@ts-ignore
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const Providers_1 = require("../web-extension/src/Providers");
// Log any GraphQL errors or network error that occurred
exports.errorLink = (0, error_1.onError)(({ graphQLErrors, networkError, operation }) => {
    var _a;
    if (graphQLErrors) {
        if (graphQLErrors[0].message === 'not authenticated') {
            //Here just logout the user
            ExtensionDevice_1.device.clearAndReload();
        }
        graphQLErrors.map(({ message, path }) => {
            console.error(`[GraphQL error]: Message: ${message}, operation: ${operation.operationName}, Path: ${path}`);
            console.error('full operation: ', (0, graphql_1.print)(operation.query));
        });
        (0, Providers_1.toast)({
            title: (_a = graphQLErrors[0].message) !== null && _a !== void 0 ? _a : 'There was API error.',
            status: 'warning',
            isClosable: true
        });
    }
    else if (networkError) {
        console.log('pepe');
        console.error(`[Network error]: ${networkError}`);
        (0, Providers_1.toast)({
            title: 'There was network error.',
            status: 'error',
            isClosable: true
        });
    }
});
//# sourceMappingURL=errorLink.js.map