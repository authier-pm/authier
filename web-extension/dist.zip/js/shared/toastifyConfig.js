"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toastifyConfig = void 0;
const react_toastify_1 = require("react-toastify"); // use react-toastify instead of chakra toast. Chakra toast is somehow weirdly broken in extension, see: https://github.com/chakra-ui/chakra-ui/issues/4619
const toastifyConfig = (position) => {
    return {
        limit: 1,
        closeOnClick: true,
        pauseOnHover: false,
        autoClose: 2700,
        hideProgressBar: true,
        transition: react_toastify_1.Flip,
        position
    };
};
exports.toastifyConfig = toastifyConfig;
//# sourceMappingURL=toastifyConfig.js.map