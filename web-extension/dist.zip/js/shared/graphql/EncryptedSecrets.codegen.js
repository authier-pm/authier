"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useUpdateEncryptedSecretMutation = exports.UpdateEncryptedSecretDocument = exports.useDeleteEncryptedSecretMutation = exports.DeleteEncryptedSecretDocument = exports.useEncryptedSecretsLazyQuery = exports.useEncryptedSecretsQuery = exports.EncryptedSecretsDocument = void 0;
const client_1 = require("@apollo/client");
const Apollo = __importStar(require("@apollo/client"));
const defaultOptions = {};
exports.EncryptedSecretsDocument = (0, client_1.gql) `
    query encryptedSecrets {
  me {
    id
    encryptedSecrets {
      id
      kind
      encrypted
    }
  }
}
    `;
/**
 * __useEncryptedSecretsQuery__
 *
 * To run a query within a React component, call `useEncryptedSecretsQuery` and pass it any options that fit your needs.
 * When your component renders, `useEncryptedSecretsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useEncryptedSecretsQuery({
 *   variables: {
 *   },
 * });
 */
function useEncryptedSecretsQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.EncryptedSecretsDocument, options);
}
exports.useEncryptedSecretsQuery = useEncryptedSecretsQuery;
function useEncryptedSecretsLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.EncryptedSecretsDocument, options);
}
exports.useEncryptedSecretsLazyQuery = useEncryptedSecretsLazyQuery;
exports.DeleteEncryptedSecretDocument = (0, client_1.gql) `
    mutation deleteEncryptedSecret($id: ID!) {
  me {
    encryptedSecret(id: $id) {
      id
      delete {
        id
      }
    }
  }
}
    `;
/**
 * __useDeleteEncryptedSecretMutation__
 *
 * To run a mutation, you first call `useDeleteEncryptedSecretMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeleteEncryptedSecretMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deleteEncryptedSecretMutation, { data, loading, error }] = useDeleteEncryptedSecretMutation({
 *   variables: {
 *      id: // value for 'id'
 *   },
 * });
 */
function useDeleteEncryptedSecretMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.DeleteEncryptedSecretDocument, options);
}
exports.useDeleteEncryptedSecretMutation = useDeleteEncryptedSecretMutation;
exports.UpdateEncryptedSecretDocument = (0, client_1.gql) `
    mutation updateEncryptedSecret($id: ID!, $patch: EncryptedSecretInput!) {
  me {
    encryptedSecret(id: $id) {
      id
      update(patch: $patch) {
        id
      }
    }
  }
}
    `;
/**
 * __useUpdateEncryptedSecretMutation__
 *
 * To run a mutation, you first call `useUpdateEncryptedSecretMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateEncryptedSecretMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateEncryptedSecretMutation, { data, loading, error }] = useUpdateEncryptedSecretMutation({
 *   variables: {
 *      id: // value for 'id'
 *      patch: // value for 'patch'
 *   },
 * });
 */
function useUpdateEncryptedSecretMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.UpdateEncryptedSecretDocument, options);
}
exports.useUpdateEncryptedSecretMutation = useUpdateEncryptedSecretMutation;
//# sourceMappingURL=EncryptedSecrets.codegen.js.map