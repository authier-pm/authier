"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebInputType = exports.TokenType = exports.EncryptedSecretType = exports.EmailVerificationType = void 0;
var EmailVerificationType;
(function (EmailVerificationType) {
    EmailVerificationType["CONTACT"] = "CONTACT";
    EmailVerificationType["PRIMARY"] = "PRIMARY";
})(EmailVerificationType = exports.EmailVerificationType || (exports.EmailVerificationType = {}));
var EncryptedSecretType;
(function (EncryptedSecretType) {
    EncryptedSecretType["LOGIN_CREDENTIALS"] = "LOGIN_CREDENTIALS";
    EncryptedSecretType["TOTP"] = "TOTP";
})(EncryptedSecretType = exports.EncryptedSecretType || (exports.EncryptedSecretType = {}));
var TokenType;
(function (TokenType) {
    TokenType["API"] = "API";
    TokenType["EMAIL"] = "EMAIL";
})(TokenType = exports.TokenType || (exports.TokenType = {}));
var WebInputType;
(function (WebInputType) {
    WebInputType["CUSTOM"] = "CUSTOM";
    WebInputType["EMAIL"] = "EMAIL";
    WebInputType["NEW_PASSWORD"] = "NEW_PASSWORD";
    WebInputType["NEW_PASSWORD_CONFIRMATION"] = "NEW_PASSWORD_CONFIRMATION";
    WebInputType["PASSWORD"] = "PASSWORD";
    WebInputType["SUBMIT_BUTTON"] = "SUBMIT_BUTTON";
    WebInputType["TOTP"] = "TOTP";
    WebInputType["USERNAME"] = "USERNAME";
    WebInputType["USERNAME_OR_EMAIL"] = "USERNAME_OR_EMAIL";
})(WebInputType = exports.WebInputType || (exports.WebInputType = {}));
//# sourceMappingURL=graphqlBaseTypes.js.map