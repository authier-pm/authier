"use strict";
// @ts-nocheck THIS IS A GENERATED FILE, DO NOT EDIT
Object.defineProperty(exports, "__esModule", { value: true });
const result = {
    "possibleTypes": {
        "DecryptionChallenge": [
            "DecryptionChallengeApproved",
            "DecryptionChallengeForApproval"
        ]
    }
};
exports.default = result;
//# sourceMappingURL=graphqlSchemaFragments.js.map