"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EncryptedSecretsType = void 0;
var EncryptedSecretsType;
(function (EncryptedSecretsType) {
    EncryptedSecretsType["TOTP"] = "TOTP";
    EncryptedSecretsType["LOGIN_CREDENTIALS"] = "LOGIN_CREDENTIALS";
})(EncryptedSecretsType = exports.EncryptedSecretsType || (exports.EncryptedSecretsType = {}));
//# sourceMappingURL=graphqlBaseTypes.js.map