"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthLinkPage = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const layout_1 = require("@chakra-ui/layout");
const react_1 = require("@chakra-ui/react");
const react_2 = require("@chakra-ui/react");
const macro_1 = require("@lingui/macro");
const io_1 = require("react-icons/io");
function AuthLinkPage() {
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsx)(layout_1.Box, Object.assign({ width: "315px", p: 30 }, { children: (0, jsx_runtime_1.jsxs)(react_1.Center, { children: [(0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ size: "sm" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Open vault to login or sign up" }) })), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: (0, macro_1.t) `Open vault`, "aria-label": (0, macro_1.t) `Open vault` }, { children: (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", ml: "2", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(io_1.IoMdArchive, {}), onClick: () => __awaiter(this, void 0, void 0, function* () {
                                chrome.tabs.create({ url: 'vault.html' });
                            }) }) }))] }) })) }));
}
exports.AuthLinkPage = AuthLinkPage;
//# sourceMappingURL=AuthLinkPage.js.map