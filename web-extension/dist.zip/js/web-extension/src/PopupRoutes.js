"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const AuthLinkPage_1 = require("./AuthLinkPage");
const VaultUnlockVerification_1 = require("./pages/VaultUnlockVerification");
const Popup_1 = require("./popup/Popup");
const DeviceStateProvider_1 = require("./providers/DeviceStateProvider");
const debug_1 = __importDefault(require("debug"));
const log = (0, debug_1.default)('au:popupRoutes');
function PopupRoutes() {
    const { device, deviceState } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    log('deviceState', deviceState);
    log({ device });
    if (device.lockedState) {
        return (0, jsx_runtime_1.jsx)(VaultUnlockVerification_1.VaultUnlockVerification, {});
    }
    if (deviceState === null) {
        return (0, jsx_runtime_1.jsx)(AuthLinkPage_1.AuthLinkPage, {});
    }
    return (0, jsx_runtime_1.jsx)(Popup_1.Popup, {});
}
exports.default = PopupRoutes;
//# sourceMappingURL=PopupRoutes.js.map