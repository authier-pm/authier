"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VaultSettings = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_router_dom_1 = require("react-router-dom");
const react_2 = require("react");
const Account_1 = __importDefault(require("@src/components/vault/settings/Account"));
const VaultConfig_1 = __importDefault(require("@src/components/vault/settings/VaultConfig"));
const framer_motion_1 = require("framer-motion");
const LinkItems = [
    { name: 'Account', path: '/account' },
    { name: 'Security', path: '/security' }
];
const NavLink = ({ name, path, handleClick, url, selected }) => {
    return ((0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ as: react_router_dom_1.Link, to: url + path, style: { textDecoration: 'none' } }, { children: (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ verticalAlign: "center", px: 2, py: 1, borderRadius: "lg", role: "group", cursor: "pointer", fontSize: 20, bgColor: selected.name === name
                ? (0, react_1.useColorModeValue)('gray.100', 'gray.700')
                : 'transparent', onClick: () => handleClick() }, { children: name })) })));
};
const VaultSettings = () => {
    const location = (0, react_router_dom_1.useLocation)();
    const [selectedTab, setSelectedTab] = (0, react_2.useState)(LinkItems[0]);
    (0, react_2.useEffect)(() => {
        if (location.pathname === '/settings/account') {
            setSelectedTab(LinkItems[0]);
        }
        else if (location.pathname === '/settings/security') {
            setSelectedTab(LinkItems[1]);
        }
    }, [location]);
    return ((0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ align: 'center', justify: 'center', flexDirection: 'column' }, { children: [(0, jsx_runtime_1.jsx)(react_1.HStack, Object.assign({ as: 'nav', spacing: 4, mb: 10 }, { children: LinkItems.map((link) => {
                    const handleClick = () => {
                        setSelectedTab(link);
                    };
                    return ((0, jsx_runtime_1.jsx)(NavLink, { path: link.path, selected: selectedTab, handleClick: handleClick, name: link.name, url: '/settings' }, link.name));
                }) })), (0, jsx_runtime_1.jsx)(framer_motion_1.AnimatePresence, Object.assign({ exitBeforeEnter: true }, { children: (0, jsx_runtime_1.jsxs)(react_router_dom_1.Routes, { children: [(0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: '/account', element: (0, jsx_runtime_1.jsx)(Account_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: '/security', element: (0, jsx_runtime_1.jsx)(VaultConfig_1.default, {}) })] }, location.pathname) }))] })));
};
exports.VaultSettings = VaultSettings;
//# sourceMappingURL=VaultSettings.js.map