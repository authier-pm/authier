"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_2 = require("@chakra-ui/react");
const fa_1 = require("react-icons/fa");
const Premium_codegen_1 = require("./Premium.codegen");
function PriceWrapper({ children }) {
    return ((0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ mb: 4, shadow: "base", borderWidth: "1px", alignSelf: { base: 'center', lg: 'flex-start' }, borderColor: (0, react_2.useColorModeValue)('gray.200', 'gray.500'), borderRadius: 'xl' }, { children: children })));
}
function Premium() {
    const [loading, setLoading] = (0, react_1.useState)(false);
    const [createCheckoutSessionMutation, { data, loading: sessionLoading, error }] = (0, Premium_codegen_1.useCreateCheckoutSessionVaultMutation)();
    const handleCheckout = () => __awaiter(this, void 0, void 0, function* () {
        setLoading(true);
        // Create a Checkout Session.
        const response = yield createCheckoutSessionMutation({
            variables: {
                product: '2'
            }
        });
        console.log(response);
        // // Redirect to Checkout.
        // const stripe = await getStripe()
        // const { error } = await stripe!.redirectToCheckout({
        //   // Make the id field from the Checkout Session creation API response
        //   // available to this file, so you can provide it as parameter here
        //   // instead of the {{CHECKOUT_SESSION_ID}} placeholder.
        //   sessionId: response.id
        // })
        // // If `redirectToCheckout` fails due to a browser or network
        // // error, display the localized error message to your customer
        // // using `error.message`.
        // console.warn(error.message)
        setLoading(false);
    });
    return ((0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 12 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ spacing: 2, textAlign: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ as: "h1", fontSize: "4xl" }, { children: "Pay per quantity" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "lg", color: 'gray.500' }, { children: "Start small and pay only when you need to scale up." }))] })), (0, jsx_runtime_1.jsxs)(react_2.Stack, Object.assign({ direction: { base: 'column', md: 'column', lg: 'row' }, textAlign: "center", justify: "center", spacing: { base: 4, lg: 10 }, py: 10 }, { children: [(0, jsx_runtime_1.jsxs)(PriceWrapper, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 4, px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "Free tier" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "0" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsxs)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheck, color: "green.500" }), "3 TOTP secrets"] }), (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheck, color: "green.500" }), "40 login secrets"] })] })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ w: "80%", pt: 7 }, { children: "Always free" }))] }))] }), (0, jsx_runtime_1.jsxs)(PriceWrapper, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 4, px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "Credentials" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "1" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsx)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheck, color: "green.500" }), "additional 60 login secrets"] }) })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ w: "80%", pt: 7 }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ w: "full", colorScheme: "red", variant: "outline" }, { children: "Buy" })) }))] }))] }), (0, jsx_runtime_1.jsxs)(PriceWrapper, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 4, px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "TOTP" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "1" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsx)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheck, color: "green.500" }), "additional 20 TOTP secrets"] }) })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ w: "80%", pt: 7 }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ w: "full", colorScheme: "red", variant: "outline" }, { children: "Buy" })) }))] }))] }), (0, jsx_runtime_1.jsx)(PriceWrapper, { children: (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ position: "relative" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ position: "absolute", top: "-16px", left: "50%", style: { transform: 'translate(-50%)' } }, { children: (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ textTransform: "uppercase", bg: (0, react_2.useColorModeValue)('red.300', 'red.700'), px: 3, py: 1, color: (0, react_2.useColorModeValue)('gray.900', 'gray.300'), fontSize: "sm", fontWeight: "600", rounded: "xl" }, { children: "Most Popular" })) })), (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ py: 4, px: 12 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontWeight: "500", fontSize: "2xl" }, { children: "TOTP and Credentials" })), (0, jsx_runtime_1.jsxs)(react_2.HStack, Object.assign({ justifyContent: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", fontWeight: "600" }, { children: "$" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "5xl", fontWeight: "900" }, { children: "2" })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "3xl", color: "gray.500" }, { children: "/month" }))] }))] })), (0, jsx_runtime_1.jsxs)(react_2.VStack, Object.assign({ bg: (0, react_2.useColorModeValue)('gray.50', 'gray.700'), py: 4, borderBottomRadius: 'xl' }, { children: [(0, jsx_runtime_1.jsxs)(react_2.List, Object.assign({ spacing: 3, textAlign: "start", px: 12 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheck, color: "green.500" }), "additional 60 login secrets"] }), (0, jsx_runtime_1.jsxs)(react_2.ListItem, { children: [(0, jsx_runtime_1.jsx)(react_2.ListIcon, { as: fa_1.FaCheck, color: "green.500" }), "additional 20 TOTP secrets"] })] })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ w: "80%", pt: 7 }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ w: "full", colorScheme: "red", onClick: handleCheckout }, { children: "Checkout" })) }))] }))] })) })] }))] })));
}
exports.default = Premium;
//# sourceMappingURL=Premium.js.map