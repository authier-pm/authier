"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VaultRouter = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const SidebarWithHeader_1 = __importDefault(require("../components/vault/SidebarWithHeader"));
const react_router_dom_1 = require("react-router-dom");
const ItemSettings_1 = require("@src/components/vault/ItemSettings");
const VaultSettings_1 = require("./VaultSettings");
const Login_1 = __importDefault(require("@src/pages-vault/Login"));
const react_2 = require("@chakra-ui/react");
const Devices_1 = __importDefault(require("./Devices"));
const VaultImportExport_1 = require("./VaultImportExport");
const Register_1 = __importDefault(require("./Register"));
const AddItem_1 = require("./AddItem");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const VaultUnlockVerification_1 = require("@src/pages/VaultUnlockVerification");
const VaultList_1 = require("./VaultList");
const AccountLimits_1 = require("./AccountLimits");
function VaultRouter() {
    const { device, deviceState } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const navigate = (0, react_router_dom_1.useNavigate)();
    (0, react_1.useEffect)(() => {
        if (device.lockedState) {
            navigate('verify');
        }
        else {
            navigate('/');
        }
        console.log('VaultRouter: useEffect');
    }, [device.lockedState]);
    if (deviceState === null) {
        return ((0, jsx_runtime_1.jsx)(react_2.Center, Object.assign({ marginX: "50%", h: "100vh" }, { children: (0, jsx_runtime_1.jsxs)(react_router_dom_1.Routes, { children: [(0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/", element: (0, jsx_runtime_1.jsx)(Login_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/signup", element: (0, jsx_runtime_1.jsx)(Register_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/verify", element: (0, jsx_runtime_1.jsx)(VaultUnlockVerification_1.VaultUnlockVerification, {}) })] }) })));
    }
    return ((0, jsx_runtime_1.jsx)(SidebarWithHeader_1.default, { children: (0, jsx_runtime_1.jsxs)(react_router_dom_1.Routes, { children: [(0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/", element: (0, jsx_runtime_1.jsx)(VaultList_1.VaultList, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/secret/:secretId", element: (0, jsx_runtime_1.jsx)(ItemSettings_1.VaultItemSettings, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/account-limits", element: (0, jsx_runtime_1.jsx)(AccountLimits_1.AccountLimits, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/settings/*", element: (0, jsx_runtime_1.jsx)(VaultSettings_1.VaultSettings, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/devices", element: (0, jsx_runtime_1.jsx)(Devices_1.default, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/import-export", element: (0, jsx_runtime_1.jsx)(VaultImportExport_1.VaultImportExport, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/addItem", element: (0, jsx_runtime_1.jsx)(AddItem_1.AddItem, {}) }), (0, jsx_runtime_1.jsx)(react_router_dom_1.Route, { path: "/devices", element: (0, jsx_runtime_1.jsx)(Devices_1.default, {}) })] }) }));
}
exports.VaultRouter = VaultRouter;
//# sourceMappingURL=VaultRouter.js.map