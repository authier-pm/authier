"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_2 = require("@chakra-ui/react");
const icons_1 = require("@chakra-ui/icons");
const formik_1 = require("formik");
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const accessTokenExtension_1 = require("@src/util/accessTokenExtension");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const macro_1 = require("@lingui/macro");
const generateEncryptionKey_1 = require("@util/generateEncryptionKey");
const registerNewUser_codegen_1 = require("@shared/graphql/registerNewUser.codegen");
const react_router_dom_1 = require("react-router-dom");
function Register() {
    const [showPassword, setShowPassword] = (0, react_1.useState)(false);
    const [register] = (0, registerNewUser_codegen_1.useRegisterNewUserMutation)();
    const navigate = (0, react_router_dom_1.useNavigate)();
    const { fireToken } = ExtensionDevice_1.device;
    if (!fireToken) {
        return (0, jsx_runtime_1.jsx)(react_2.Spinner, {});
    }
    return ((0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ p: 8, borderWidth: 1, borderRadius: 6, boxShadow: "lg", minW: "400px" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ alignItems: "center", justifyContent: "center" }, { children: (0, jsx_runtime_1.jsx)(react_2.Heading, { children: "Create account" }) })), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: { email: '', password: '' }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                    var _a, _b;
                    const userId = crypto.randomUUID();
                    const deviceId = yield ExtensionDevice_1.device.getDeviceId();
                    const encryptionSalt = window.crypto.getRandomValues(new Uint8Array(16));
                    const masterEncryptionKey = yield (0, generateEncryptionKey_1.generateEncryptionKey)(values.password, encryptionSalt);
                    const params = yield ExtensionDevice_1.device.initLocalDeviceAuthSecret(masterEncryptionKey, encryptionSalt);
                    const res = yield register({
                        variables: {
                            userId,
                            input: Object.assign(Object.assign({ encryptionSalt: (0, generateEncryptionKey_1.buff_to_base64)(encryptionSalt), email: values.email }, params), { deviceId, devicePlatform: ExtensionDevice_1.device.platform, deviceName: ExtensionDevice_1.device.generateDeviceName(), firebaseToken: fireToken })
                        }
                    });
                    const registerResult = (_a = res.data) === null || _a === void 0 ? void 0 : _a.registerNewUser;
                    if (registerResult === null || registerResult === void 0 ? void 0 : registerResult.accessToken) {
                        //FIX: is this right, maybe someone could use proxy and send random string
                        yield webextension_polyfill_1.default.storage.local.set({
                            'access-token': (_b = res.data) === null || _b === void 0 ? void 0 : _b.registerNewUser.accessToken
                        });
                        (0, accessTokenExtension_1.setAccessToken)(registerResult.accessToken);
                        const stringKey = yield (0, generateEncryptionKey_1.cryptoKeyToString)(masterEncryptionKey);
                        const deviceState = {
                            masterEncryptionKey: stringKey,
                            userId: userId,
                            secrets: [],
                            email: values.email,
                            deviceName: ExtensionDevice_1.device.name,
                            encryptionSalt: (0, generateEncryptionKey_1.buff_to_base64)(encryptionSalt),
                            authSecret: params.addDeviceSecret,
                            authSecretEncrypted: params.addDeviceSecretEncrypted,
                            lockTime: 28800,
                            autofill: true,
                            language: 'en',
                            syncTOTP: false,
                            theme: 'dark'
                        };
                        ExtensionDevice_1.device.save(deviceState);
                        navigate('/');
                        setSubmitting(false);
                    }
                }) }, { children: (props) => ((0, jsx_runtime_1.jsxs)(formik_1.Form, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "email" }, { children: ({ field, form }) => ((0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: form.errors.email && form.touched.email, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "email" }, { children: "Email" })), (0, jsx_runtime_1.jsx)(react_2.Input, Object.assign({}, field, { id: "Email", placeholder: "bob@bob.com" })), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: form.errors.email })] }))) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "password" }, { children: ({ field, form }) => ((0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: form.errors.password && form.touched.password, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password" })), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, { children: [(0, jsx_runtime_1.jsx)(react_2.Input, Object.assign({}, field, { type: showPassword ? 'text' : 'password', placeholder: "*******" })), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "3rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.5rem", size: "sm", onClick: () => setShowPassword(!showPassword) }, { children: showPassword ? (0, jsx_runtime_1.jsx)(icons_1.ViewOffIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ViewIcon, {}) })) }))] }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: form.errors.password })] }))) })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ colorScheme: "teal", variant: "outline", type: "submit", width: "full", mt: 4, isLoading: props.isSubmitting }, { children: "Register" })), (0, jsx_runtime_1.jsxs)(react_2.chakra.p, Object.assign({ p: 2, fontSize: "xs", textAlign: "center", color: "gray.600" }, { children: ["By signing up you agree to our", ' ', (0, jsx_runtime_1.jsx)(react_2.chakra.a, Object.assign({ color: "brand.500" }, { children: "Terms of Service" }))] }))] })) })), (0, jsx_runtime_1.jsx)(react_router_dom_1.Link, Object.assign({ to: "/" }, { children: (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ pt: 3 }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Already have an account?" }) })) }))] })));
}
exports.default = Register;
//# sourceMappingURL=Register.js.map