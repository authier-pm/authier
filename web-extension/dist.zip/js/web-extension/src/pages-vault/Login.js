"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginContext = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = __importStar(require("react"));
const react_2 = require("@chakra-ui/react");
const formik_1 = require("formik");
const icons_1 = require("@chakra-ui/icons");
const debug_1 = __importDefault(require("debug"));
const macro_1 = require("@lingui/macro");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const LoginAwaitingApproval_1 = require("./LoginAwaitingApproval");
const react_router_dom_1 = require("react-router-dom");
const log = (0, debug_1.default)('au:Login');
// @ts-expect-error TODO: fix types
exports.LoginContext = react_1.default.createContext();
// export const isRunningInVault = location.href.includes('/vault.html#')
function Login() {
    const [showPassword, setShowPassword] = (0, react_1.useState)(false);
    const [formState, setFormState] = (0, react_1.useState)(null);
    if (!ExtensionDevice_1.device.id) {
        return (0, jsx_runtime_1.jsx)(react_2.Spinner, {});
    }
    if (formState) {
        return ((0, jsx_runtime_1.jsx)(exports.LoginContext.Provider, Object.assign({ value: { formState, setFormState } }, { children: (0, jsx_runtime_1.jsx)(LoginAwaitingApproval_1.LoginAwaitingApproval, {}) })));
    }
    return ((0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ p: 8, borderWidth: 1, borderRadius: 6, boxShadow: "lg", minW: "400px" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ alignItems: "center", justifyContent: "center" }, { children: (0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "lg" }, { children: "Login" })) })), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: { email: 'bob@bob.com', password: 'bob' }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                    setFormState(values);
                    setSubmitting(false);
                }) }, { children: (props) => ((0, jsx_runtime_1.jsxs)(formik_1.Form, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "email" }, { children: ({ field, form }) => ((0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: form.errors.email && form.touched.email, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "email" }, { children: "Email" })), (0, jsx_runtime_1.jsx)(react_2.Input, Object.assign({}, field, { id: "Email", placeholder: "bob@bob.com" })), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: form.errors.email })] }))) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "password" }, { children: ({ field, form }) => ((0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: form.errors.password && form.touched.password, isRequired: true }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password" })), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, { children: [(0, jsx_runtime_1.jsx)(react_2.Input, Object.assign({}, field, { type: showPassword ? 'text' : 'password', placeholder: "*******" })), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "3rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.5rem", size: "sm", onClick: () => setShowPassword(!showPassword) }, { children: showPassword ? (0, jsx_runtime_1.jsx)(icons_1.ViewOffIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ViewIcon, {}) })) }))] }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: form.errors.password })] }))) })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ colorScheme: "teal", variant: "outline", type: "submit", width: "full", mt: 4, isLoading: props.isSubmitting }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Login" }) }))] })) })), (0, jsx_runtime_1.jsx)(react_2.Flex, { children: (0, jsx_runtime_1.jsx)(react_router_dom_1.Link, Object.assign({ to: "/signup" }, { children: (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ pt: 3 }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Don't have account?" }) })) })) })] })));
}
exports.default = Login;
//# sourceMappingURL=Login.js.map