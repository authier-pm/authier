"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const icons_1 = require("@chakra-ui/icons");
const react_1 = require("@chakra-ui/react");
const macro_1 = require("@lingui/macro");
const NbSp_1 = require("@src/components/util/NbSp");
const formik_1 = require("formik");
const react_2 = require("react");
const fi_1 = require("react-icons/fi");
const AccountDevices_codegen_1 = require("@shared/graphql/AccountDevices.codegen");
const date_fns_1 = require("date-fns");
const DeviceDeleteAlert_1 = require("@src/components/vault/DeviceDeleteAlert");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const RefreshDeviceButton_1 = require("@src/components/vault/RefreshDeviceButton");
const react_router_dom_1 = require("react-router-dom");
const NewDeviceApproval_1 = require("./NewDeviceApproval");
const DeviceListItem = ({ deviceInfo, masterDeviceId }) => {
    var _a, _b;
    const [changeMasterDeviceMutation] = (0, AccountDevices_codegen_1.useChangeMasterDeviceMutation)();
    const [isConfigOpen, setIsConfigOpen] = (0, react_2.useState)(false);
    const { isOpen, onOpen, onClose } = (0, react_1.useDisclosure)();
    const navigate = (0, react_router_dom_1.useNavigate)();
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ py: 6, m: 5 }, { children: (0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ w: "350px", bg: (0, react_1.useColorModeValue)('white', 'gray.800'), boxShadow: '2xl', rounded: 'lg', p: 6 }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ justifyContent: "space-between", direction: 'row', spacing: 3, alignItems: 'baseline', lineHeight: '6' }, { children: [(0, jsx_runtime_1.jsxs)(react_1.HStack, Object.assign({ mb: 2, spacing: 3 }, { children: [deviceInfo.id === ExtensionDevice_1.device.id && ((0, jsx_runtime_1.jsx)(react_1.Badge, Object.assign({ height: "min-content", colorScheme: "yellow" }, { children: "Current" }))), deviceInfo.id === masterDeviceId && ((0, jsx_runtime_1.jsx)(react_1.Badge, Object.assign({ height: "min-content", colorScheme: "purple" }, { children: "Master" }))), deviceInfo.logoutAt ? ((0, jsx_runtime_1.jsx)(react_1.Badge, Object.assign({ height: "min-content", colorScheme: "red" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Logged out" }) }))) : ((0, jsx_runtime_1.jsx)(react_1.Badge, Object.assign({ height: "min-content", colorScheme: "green" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Logged in" }) })))] })), (0, jsx_runtime_1.jsxs)(react_1.Menu, { children: [(0, jsx_runtime_1.jsx)(react_1.MenuButton, { as: react_1.IconButton, size: "xs", variant: "unstyled", "aria-label": "Favourite", fontSize: "15px", icon: (0, jsx_runtime_1.jsx)(icons_1.SettingsIcon, { color: 'white' }) }), (0, jsx_runtime_1.jsxs)(react_1.MenuList, { children: [masterDeviceId !== deviceInfo.id ? ((0, jsx_runtime_1.jsxs)(react_1.MenuItem, Object.assign({ onClick: () => changeMasterDeviceMutation({
                                                    variables: {
                                                        newMasterDeviceId: deviceInfo.id
                                                    }
                                                }) }, { children: [(0, jsx_runtime_1.jsx)(fi_1.FiStar, {}), (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Set on master device" })] }))) : null, (0, jsx_runtime_1.jsxs)(react_1.MenuItem, Object.assign({ onClick: () => onOpen() }, { children: [(0, jsx_runtime_1.jsx)(fi_1.FiLogOut, {}), (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Logout" })] })), (0, jsx_runtime_1.jsx)(DeviceDeleteAlert_1.DeviceDeleteAlert, { id: deviceInfo.id, isOpen: isOpen, onClose: onClose }), (0, jsx_runtime_1.jsxs)(react_1.MenuItem, Object.assign({ onClick: () => {
                                                    if (deviceInfo.id === ExtensionDevice_1.device.id) {
                                                        navigate('/settings/security');
                                                    }
                                                    else {
                                                        setIsConfigOpen(!isConfigOpen);
                                                    }
                                                } }, { children: [(0, jsx_runtime_1.jsx)(fi_1.FiSettings, {}), (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Config" })] }))] })] })] })), (0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ fontSize: 'xl', fontFamily: 'body' }, { children: deviceInfo.name })), isConfigOpen ? ((0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ mt: 5 }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                                lockTime: deviceInfo.vaultLockTimeoutSeconds,
                                twoFA: deviceInfo.syncTOTP
                            }, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                                console.log(values);
                                setSubmitting(false);
                            }) }, { children: ({ isSubmitting, dirty, handleSubmit, errors, touched, values }) => ((0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ spacing: 4, align: "flex-start" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.lockTime && touched.lockTime }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "lockTime" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Lock time" }) })), (0, jsx_runtime_1.jsxs)(formik_1.Field, Object.assign({ as: react_1.Select, id: "lockTime", name: "lockTime" }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ value: 60 }, { children: "1 minute" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 120 }, { children: "2 minutes" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 3600 }, { children: "1 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 14400 }, { children: "4 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 28800 }, { children: "8 hours" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 86400 }, { children: "1 day" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 604800 }, { children: "1 week" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 2592000 }, { children: "1 month" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 0 }, { children: "Never" }))] })), (0, jsx_runtime_1.jsx)(react_1.FormHelperText, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Automatically locks vault after chosen period of time" }) })] })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "twoFA" }, { children: ({ field, form }) => {
                                                const { onChange } = field, rest = __rest(field, ["onChange"]);
                                                return ((0, jsx_runtime_1.jsx)(react_1.FormControl, Object.assign({ id: "twoFA", isInvalid: !!form.errors['twoFA'] &&
                                                        !!form.touched['twoFA'] }, { children: (0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({}, rest, { id: "twoFA", onChange: onChange, defaultChecked: values.twoFA }, { children: "2FA" })) })));
                                            } })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ mt: 4, colorScheme: "teal", disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Save" }) }))] })) }))) })) }))) : ((0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ mt: 6, spacing: 4 }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Box, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontWeight: 600, color: 'gray.500', fontSize: 'md' }, { children: "Last IP Address" })), (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: 'xl' }, { children: deviceInfo.lastIpAddress }))] }), (0, jsx_runtime_1.jsxs)(react_1.Box, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontWeight: 600, color: 'gray.500', fontSize: 'md' }, { children: "Geolocation" })), (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: 'xl' }, { children: deviceInfo.lastGeoLocation }))] }), (0, jsx_runtime_1.jsxs)(react_1.Box, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontWeight: 600, color: 'gray.500', fontSize: 'md' }, { children: "Added" })), (0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ label: (0, date_fns_1.intlFormat)(new Date((_a = deviceInfo.createdAt) !== null && _a !== void 0 ? _a : ''), {
                                            weekday: 'long',
                                            year: 'numeric',
                                            month: 'long',
                                            day: 'numeric'
                                        }) }, { children: (0, jsx_runtime_1.jsxs)(react_1.Text, Object.assign({ fontSize: 'xl' }, { children: [(0, date_fns_1.formatDistance)(new Date((_b = deviceInfo.createdAt) !== null && _b !== void 0 ? _b : ''), new Date()), "ago"] })) }))] })] })))] })) })) }));
};
function Devices() {
    var _a, _b, _c;
    const { data, loading, refetch: devicesRefetch } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    const [filterBy, setFilterBy] = (0, react_2.useState)('');
    return ((0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Center, { children: [(0, jsx_runtime_1.jsx)(react_1.Input, { w: ['300px', '350px', '400px', '500px'], placeholder: (0, macro_1.t) `Search for device`, m: "auto", onChange: (ev) => {
                            setFilterBy(ev.target.value);
                        } }), (0, jsx_runtime_1.jsxs)(react_1.Center, Object.assign({ px: 3 }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Stat, Object.assign({ ml: "auto", whiteSpace: 'nowrap' }, { children: [(_a = data === null || data === void 0 ? void 0 : data.me) === null || _a === void 0 ? void 0 : _a.devices.length, " ", (0, macro_1.t) `devices`] })), (0, jsx_runtime_1.jsx)(RefreshDeviceButton_1.RefreshDeviceButton, {})] }))] }), (0, jsx_runtime_1.jsx)(NewDeviceApproval_1.NewDevicesApprovalStack, {}), (0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ justifyContent: ['flex-end', 'center', 'center'] }, { children: (0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ flexDirection: "column" }, { children: (0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ flexDirection: "row", flexWrap: "wrap", m: "auto" }, { children: loading ? ((0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ pt: 5 }, { children: (0, jsx_runtime_1.jsx)(react_1.Spinner, { size: "lg" }) }))) : ((_c = (_b = data === null || data === void 0 ? void 0 : data.me) === null || _b === void 0 ? void 0 : _b.devices) === null || _c === void 0 ? void 0 : _c.filter(({ name }) => {
                            return name.includes(filterBy);
                        }).map((el, i) => {
                            return ((0, jsx_runtime_1.jsx)(DeviceListItem, { deviceInfo: el, masterDeviceId: data.me.masterDeviceId }, i));
                        })) })) })) }))] })));
}
exports.default = Devices;
//# sourceMappingURL=Devices.js.map