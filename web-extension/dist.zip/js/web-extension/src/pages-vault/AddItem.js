"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddItem = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = require("react");
const framer_motion_1 = require("framer-motion");
const AddLogin_1 = require("@src/components/vault/addItem/AddLogin");
const AddTOTP_1 = require("@src/components/vault/addItem/AddTOTP");
const AccountLimits_codegen_1 = require("./AccountLimits.codegen");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const AddItem = () => {
    const [type, setType] = (0, react_2.useState)(null);
    const { loginCredentials: LoginCredentials, TOTPSecrets } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { data, loading } = (0, AccountLimits_codegen_1.useMeExtensionQuery)({
        fetchPolicy: 'network-only'
    });
    const bg = (0, react_1.useColorModeValue)('white', 'gray.800');
    if (loading) {
        return (0, jsx_runtime_1.jsx)(react_1.Spinner, {});
    }
    const totpCond = data.me.TOTPlimit <= TOTPSecrets.length;
    const pswCond = data.me.PasswordLimits <= LoginCredentials.length;
    return ((0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: { opacity: 1 }, initial: { opacity: 0 }, exit: { opacity: 0 }, transition: { duration: 0.25 }, style: {
            width: '80%',
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ width: { base: '90%', sm: '70%', lg: '60%', xl: '50%', '2xl': '40%' }, flexDirection: "column", boxShadow: '2xl', rounded: 'md', overflow: 'hidden', m: "auto", alignItems: 'center', bg: bg }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Select, Object.assign({ onChange: (e) => setType(e.target.value), defaultValue: undefined, placeholder: "Select type", w: '50%', mt: 5 }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ disabled: totpCond, value: "TOTP" }, { children: "TOTP" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ disabled: pswCond, value: "Login" }, { children: "Login" }))] })), type === 'Login' ? ((0, jsx_runtime_1.jsx)(AddLogin_1.AddLogin, {})) : type === 'TOTP' ? ((0, jsx_runtime_1.jsx)(AddTOTP_1.AddTOTP, {})) : ((0, jsx_runtime_1.jsx)(react_1.Box, { children: (0, jsx_runtime_1.jsx)(react_1.Text, { children: "Select a type" }) }))] })) })));
};
exports.AddItem = AddItem;
//# sourceMappingURL=AddItem.js.map