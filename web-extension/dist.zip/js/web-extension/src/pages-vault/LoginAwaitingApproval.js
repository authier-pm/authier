"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginAwaitingApproval = exports.useLogin = exports.log = exports.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const macro_1 = require("@lingui/macro");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const UserProvider_1 = require("@src/providers/UserProvider");
const react_1 = require("react");
const Login_1 = require("./Login");
const Login_codegen_1 = require("@shared/graphql/Login.codegen");
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const accessTokenExtension_1 = require("../util/accessTokenExtension");
const react_2 = require("@chakra-ui/react");
const date_fns_1 = require("date-fns");
const icons_1 = require("@chakra-ui/icons");
const debug_1 = __importDefault(require("debug"));
const generateEncryptionKey_1 = require("@util/generateEncryptionKey");
const Providers_1 = require("@src/Providers");
exports.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL = 6000;
exports.log = (0, debug_1.default)('au:LoginAwaitingApproval');
const useLogin = (props) => {
    const { formState, setFormState } = (0, react_1.useContext)(Login_1.LoginContext);
    const { setUserId } = (0, react_1.useContext)(UserProvider_1.UserContext);
    const [addNewDevice, { loading, error }] = (0, Login_codegen_1.useAddNewDeviceForUserMutation)();
    const [getDeviceDecryptionChallenge, { data: decryptionData, error: decrChallError }] = (0, Login_codegen_1.useDeviceDecryptionChallengeMutation)({
        variables: {
            deviceInput: {
                id: ExtensionDevice_1.device.id,
                name: props.deviceName,
                platform: ExtensionDevice_1.device.platform
            },
            email: formState.email
        }
    });
    (0, react_1.useEffect)(() => {
        if (error || decrChallError) {
            setFormState(null);
        }
    }, [error, decrChallError]);
    (0, react_2.useInterval)(() => {
        getDeviceDecryptionChallenge();
    }, exports.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL);
    const deviceDecryptionChallenge = decryptionData === null || decryptionData === void 0 ? void 0 : decryptionData.deviceDecryptionChallenge;
    (0, react_1.useEffect)(() => {
        console.log('~ decryptionData', decryptionData);
        const { fireToken } = ExtensionDevice_1.device;
        if ((deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.__typename) === 'DecryptionChallengeApproved' &&
            fireToken) {
            ;
            (() => __awaiter(void 0, void 0, void 0, function* () {
                var _a, _b, _c;
                const addDeviceSecretEncrypted = deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.addDeviceSecretEncrypted;
                const userId = deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.userId;
                if (!addDeviceSecretEncrypted || !userId) {
                    (0, Providers_1.toast)({
                        title: (0, macro_1.t) `Login failed, check your email or password`,
                        status: 'error',
                        isClosable: true
                    });
                    return;
                }
                if (!(deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.id)) {
                    (0, Providers_1.toast)({
                        title: 'Failed to create decryption challenge',
                        status: 'error',
                        isClosable: true
                    });
                    return;
                }
                const encryptionSalt = deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.encryptionSalt;
                const masterEncryptionKey = yield (0, generateEncryptionKey_1.generateEncryptionKey)(formState.password, (0, generateEncryptionKey_1.base64_to_buf)(encryptionSalt));
                let currentAddDeviceSecret;
                try {
                    const encryptedDataBuff = (0, generateEncryptionKey_1.base64_to_buf)(addDeviceSecretEncrypted);
                    const iv = encryptedDataBuff.slice(16, 16 + 12);
                    const data = encryptedDataBuff.slice(16 + 12);
                    const decryptedContent = yield window.crypto.subtle.decrypt({ name: 'AES-GCM', iv }, masterEncryptionKey, data);
                    currentAddDeviceSecret = generateEncryptionKey_1.dec.decode(decryptedContent);
                }
                catch (error) {
                    console.error(error);
                }
                (0, exports.log)('~ currentAddDeviceSecret', currentAddDeviceSecret);
                if (!currentAddDeviceSecret) {
                    (0, Providers_1.toast)({
                        title: (0, macro_1.t) `Login failed, check your email or password`,
                        status: 'error',
                        isClosable: true
                    });
                    setFormState(null);
                    return;
                }
                const newAuthSecret = ExtensionDevice_1.device.generateBackendSecret();
                const iv = window.crypto.getRandomValues(new Uint8Array(12));
                const salt = window.crypto.getRandomValues(new Uint8Array(16));
                const newAuthSecretEncryptedAb = yield window.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, masterEncryptionKey, generateEncryptionKey_1.enc.encode(newAuthSecret));
                const newAuthSecretEncrypted = (0, generateEncryptionKey_1.encryptedBuf_to_base64)(newAuthSecretEncryptedAb, iv, salt);
                const response = yield addNewDevice({
                    variables: {
                        email: formState.email,
                        deviceInput: {
                            id: ExtensionDevice_1.device.id,
                            name: props.deviceName,
                            platform: ExtensionDevice_1.device.platform
                        },
                        input: {
                            addDeviceSecret: newAuthSecret,
                            addDeviceSecretEncrypted: newAuthSecretEncrypted,
                            firebaseToken: fireToken,
                            devicePlatform: ExtensionDevice_1.device.platform,
                            encryptionSalt: (0, generateEncryptionKey_1.buff_to_base64)(salt)
                        },
                        currentAddDeviceSecret: currentAddDeviceSecret
                    }
                });
                yield webextension_polyfill_1.default.storage.local.set({
                    addDeviceSecretEncrypted,
                    currentAddDeviceSecret
                });
                const addNewDeviceForUser = ((_b = (_a = response.data) === null || _a === void 0 ? void 0 : _a.deviceDecryptionChallenge) === null || _b === void 0 ? void 0 : _b.__typename) ===
                    'DecryptionChallengeApproved'
                    ? (_c = response.data) === null || _c === void 0 ? void 0 : _c.deviceDecryptionChallenge.addNewDeviceForUser
                    : null;
                if (addNewDeviceForUser === null || addNewDeviceForUser === void 0 ? void 0 : addNewDeviceForUser.accessToken) {
                    (0, accessTokenExtension_1.setAccessToken)(addNewDeviceForUser === null || addNewDeviceForUser === void 0 ? void 0 : addNewDeviceForUser.accessToken);
                    const decodedToken = yield (0, accessTokenExtension_1.getUserFromToken)();
                    const EncryptedSecrets = addNewDeviceForUser.user.EncryptedSecrets;
                    const deviceState = {
                        masterEncryptionKey: yield (0, generateEncryptionKey_1.cryptoKeyToString)(masterEncryptionKey),
                        userId: userId,
                        secrets: EncryptedSecrets,
                        email: formState.email,
                        encryptionSalt: (0, generateEncryptionKey_1.buff_to_base64)(salt),
                        deviceName: props.deviceName,
                        authSecret: newAuthSecret,
                        authSecretEncrypted: newAuthSecretEncrypted,
                        lockTime: 28800,
                        autofill: true,
                        language: 'en',
                        syncTOTP: false,
                        theme: 'dark'
                    };
                    setUserId(decodedToken.userId);
                    ExtensionDevice_1.device.save(deviceState);
                    (0, Providers_1.toast)({
                        title: (0, macro_1.t) `Device approved at ${(0, date_fns_1.formatRelative)(new Date(), new Date(deviceDecryptionChallenge.approvedAt))}`,
                        status: 'success',
                        isClosable: true
                    });
                }
                else {
                    (0, Providers_1.toast)({
                        title: (0, macro_1.t) `Login failed, check your username or password`,
                        status: 'error',
                        isClosable: true
                    });
                }
            }))();
        }
        else if (!deviceDecryptionChallenge) {
            getDeviceDecryptionChallenge();
        }
    }, [deviceDecryptionChallenge]);
    return { deviceDecryptionChallenge, loading };
};
exports.useLogin = useLogin;
const LoginAwaitingApproval = () => {
    const [deviceName] = (0, react_1.useState)(ExtensionDevice_1.device.generateDeviceName());
    const { deviceDecryptionChallenge } = (0, exports.useLogin)({
        deviceName
    });
    if (!deviceDecryptionChallenge) {
        return (0, jsx_runtime_1.jsx)(react_2.Spinner, {});
    }
    if (!deviceDecryptionChallenge ||
        ((deviceDecryptionChallenge === null || deviceDecryptionChallenge === void 0 ? void 0 : deviceDecryptionChallenge.id) &&
            deviceDecryptionChallenge.__typename === 'DecryptionChallengeForApproval')) {
        return ((0, jsx_runtime_1.jsxs)(react_2.Card, Object.assign({ p: 8, borderWidth: 1, borderRadius: 6, boxShadow: "lg", minW: "600px" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ align: 'center' }, { children: [(0, jsx_runtime_1.jsx)(icons_1.WarningIcon, { mr: 2, boxSize: 30 }), (0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "md", mr: 4 }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Device: " }) })), (0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "sm" }, { children: deviceName }))] })), (0, jsx_runtime_1.jsx)(react_2.Flex, { children: (0, jsx_runtime_1.jsx)(react_2.Center, Object.assign({ mt: 3 }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Approve this device in your device management in the vault on your master device in order to finish adding new device. Afterwards your vault will open automatically in this tab." }) })) })] })));
    }
    else {
        return null;
    }
};
exports.LoginAwaitingApproval = LoginAwaitingApproval;
//# sourceMappingURL=LoginAwaitingApproval.js.map