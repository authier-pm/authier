"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VaultList = exports.VaultListItem = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const button_1 = require("@chakra-ui/button");
const color_mode_1 = require("@chakra-ui/color-mode");
const icons_1 = require("@chakra-ui/icons");
const react_1 = require("@chakra-ui/react");
const react_2 = require("react");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const macro_1 = require("@lingui/macro");
const react_router_dom_1 = require("react-router-dom");
const DeleteAlert_1 = require("../components/vault/DeleteAlert");
const SecretItemIcon_1 = require("@src/components/SecretItemIcon");
const RefreshSecretsButton_1 = require("@src/components/RefreshSecretsButton");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const EncryptedSecrets_codegen_1 = require("@shared/graphql/EncryptedSecrets.codegen");
const Settings_codegen_1 = require("@shared/graphql/Settings.codegen");
const VirtualizedList_1 = require("@src/components/vault/VirtualizedList");
function VaultListItem({ secret }) {
    const [isVisible, setIsVisible] = (0, react_2.useState)(false);
    const { isOpen, onOpen, onClose } = (0, react_1.useDisclosure)();
    const [deleteEncryptedSecretMutation] = (0, EncryptedSecrets_codegen_1.useDeleteEncryptedSecretMutation)();
    const { deviceState } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    if (!deviceState) {
        return null;
    }
    const secretUrl = (0, ExtensionDevice_1.getDecryptedSecretProp)(secret, 'url');
    return ((0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ py: 5, m: ['auto', '3'] }, { children: (0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ w: "250px", h: "195px", bg: (0, color_mode_1.useColorModeValue)('white', 'gray.800'), boxShadow: '2xl', rounded: 'md', overflow: 'hidden', onMouseOver: () => setIsVisible(true), onMouseOut: () => setIsVisible(false) }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ bg: 'gray.100', h: "70%", pos: 'relative' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ h: 130 }, { children: (0, jsx_runtime_1.jsx)(SecretItemIcon_1.SecretItemIcon, { url: secretUrl, iconUrl: (0, ExtensionDevice_1.getDecryptedSecretProp)(secret, 'iconUrl') }) })), (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ display: isVisible ? 'flex' : 'none', alignItems: "center", justifyContent: "center", zIndex: 9, position: "absolute", top: 0, bgColor: "blackAlpha.600", w: "100%", h: "full" }, { children: [secretUrl ? ((0, jsx_runtime_1.jsx)(button_1.IconButton, { "aria-label": "open item", colorScheme: "blackAlpha", icon: (0, jsx_runtime_1.jsx)(icons_1.UnlockIcon, {}), onClick: () => chrome.tabs.create({ url: secretUrl }) })) : null, (0, jsx_runtime_1.jsx)(icons_1.DeleteIcon, { cursor: 'pointer', boxSize: 26, padding: 1.5, overflow: 'visible', backgroundColor: 'red.400', _hover: { backgroundColor: 'red.500' }, position: 'absolute', right: "0", top: "inherit", onClick: onOpen }), (0, jsx_runtime_1.jsx)(DeleteAlert_1.DeleteAlert, { isOpen: isOpen, onClose: onClose, deleteItem: () => __awaiter(this, void 0, void 0, function* () {
                                        var _a;
                                        yield deleteEncryptedSecretMutation({
                                            variables: {
                                                id: secret.id
                                            }
                                        });
                                        yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.removeSecret(secret.id));
                                    }) })] }))] })), (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "row", align: "center", justifyContent: "space-between", p: 4 }, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontWeight: 'bold', fontSize: 'lg', noOfLines: 1 }, { children: (0, ExtensionDevice_1.getDecryptedSecretProp)(secret, 'label') })), (0, jsx_runtime_1.jsx)(react_router_dom_1.Link, Object.assign({ to: {
                                pathname: `secret/${secret.id}`
                            }, state: { data: secret } }, { children: (0, jsx_runtime_1.jsx)(button_1.IconButton, { size: "sm", display: isVisible ? 'block' : 'none', "aria-label": "open item", colorScheme: "gray", icon: (0, jsx_runtime_1.jsx)(icons_1.SettingsIcon, {}) }) }))] }))] })) })));
}
exports.VaultListItem = VaultListItem;
const VaultList = () => {
    const { loginCredentials: LoginCredentials, TOTPSecrets } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const [filterBy, setFilterBy] = (0, react_2.useState)('');
    const navigate = (0, react_router_dom_1.useNavigate)();
    const { setSecuritySettings } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { data, loading, error } = (0, Settings_codegen_1.useSyncSettingsQuery)();
    const { colorMode, toggleColorMode } = (0, react_1.useColorMode)();
    // Here is bug wut theme change, this is not ideal
    (0, react_2.useEffect)(() => {
        var _a, _b;
        if (data) {
            if (colorMode !== data.me.theme) {
                toggleColorMode();
            }
            setSecuritySettings({
                autofill: (_a = data.me) === null || _a === void 0 ? void 0 : _a.autofill,
                language: (_b = data.me) === null || _b === void 0 ? void 0 : _b.language,
                syncTOTP: data.currentDevice.syncTOTP,
                vaultLockTimeoutSeconds: data.currentDevice
                    .vaultLockTimeoutSeconds
            });
        }
    }, [data, loading]);
    if (loading && !data) {
        return (0, jsx_runtime_1.jsx)(react_1.Spinner, {});
    }
    console.log(data === null || data === void 0 ? void 0 : data.me.TOTPlimit, ExtensionDevice_1.device.state);
    //TODO: resolve this bullshit
    // const totpCond =
    //   data?.me?.TOTPlimit ??
    //   0 <=
    //     device?.state?.decryptedSecrets.filter((x) => x.kind === 'TOTP').length ??
    //   0
    // const pswCond =
    //   data.me.PasswordLimits ??
    //   0 <=
    //     device.state.decryptedSecrets.filter(
    //       (x) => x.kind === 'LOGIN_CREDENTIALS'
    //     ).length
    return ((0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ flexDirection: "column", h: '90vh' }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Center, Object.assign({ justifyContent: 'space-evenly', w: '100%' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Input, { variant: 'filled', color: "grey.600", w: ['300px', '350px', '400px', '500px'], placeholder: (0, macro_1.t) `Search vault`, m: "auto", onChange: (ev) => {
                            setFilterBy(ev.target.value);
                        } }), (0, jsx_runtime_1.jsxs)(react_1.Center, Object.assign({ px: 3 }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Stat, Object.assign({ ml: "auto", whiteSpace: 'nowrap' }, { children: [LoginCredentials.length + TOTPSecrets.length, " ", (0, macro_1.t) `secrets`] })), (0, jsx_runtime_1.jsx)(RefreshSecretsButton_1.RefreshSecretsButton, {})] })), error ? ((0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ shouldWrapChildren: true, label: "You have reached your limit", "aria-label": "A tooltip" }, { children: (0, jsx_runtime_1.jsx)(button_1.IconButton, { disabled: true, "aria-label": "Add item", icon: (0, jsx_runtime_1.jsx)(icons_1.AddIcon, {}), rounded: 'full', onClick: () => __awaiter(void 0, void 0, void 0, function* () { return navigate('/addItem'); }) }) }))) : ((0, jsx_runtime_1.jsx)(button_1.IconButton, { "aria-label": "Add item", icon: (0, jsx_runtime_1.jsx)(icons_1.AddIcon, {}), rounded: 'full', onClick: () => __awaiter(void 0, void 0, void 0, function* () { return navigate('/addItem'); }) }))] })), (0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ w: '95%', h: '95%' }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ style: { flex: '1 1 auto', height: '100%', width: '100%' } }, { children: (0, jsx_runtime_1.jsx)(VirtualizedList_1.VirtualizedList, { filter: filterBy }) })) }))] })));
};
exports.VaultList = VaultList;
//# sourceMappingURL=VaultList.js.map