"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NewDevicesApprovalStack = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const macro_1 = require("@lingui/macro");
const AccountDevices_codegen_1 = require("@shared/graphql/AccountDevices.codegen");
const date_fns_1 = require("date-fns");
const LoginAwaitingApproval_1 = require("./LoginAwaitingApproval");
const NewDevicesApprovalStack = () => {
    var _a;
    const { refetch: devicesRefetch } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    const { data: devicesRequests, refetch } = (0, AccountDevices_codegen_1.useDevicesRequestsQuery)();
    const [reject] = (0, AccountDevices_codegen_1.useRejectChallengeMutation)();
    const [approve] = (0, AccountDevices_codegen_1.useApproveChallengeMutation)();
    return ((0, jsx_runtime_1.jsx)(react_1.VStack, Object.assign({ mt: 3 }, { children: (_a = devicesRequests === null || devicesRequests === void 0 ? void 0 : devicesRequests.me) === null || _a === void 0 ? void 0 : _a.decryptionChallengesWaiting.map((challengeToApprove) => {
            return ((0, jsx_runtime_1.jsxs)(react_1.Alert, Object.assign({ minW: "90%", status: "warning", display: "grid", rounded: 4, gridRowGap: 1, maxW: 500 }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Center, { children: ["New device \"", challengeToApprove.deviceName, "\" trying to login", ' ', (0, date_fns_1.formatRelative)(new Date(challengeToApprove.createdAt), new Date()), ": from IP ", challengeToApprove.ipAddress, " (", challengeToApprove.ipGeoLocation.city, ",", ' ', challengeToApprove.ipGeoLocation.country_name, ")"] }), (0, jsx_runtime_1.jsxs)(react_1.Grid, Object.assign({ gridGap: 1, autoFlow: "row", templateColumns: "repeat(auto-fit, 49%)" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Center, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ w: "50%", colorScheme: "red", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                        yield reject({
                                            variables: {
                                                id: challengeToApprove.id
                                            }
                                        });
                                        yield refetch();
                                    }) }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Reject" }) })) }), (0, jsx_runtime_1.jsx)(react_1.Center, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ w: "50%", colorScheme: "green", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                        yield approve({
                                            variables: {
                                                id: challengeToApprove.id
                                            }
                                        });
                                        yield refetch();
                                        setTimeout(() => {
                                            devicesRefetch();
                                        }, LoginAwaitingApproval_1.LOGIN_DECRYPTION_CHALLENGE_REFETCH_INTERVAL); // this is needed, because it takes time one the client side to do the decryption challenge
                                    }) }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Approve" }) })) })] }))] }), challengeToApprove.id));
        }) })));
};
exports.NewDevicesApprovalStack = NewDevicesApprovalStack;
//# sourceMappingURL=NewDeviceApproval.js.map