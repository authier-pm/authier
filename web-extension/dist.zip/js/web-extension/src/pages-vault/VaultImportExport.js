"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VaultImportExport = exports.onJsonFileAccepted = exports.onCSVFileAccepted = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const macro_1 = require("@lingui/macro");
const ExportCsvButtons_1 = require("@src/components/vault/ExportCsvButtons");
const ImportFromFile_1 = require("@src/components/vault/ImportFromFile");
const react_2 = __importDefault(require("react"));
const papaparse_1 = __importDefault(require("papaparse"));
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const graphqlBaseTypes_1 = require("../../../shared/generated/graphqlBaseTypes");
const AccountLimits_codegen_1 = require("./AccountLimits.codegen");
const Providers_1 = require("@src/Providers");
// const csvHeaderNames = {
//   password: [
//     'password',
//     'login_password'
//   ],
//   url: [
//     'url', // lastpass
//     'login_uri' // bitwarden
//   ]
// }
const mapCsvToLoginCredentials = (csv) => {
    const [header] = csv;
    const indexUsername = header.findIndex((x) => x.match(/username/i));
    const indexLabel = header.findIndex((x) => x === 'name');
    const indexPassword = header.findIndex((x) => x.match(/password/i));
    const indexUrl = header.findIndex((x) => {
        return x === 'url' || x === 'login_uri';
    });
    if (indexUsername === -1 ||
        indexLabel === -1 ||
        indexPassword === -1 ||
        indexUrl === -1) {
        return [];
    }
    return csv
        .slice(1)
        .filter((row) => row[indexUrl] && row[indexUsername] && row[indexPassword])
        .map((row) => ({
        label: row[indexLabel],
        url: row[indexUrl],
        username: row[indexUsername],
        password: row[indexPassword],
        iconUrl: null // TODO add icon Url if it is in the CSV
    }));
};
/**
 * should support lastpass and bitwarden for now, TODO write e2e specs
 */
const onCSVFileAccepted = (file, pswCount) => {
    return new Promise((resolve) => {
        papaparse_1.default.parse(file, {
            complete: (results) => __awaiter(void 0, void 0, void 0, function* () {
                var _a, _b;
                if (!results.data) {
                    (0, Providers_1.toast)({
                        title: 'failed to parse',
                        status: 'error',
                        isClosable: true
                    });
                }
                const mapped = mapCsvToLoginCredentials(results.data);
                const state = ExtensionDevice_1.device.state;
                const toAdd = [];
                let skipped = 0;
                let added = 0;
                for (const creds of mapped) {
                    if (((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.decryptedSecrets.length) + added >=
                        pswCount) {
                        (0, Providers_1.toast)({
                            title: 'You have reached your limit of secrets',
                            status: 'error',
                            isClosable: true
                        });
                        break;
                    }
                    let hostname;
                    try {
                        hostname = new URL(creds.url).hostname;
                    }
                    catch (error) {
                        skipped++;
                        break;
                    }
                    const input = {
                        kind: graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS,
                        loginCredentials: creds,
                        url: creds.url,
                        encrypted: yield (state === null || state === void 0 ? void 0 : state.encrypt(JSON.stringify(creds))),
                        createdAt: new Date().toJSON(),
                        iconUrl: null,
                        label: (_b = creds.label) !== null && _b !== void 0 ? _b : `${creds.username}@${hostname}`
                    };
                    if (yield state.findExistingSecret(input)) {
                        skipped++;
                        continue;
                    }
                    toAdd.push(input);
                    added += 1;
                }
                yield state.addSecrets(toAdd);
                resolve({
                    added,
                    skipped
                });
            })
        });
    });
};
exports.onCSVFileAccepted = onCSVFileAccepted;
const onJsonFileAccepted = (file) => __awaiter(void 0, void 0, void 0, function* () {
    const state = ExtensionDevice_1.device.state;
    const parsed = JSON.parse(yield file.text());
    const toAdd = [];
    for (const totp of parsed) {
        if (!totp.originalName) {
            continue; // for some reason authy has secrets without any name. These are not shown in the Authy app, so we are skipping. Nobody would know what these secrets are for anyway
        }
        const totpWithMeta = Object.assign(Object.assign({}, totp), { iconUrl: null, label: totp.originalName });
        toAdd.push({
            kind: graphqlBaseTypes_1.EncryptedSecretType.TOTP,
            totp: totpWithMeta,
            encrypted: yield state.encrypt(JSON.stringify(totpWithMeta)),
            createdAt: new Date().toJSON()
        });
    }
    yield state.addSecrets(toAdd);
    return { added: toAdd.length, skipped: 0 };
});
exports.onJsonFileAccepted = onJsonFileAccepted;
const VaultImportExport = () => {
    const [importedStat, setImportedStat] = react_2.default.useState(null);
    const { data } = (0, AccountLimits_codegen_1.useMeExtensionQuery)();
    return ((0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ p: 5 }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ maxW: '1200px', flexDir: 'column' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ size: "sm" }, { children: "Import" })), (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ p: 30, width: "100%" }, { children: !importedStat ? ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(ImportFromFile_1.ImportFromFile, { onFileAccepted: (f) => __awaiter(void 0, void 0, void 0, function* () {
                                    if (f.type === 'text/csv') {
                                        setImportedStat(yield (0, exports.onCSVFileAccepted)(f, data === null || data === void 0 ? void 0 : data.me.PasswordLimits));
                                    }
                                    else if (f.type === 'application/json') {
                                        setImportedStat(yield (0, exports.onJsonFileAccepted)(f));
                                    }
                                }) }), (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: 16, mt: 8, mb: 6 }, { children: (0, jsx_runtime_1.jsxs)(macro_1.Trans, { children: ["We support importing from ", (0, jsx_runtime_1.jsx)("code", { children: "csv" }), " and", ' ', (0, jsx_runtime_1.jsx)("code", { children: "json" }), " files.", (0, jsx_runtime_1.jsxs)("ul", { children: [(0, jsx_runtime_1.jsx)("li", { children: "Lastpass/Bitwarden will work fine, file exported from other password managers might work as well, but it's not guaranteed." }), (0, jsx_runtime_1.jsxs)("li", { children: ["For JSON, it must be a file exported from", ' ', (0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ href: "https://www.npmjs.com/package/authy-desktop-export" }, { children: "authy-desktop-export" }))] })] })] }) }))] })) : ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(react_1.Alert, Object.assign({ status: "success" }, { children: (0, jsx_runtime_1.jsxs)(macro_1.Trans, { children: ["Successfully added ", importedStat.added, ", skipped", ' ', importedStat.skipped] }) })), (0, jsx_runtime_1.jsx)(react_1.Center, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ m: 2, onClick: () => {
                                        setImportedStat(null);
                                    } }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Import another" }) })) })] })) })), (0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ size: "sm" }, { children: "Export" })), (0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ m: 8 }, { children: [(0, jsx_runtime_1.jsx)(ExportCsvButtons_1.ExportLoginCredentialsToCsvButton, {}), (0, jsx_runtime_1.jsx)("br", {}), (0, jsx_runtime_1.jsx)(ExportCsvButtons_1.ExportTOTPToCsvButton, {})] }))] })) })));
};
exports.VaultImportExport = VaultImportExport;
//# sourceMappingURL=VaultImportExport.js.map