"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.backgroundStateSerializableLockedSchema = exports.settingsSchema = exports.webInputElementSchema = exports.capturedEventsPayloadSchema = exports.encryptedDataSchema = exports.loginCredentialsFromContentScriptSchema = exports.loginCredentialSchema = exports.contentScriptContextSchema = exports.capturedInputSchema = void 0;
const graphqlBaseTypes_1 = require("@shared/generated/graphqlBaseTypes");
const zod_1 = require("zod");
exports.capturedInputSchema = zod_1.z.object({
    cssSelector: zod_1.z.string().min(1),
    domOrdinal: zod_1.z.number(),
    type: zod_1.z.union([
        zod_1.z.literal('input'),
        zod_1.z.literal('submit'),
        zod_1.z.literal('keydown')
    ]),
    kind: zod_1.z.nativeEnum(graphqlBaseTypes_1.WebInputType),
    inputted: zod_1.z.string().optional(),
    domCoordinates: zod_1.z.object({ x: zod_1.z.number(), y: zod_1.z.number() })
});
exports.contentScriptContextSchema = zod_1.z.object({
    capturedInputEvents: zod_1.z.array(exports.capturedInputSchema),
    openInVault: zod_1.z.boolean()
});
exports.loginCredentialSchema = zod_1.z.object({
    username: zod_1.z.string(),
    password: zod_1.z.string()
});
exports.loginCredentialsFromContentScriptSchema = exports.contentScriptContextSchema.extend({
    username: zod_1.z.string(),
    password: zod_1.z.string()
});
exports.encryptedDataSchema = exports.loginCredentialSchema.extend({
    iconUrl: zod_1.z.string().nullable(),
    url: zod_1.z.string(),
    label: zod_1.z.string()
});
exports.capturedEventsPayloadSchema = zod_1.z.object({
    url: zod_1.z.string(),
    inputEvents: zod_1.z.array(exports.capturedInputSchema)
});
exports.webInputElementSchema = zod_1.z.object({
    domCoordinates: zod_1.z.object({ x: zod_1.z.number(), y: zod_1.z.number() }),
    domOrdinal: zod_1.z.number(),
    domPath: zod_1.z.string(),
    kind: zod_1.z.nativeEnum(graphqlBaseTypes_1.WebInputType),
    url: zod_1.z.string()
});
exports.settingsSchema = zod_1.z.object({
    autofill: zod_1.z.boolean(),
    language: zod_1.z.string(),
    syncTOTP: zod_1.z.boolean(),
    theme: zod_1.z.string().optional().nullable(),
    vaultLockTimeoutSeconds: zod_1.z.number()
});
exports.backgroundStateSerializableLockedSchema = zod_1.z.object({
    email: zod_1.z.string(),
    userId: zod_1.z.string(),
    secrets: zod_1.z.array(zod_1.z.object({
        id: zod_1.z.string(),
        encrypted: zod_1.z.string(),
        kind: zod_1.z.nativeEnum(graphqlBaseTypes_1.EncryptedSecretType),
        lastUsedAt: zod_1.z.string().nullable().optional(),
        createdAt: zod_1.z.string(),
        deletedAt: zod_1.z.string().nullable().optional(),
        updatedAt: zod_1.z.string().nullable().optional()
    })),
    encryptionSalt: zod_1.z.string(),
    deviceName: zod_1.z.string(),
    authSecretEncrypted: zod_1.z.string(),
    authSecret: zod_1.z.string(),
    lockTime: zod_1.z.number(),
    autofill: zod_1.z.boolean(),
    language: zod_1.z.string(),
    theme: zod_1.z.string(),
    syncTOTP: zod_1.z.boolean(),
    masterEncryptionKey: zod_1.z.string()
});
//# sourceMappingURL=backgroundSchemas.js.map