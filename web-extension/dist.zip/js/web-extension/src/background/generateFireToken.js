"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateFireToken = exports.messaging = void 0;
const app_1 = require("firebase/app");
const messaging_1 = require("firebase/messaging");
const firebaseConfig = {
    apiKey: 'AIzaSyBkBIcE71acyLg1yMNJwn3Ys_CxbY5gt7U',
    authDomain: 'authier-bc184.firebaseapp.com',
    projectId: 'authier-bc184',
    storageBucket: 'authier-bc184.appspot.com',
    messagingSenderId: '500382892914',
    appId: '1:500382892914:web:6b202f90d6c0c6bcc213eb',
    measurementId: 'G-0W2MW55WVF'
};
const firebaseApp = (0, app_1.initializeApp)(firebaseConfig);
exports.messaging = (0, messaging_1.getMessaging)(firebaseApp);
// export function setLockTime(val: number) {
//   log('setLockTime', val)
//   if (typeof val !== 'number') {
//     throw new Error('setLockTime must have a number value')
//   }
//   lockTime = val
// }
// broadcast.onmessage = (event) => {
//   if (event.data.data.success === 'true') {
//     log('sec', typeof otpCode)
//     let a = executeScriptInCurrentTab(
//       `const OTP = ${otpCode};` + `(` + fillInput.toString() + `)()`
//     )
//   }
// }
function generateFireToken() {
    return __awaiter(this, void 0, void 0, function* () {
        return yield (0, messaging_1.getToken)(exports.messaging, {
            vapidKey: 'BPxh_JmX3cR4Cb6lCYon2cC0iAVlv8dOL1pjX2Q33ROT0VILKuGAlTqG1uH8YZXQRCscLlxqct0XeTiUvF4sy4A'
        });
    });
}
exports.generateFireToken = generateFireToken;
//# sourceMappingURL=generateFireToken.js.map