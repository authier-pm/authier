"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SharedBrowserEvents = void 0;
var SharedBrowserEvents;
(function (SharedBrowserEvents) {
    SharedBrowserEvents["URL_CHANGED"] = "URL_CHANGED";
})(SharedBrowserEvents = exports.SharedBrowserEvents || (exports.SharedBrowserEvents = {}));
//# sourceMappingURL=SharedBrowserEvents.js.map