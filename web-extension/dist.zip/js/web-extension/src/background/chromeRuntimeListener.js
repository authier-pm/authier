"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.noHandsLogin = exports.saveLoginModalsStates = void 0;
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const debug_1 = __importDefault(require("debug"));
const apolloClient_1 = require("@src/apollo/apolloClient");
const chromeRuntimeListener_codegen_1 = require("./chromeRuntimeListener.codegen");
const graphqlBaseTypes_1 = require("@shared/generated/graphqlBaseTypes");
const server_1 = require("@trpc/server");
const adapter_1 = require("trpc-chrome/adapter");
const ExtensionDevice_1 = require("./ExtensionDevice");
const getContentScriptInitialState_1 = require("./getContentScriptInitialState");
const backgroundSchemas_1 = require("./backgroundSchemas");
const zod_1 = require("zod");
const log = (0, debug_1.default)('au:chListener');
if (!ExtensionDevice_1.isRunningInBgPage) {
    throw new Error('this file should only be imported in the background page');
}
const t = server_1.initTRPC.create({
    isServer: false,
    allowOutsideOfServer: true
});
//NOTE: temporery storage for not yet saved credentials. (during page rerender)
exports.saveLoginModalsStates = new Map();
exports.noHandsLogin = false;
let capturedInputEvents = [];
let inputsUrl;
let lockTimeEnd;
let lockTimeStart;
let lockInterval;
const appRouter = t.router({
    addLoginCredentials: t.procedure
        .input(backgroundSchemas_1.loginCredentialsFromContentScriptSchema)
        .mutation(({ ctx, input }) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b;
        //@ts-ignore
        const tab = ctx.sender.tab;
        const deviceState = ExtensionDevice_1.device.state;
        const { url } = tab;
        if (!url || !deviceState) {
            return false; // we can't do anything without a valid url
        }
        let urlParsed;
        try {
            urlParsed = new URL(url);
        }
        catch (err) {
            return false;
        }
        const credentials = input;
        log('addLoginCredentials', credentials);
        const encryptedData = {
            username: credentials.username,
            password: credentials.password,
            iconUrl: (_a = tab.favIconUrl) !== null && _a !== void 0 ? _a : null,
            url: inputsUrl,
            label: (_b = tab.title) !== null && _b !== void 0 ? _b : `${credentials.username}@${urlParsed.hostname}`
        };
        backgroundSchemas_1.encryptedDataSchema.parse(encryptedData);
        const encrypted = yield deviceState.encrypt(JSON.stringify(encryptedData));
        const [secret] = yield deviceState.addSecrets([
            {
                kind: graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS,
                loginCredentials: encryptedData,
                encrypted,
                createdAt: new Date().toJSON()
            }
        ]);
        if (!secret) {
            return false;
        }
        tab.id && exports.saveLoginModalsStates.delete(tab.id);
        const webInputs = credentials.capturedInputEvents.map((captured) => {
            return {
                domPath: captured.cssSelector,
                kind: captured.kind,
                url: inputsUrl,
                domOrdinal: captured.domOrdinal,
                domCoordinates: captured.domCoordinates
            };
        });
        yield apolloClient_1.apolloClient.mutate({
            mutation: chromeRuntimeListener_codegen_1.AddWebInputsDocument,
            variables: {
                webInputs
            }
        });
        if (input.openInVault) {
            webextension_polyfill_1.default.tabs.create({ url: `vault.html#/secret/${secret.id}` });
        }
    })),
    saveCapturedInputEvents: t.procedure
        .input(backgroundSchemas_1.capturedEventsPayloadSchema)
        .mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        capturedInputEvents = input.inputEvents;
        inputsUrl = input.url;
        const newWebInputs = capturedInputEvents.map((captured) => {
            return {
                domPath: captured.cssSelector,
                kind: captured.kind,
                url: inputsUrl,
                domOrdinal: captured.domOrdinal,
                domCoordinates: captured.domCoordinates
            };
        });
        //Update web inputs in DB
        yield apolloClient_1.apolloClient.mutate({
            mutation: chromeRuntimeListener_codegen_1.AddWebInputsDocument,
            variables: {
                webInputs: newWebInputs
            }
        });
    })),
    saveLoginCredentialsModalShown: t.procedure
        .input(backgroundSchemas_1.loginCredentialSchema)
        .mutation(({ input, ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        //@ts-ignore
        const tab = ctx.sender.tab;
        const currentTabId = tab.id;
        if (currentTabId) {
            exports.saveLoginModalsStates.set(currentTabId, input);
        }
    })),
    hideLoginCredentialsModal: t.procedure.mutation(({ ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        //@ts-ignore
        const tab = ctx.sender.tab;
        const currentTabId = tab.id;
        if (currentTabId) {
            exports.saveLoginModalsStates.delete(currentTabId);
        }
    })),
    addTOTPInput: t.procedure
        .input(backgroundSchemas_1.webInputElementSchema)
        .mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        yield apolloClient_1.apolloClient.mutate({
            mutation: chromeRuntimeListener_codegen_1.AddWebInputsDocument,
            variables: {
                webInputs: [input]
            }
        });
    })),
    getFallbackUsernames: t.procedure.query(() => __awaiter(void 0, void 0, void 0, function* () {
        const deviceState = ExtensionDevice_1.device.state;
        log('Getting fallback usernames', deviceState === null || deviceState === void 0 ? void 0 : deviceState.email);
        return [deviceState === null || deviceState === void 0 ? void 0 : deviceState.email];
    })),
    getContentScriptInitialState: t.procedure.query(({ ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        //@ts-ignore
        const tab = ctx.sender.tab;
        const currentTabId = tab.id;
        const tabUrl = tab === null || tab === void 0 ? void 0 : tab.url;
        const deviceState = ExtensionDevice_1.device.state;
        log('GEtting initial state from BG', tab === null || tab === void 0 ? void 0 : tab.url, tab === null || tab === void 0 ? void 0 : tab.pendingUrl);
        if (!tabUrl || !deviceState || !currentTabId) {
            log('~ chromeRuntimeListener We dont have tabURL or deviceState or tabId');
            return null;
        }
        else {
            //We will have to get webInputs for current URL from DB and send it to content script for reseting after new DOM path save
            return (0, getContentScriptInitialState_1.getContentScriptInitialState)(tabUrl, currentTabId);
        }
    })),
    getCapturedInputEvents: t.procedure.query(({ ctx }) => __awaiter(void 0, void 0, void 0, function* () {
        //@ts-ignore
        const tab = ctx.sender.tab;
        return { capturedInputEvents, inputsUrl: tab === null || tab === void 0 ? void 0 : tab.url };
    })),
    securitySettings: t.procedure
        .input(backgroundSchemas_1.settingsSchema)
        .mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        const deviceState = ExtensionDevice_1.device.state;
        if (deviceState) {
            deviceState.lockTime = input.vaultLockTimeoutSeconds;
            deviceState.syncTOTP = input.syncTOTP;
            deviceState.language = input.language;
            deviceState.autofill = input.autofill;
            exports.noHandsLogin = input.autofill;
            //Refresh the lock interval
            lockInterval = clearInterval(lockInterval);
            lockTimeStart = Date.now();
            lockTimeEnd = lockTimeStart + deviceState.lockTime * 1000;
            checkInterval(lockTimeEnd);
            deviceState.save();
        }
        return true;
    })),
    setLockInterval: t.procedure
        .input(zod_1.z.object({ time: zod_1.z.number() }))
        .mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        if (!lockInterval) {
            lockTimeStart = Date.now();
            lockTimeEnd = lockTimeStart + input.time * 1000;
        }
        checkInterval(lockTimeEnd);
        return true;
    })),
    clearLockInterval: t.procedure.mutation(() => __awaiter(void 0, void 0, void 0, function* () {
        resetInterval();
        return true;
    })),
    setDeviceState: t.procedure
        .input(backgroundSchemas_1.backgroundStateSerializableLockedSchema)
        .mutation(({ input }) => __awaiter(void 0, void 0, void 0, function* () {
        ExtensionDevice_1.device.save(input);
        return true;
    }))
});
(0, adapter_1.createChromeHandler)({
    router: appRouter,
    createContext: (ctx) => {
        return { sender: ctx.req.sender };
    },
    onError: (err) => {
        console.error('TRPC ERROR', err);
    }
});
log('background page loaded');
const checkInterval = (time) => {
    if (!lockInterval && lockTimeStart !== lockTimeEnd) {
        lockInterval = setInterval(() => {
            if (time && time <= Date.now()) {
                log('lock', Date.now(), ExtensionDevice_1.device);
                resetInterval();
                ExtensionDevice_1.device.lock();
            }
        }, 5000);
    }
};
const resetInterval = () => {
    lockTimeEnd = null;
    lockTimeStart = null;
    lockInterval = clearInterval(lockInterval);
};
//# sourceMappingURL=chromeRuntimeListener.js.map