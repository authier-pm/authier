"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackgroundMessageType = void 0;
var BackgroundMessageType;
(function (BackgroundMessageType) {
    BackgroundMessageType["getFallbackUsernames"] = "getFallbackUsernames";
    BackgroundMessageType["rerenderViews"] = "rerenderViews";
    BackgroundMessageType["wasClosed"] = "wasClosed";
    BackgroundMessageType["addTOTPInput"] = "addTOTPInput";
    BackgroundMessageType["startCount"] = "startCount";
    BackgroundMessageType["loggedIn"] = "loggedIn";
    BackgroundMessageType["passwords"] = "passwords";
    BackgroundMessageType["securitySettings"] = "securitySettings";
    BackgroundMessageType["giveSecuritySettings"] = "giveSecuritySettings";
    BackgroundMessageType["giveUISettings"] = "giveUISettings";
    BackgroundMessageType["UISettings"] = "UISettings";
    BackgroundMessageType["addLoginCredentials"] = "addLoginCredentials";
    BackgroundMessageType["addTOTPSecret"] = "addTOTPSecret";
    BackgroundMessageType["getContentScriptInitialState"] = "getContentScriptInitialState";
    BackgroundMessageType["hideLoginCredentialsModal"] = "hideLoginCredentialsModal";
    BackgroundMessageType["saveLoginCredentialsModalShown"] = "saveLoginCredentialsModalShown";
    BackgroundMessageType["saveCapturedInputEvents"] = "saveCapturedInputEvents";
    BackgroundMessageType["getCapturedInputEvents"] = "getCapturedInputEvents";
    BackgroundMessageType["getLockInterval"] = "getLockInterval";
    BackgroundMessageType["setLockInterval"] = "setLockInterval";
    BackgroundMessageType["clearLockInterval"] = "clearLockInterval";
    BackgroundMessageType["setDeviceState"] = "setDeviceState";
})(BackgroundMessageType = exports.BackgroundMessageType || (exports.BackgroundMessageType = {}));
//# sourceMappingURL=BackgroundMessageType.js.map