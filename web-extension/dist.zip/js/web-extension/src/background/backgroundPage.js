"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.log = void 0;
require("./chromeRuntimeListener");
const debug_1 = __importDefault(require("debug"));
exports.log = (0, debug_1.default)('au:backgroundPage');
localStorage.debug = 'au:*'; // enable all debug messages
if ('serviceWorker' in navigator) {
    navigator.serviceWorker
        .register('/firebase-messaging-sw.js')
        .then(function (registration) {
        (0, exports.log)('ServiceWorker registration successful with scope: ', registration.scope);
    })
        .catch(function (err) {
        //registration failed :(
        (0, exports.log)('ServiceWorker registration failed: ', err);
    });
}
else {
    (0, exports.log)('No service-worker on this browser');
}
//# sourceMappingURL=backgroundPage.js.map