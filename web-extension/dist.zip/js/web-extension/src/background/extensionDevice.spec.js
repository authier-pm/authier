"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const ExtensionDevice_1 = require("./ExtensionDevice");
describe('ExtensionDevice', () => {
    describe('startLockInterval', () => {
        it('should send a message to the background page to set the lock interval', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockRuntimeSendMessage = jest.fn();
            chrome.runtime.sendMessage = mockRuntimeSendMessage;
            yield ExtensionDevice_1.device.startLockInterval(1234);
            expect(mockRuntimeSendMessage).toHaveBeenCalledWith({
                action: 'setLockInterval',
                time: 1234
            });
        }));
    });
    describe('clearLockInterval', () => {
        it('should send a message to the background page to clear the lock interval', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockRuntimeSendMessage = jest.fn();
            chrome.runtime.sendMessage = mockRuntimeSendMessage;
            yield ExtensionDevice_1.device.clearLockInterval();
            expect(mockRuntimeSendMessage).toHaveBeenCalledWith({
                action: 'clearLockInterval'
            });
        }));
    });
    describe('platform', () => {
        it('should return the OS name from the browserInfo module', () => {
            const mockOSName = 'Mock OS';
            jest.mock('./browserInfo', () => ({
                getOSName: () => mockOSName
            }));
            expect(ExtensionDevice_1.device.platform).toBe(mockOSName);
        });
    });
    describe('initialize', () => {
        it('should initialize the device and start the lock interval if a device state is present in storage', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockGet = jest.fn().mockResolvedValue({
                backgroundState: {
                    deviceName: 'Mock device',
                    lockTime: 1234
                }
            });
            chrome.storage.local.get = mockGet;
            const mockStartLockInterval = jest.fn();
            ExtensionDevice_1.device.startLockInterval = mockStartLockInterval;
            yield ExtensionDevice_1.device.initialize();
            expect(mockGet).toHaveBeenCalled();
            expect(ExtensionDevice_1.device.state).toBeTruthy();
            expect(ExtensionDevice_1.device.name).toBe('Mock device');
            expect(mockStartLockInterval).toHaveBeenCalledWith(1234);
        }));
        it('should initialize the device in a locked state if a locked state is present in storage', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockGet = jest.fn().mockResolvedValue({
                lockedState: {
                    id: 'Mock locked state ID'
                }
            });
            chrome.storage.local.get = mockGet;
            const mockGenerateDeviceName = jest
                .fn()
                .mockReturnValue('Mock device name');
            ExtensionDevice_1.device.generateDeviceName = mockGenerateDeviceName;
            yield ExtensionDevice_1.device.initialize();
            expect(mockGet).toHaveBeenCalled();
            expect(ExtensionDevice_1.device.state).toBeFalsy();
            expect(ExtensionDevice_1.device.lockedState).toEqual;
        }));
    });
});
//# sourceMappingURL=extensionDevice.spec.js.map