"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useWebInputsForHostLazyQuery = exports.useWebInputsForHostQuery = exports.WebInputsForHostDocument = exports.useAddWebInputsMutation = exports.AddWebInputsDocument = void 0;
const client_1 = require("@apollo/client");
const Apollo = __importStar(require("@apollo/client"));
const defaultOptions = {};
exports.AddWebInputsDocument = (0, client_1.gql) `
    mutation addWebInputs($webInputs: [WebInputElement!]!) {
  addWebInputs(webInputs: $webInputs) {
    id
  }
}
    `;
/**
 * __useAddWebInputsMutation__
 *
 * To run a mutation, you first call `useAddWebInputsMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useAddWebInputsMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [addWebInputsMutation, { data, loading, error }] = useAddWebInputsMutation({
 *   variables: {
 *      webInputs: // value for 'webInputs'
 *   },
 * });
 */
function useAddWebInputsMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.AddWebInputsDocument, options);
}
exports.useAddWebInputsMutation = useAddWebInputsMutation;
exports.WebInputsForHostDocument = (0, client_1.gql) `
    query webInputsForHost($host: String!) {
  webInputs(host: $host) {
    id
    host
    url
    domPath
    domOrdinal
    kind
    createdAt
    domCoordinates
  }
}
    `;
/**
 * __useWebInputsForHostQuery__
 *
 * To run a query within a React component, call `useWebInputsForHostQuery` and pass it any options that fit your needs.
 * When your component renders, `useWebInputsForHostQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useWebInputsForHostQuery({
 *   variables: {
 *      host: // value for 'host'
 *   },
 * });
 */
function useWebInputsForHostQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.WebInputsForHostDocument, options);
}
exports.useWebInputsForHostQuery = useWebInputsForHostQuery;
function useWebInputsForHostLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.WebInputsForHostDocument, options);
}
exports.useWebInputsForHostLazyQuery = useWebInputsForHostLazyQuery;
//# sourceMappingURL=chromeRuntimeListener.codegen.js.map