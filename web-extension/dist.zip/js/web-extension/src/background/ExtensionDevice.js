"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.device = exports.DeviceState = exports.getDecryptedSecretProp = exports.isRunningInBgPage = exports.extensionDeviceTrpc = exports.log = void 0;
const debug_1 = __importDefault(require("debug"));
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const bowser_1 = __importDefault(require("bowser"));
const accessTokenExtension_1 = require("@src/util/accessTokenExtension");
const graphqlBaseTypes_1 = require("../../../shared/generated/graphqlBaseTypes");
const apolloClient_1 = require("@src/apollo/apolloClient");
const ExtensionDevice_codegen_1 = require("@shared/graphql/ExtensionDevice.codegen");
const loginCredentialsSchema_1 = require("@src/util/loginCredentialsSchema");
const generateEncryptionKey_1 = require("@util/generateEncryptionKey");
const Providers_1 = require("@src/Providers");
const client_1 = require("@trpc/client");
const link_1 = require("trpc-chrome/link");
exports.log = (0, debug_1.default)('au:Device');
const port = chrome.runtime.connect();
exports.extensionDeviceTrpc = (0, client_1.createTRPCProxyClient)({
    links: [(0, link_1.chromeLink)({ port })]
});
const getTldPart = (url) => {
    const host = new URL(url !== null && url !== void 0 ? url : '').hostname;
    const parts = host.split('.');
    return `${parts[parts.length - 2]}.${parts[parts.length - 1]}`;
};
function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
}
const browserInfo = bowser_1.default.getParser(navigator.userAgent);
exports.isRunningInBgPage = location.href.includes('_generated_background_page.html');
const isVault = location.href.includes('vault.html');
const isPopup = location.href.includes('popup.html');
function rerenderViewInThisRuntime() {
    return __awaiter(this, void 0, void 0, function* () {
        if (isVault) {
            const index = yield Promise.resolve().then(() => __importStar(require('@src/vault-index')));
            index.renderVault();
        }
        else if (isPopup) {
            const index = yield Promise.resolve().then(() => __importStar(require('..')));
            index.renderPopup();
        }
    });
}
const isLoginSecret = (secret) => 'loginCredentials' in secret;
const isTotpSecret = (secret) => 'totp' in secret;
const getDecryptedSecretProp = (secret, prop) => {
    var _a;
    return ((_a = (secret.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP
        ? secret.totp[prop]
        : secret.loginCredentials[prop])) !== null && _a !== void 0 ? _a : '');
};
exports.getDecryptedSecretProp = getDecryptedSecretProp;
class DeviceState {
    constructor(parameters) {
        Object.assign(this, parameters);
        //log('device state created', this)
        webextension_polyfill_1.default.storage.onChanged.addListener(this.onStorageChange);
        this.initialize();
    }
    onStorageChange(changes, areaName) {
        (0, exports.log)('storage changed', changes, areaName);
        if (areaName === 'local' && changes.backgroundState && exports.device.state) {
            Object.assign(exports.device.state, changes.backgroundState.newValue);
        }
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            this.decryptedSecrets = yield this.getAllSecretsDecrypted();
        });
    }
    setMasterEncryptionKey(masterPassword) {
        return __awaiter(this, void 0, void 0, function* () {
            const key = yield (0, generateEncryptionKey_1.generateEncryptionKey)(masterPassword, (0, generateEncryptionKey_1.base64_to_buf)(this.encryptionSalt));
            this.masterEncryptionKey = yield (0, generateEncryptionKey_1.cryptoKeyToString)(key);
            this.save();
        });
    }
    /**
     * @returns string in base64
     */
    encrypt(stringToEncrypt) {
        return __awaiter(this, void 0, void 0, function* () {
            const cryptoKey = yield (0, generateEncryptionKey_1.abToCryptoKey)((0, generateEncryptionKey_1.base64_to_buf)(this.masterEncryptionKey));
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const salt = (0, generateEncryptionKey_1.base64_to_buf)(this.encryptionSalt);
            const encrypted = yield window.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cryptoKey, generateEncryptionKey_1.enc.encode(stringToEncrypt));
            return (0, generateEncryptionKey_1.encryptedBuf_to_base64)(encrypted, iv, salt);
        });
    }
    /**
     * @param encrypted in base64
     * @returns pure string
     */
    decrypt(encrypted) {
        return __awaiter(this, void 0, void 0, function* () {
            const cryptoKey = yield (0, generateEncryptionKey_1.abToCryptoKey)((0, generateEncryptionKey_1.base64_to_buf)(this.masterEncryptionKey));
            const encryptedDataBuff = (0, generateEncryptionKey_1.base64_to_buf)(encrypted);
            const iv = encryptedDataBuff.slice(16, 16 + 12);
            const data = encryptedDataBuff.slice(16 + 12);
            const decrypted = yield window.crypto.subtle.decrypt({ name: 'AES-GCM', iv }, cryptoKey, data);
            return generateEncryptionKey_1.dec.decode(decrypted);
        });
    }
    save() {
        return __awaiter(this, void 0, void 0, function* () {
            webextension_polyfill_1.default.storage.onChanged.removeListener(this.onStorageChange);
            exports.device.lockedState = null;
            this.decryptedSecrets = yield this.getAllSecretsDecrypted();
            (0, exports.log)('SAVE DEVICE STATE', this.decryptedSecrets);
            yield webextension_polyfill_1.default.storage.local.set({
                backgroundState: this,
                lockedState: null
            });
            webextension_polyfill_1.default.storage.onChanged.addListener(this.onStorageChange);
        });
    }
    getSecretDecryptedById(id) {
        const secret = this.decryptedSecrets.find((secret) => secret.id === id);
        if (secret) {
            return this.decryptSecret(secret);
        }
    }
    getSecretsDecryptedByHostname(host) {
        return __awaiter(this, void 0, void 0, function* () {
            let secrets = this.decryptedSecrets.filter((secret) => {
                var _a;
                return (host === new URL((_a = (0, exports.getDecryptedSecretProp)(secret, 'url')) !== null && _a !== void 0 ? _a : '').hostname);
            });
            if (secrets.length === 0) {
                secrets = this.decryptedSecrets.filter((secret) => { var _a; return host.endsWith(getTldPart((_a = (0, exports.getDecryptedSecretProp)(secret, 'url')) !== null && _a !== void 0 ? _a : '')); });
            }
            return Promise.all(secrets.map((secret) => {
                return this.decryptSecret(secret);
            }));
        });
    }
    getAllSecretsDecrypted() {
        return Promise.all(this.secrets.map((secret) => {
            return this.decryptSecret(secret);
        }));
    }
    decryptSecret(secret) {
        return __awaiter(this, void 0, void 0, function* () {
            const decrypted = yield this.decrypt(secret.encrypted);
            let secretDecrypted;
            if (secret.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP) {
                secretDecrypted = Object.assign(Object.assign({}, secret), { totp: JSON.parse(decrypted) });
            }
            else if (secret.kind === graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS) {
                const parsed = JSON.parse(decrypted);
                try {
                    loginCredentialsSchema_1.loginCredentialsSchema.parse(parsed);
                    secretDecrypted = Object.assign({ loginCredentials: parsed }, secret);
                }
                catch (err) {
                    secretDecrypted = Object.assign(Object.assign({}, secret), { loginCredentials: {
                            username: '',
                            password: '',
                            parseError: err,
                            label: parsed.label,
                            url: parsed.url
                        } });
                }
            }
            else {
                throw new Error('Unknown secret type');
            }
            return secretDecrypted;
        });
    }
    /**
     * fetches newly added/deleted/updated secrets from the backend and updates the device state
     */
    backendSync() {
        return __awaiter(this, void 0, void 0, function* () {
            const { data } = yield apolloClient_1.apolloClient.query({
                query: ExtensionDevice_codegen_1.SyncEncryptedSecretsDocument,
                fetchPolicy: 'no-cache'
            });
            if (data) {
                const deviceState = exports.device.state;
                if (data && deviceState) {
                    const backendRemovedSecrets = data.currentDevice.encryptedSecretsToSync.filter(({ deletedAt }) => deletedAt);
                    const newAndUpdatedSecrets = data.currentDevice.encryptedSecretsToSync.filter(({ deletedAt }) => !deletedAt);
                    const secretsBeforeSync = deviceState.secrets;
                    const unchangedSecrets = secretsBeforeSync.filter(({ id }) => !backendRemovedSecrets.find((removedSecret) => id === removedSecret.id) &&
                        !newAndUpdatedSecrets.find((updatedSecret) => id === updatedSecret.id));
                    deviceState.secrets = [...unchangedSecrets, ...newAndUpdatedSecrets];
                    yield this.save();
                    yield apolloClient_1.apolloClient.mutate({ mutation: ExtensionDevice_codegen_1.MarkAsSyncedDocument });
                    const actuallyRemovedOnThisDevice = backendRemovedSecrets.filter(({ id: removedId }) => {
                        return secretsBeforeSync.find(({ id }) => removedId === id);
                    });
                    console.log('~ actuallyRemovedOnThisDevice', actuallyRemovedOnThisDevice);
                    return {
                        removedSecrets: actuallyRemovedOnThisDevice.length,
                        newAndUpdatedSecrets: newAndUpdatedSecrets.length
                    };
                }
            }
        });
    }
    //TODO: type this
    findExistingSecret(secret) {
        return __awaiter(this, void 0, void 0, function* () {
            const existingSecretsOnHostname = yield this.getSecretsDecryptedByHostname(new URL(secret.url).hostname);
            return existingSecretsOnHostname.find((s) => {
                var _a;
                return (isLoginSecret(s) &&
                    s.loginCredentials.username === ((_a = secret.loginCredentials) === null || _a === void 0 ? void 0 : _a.username)) ||
                    (isTotpSecret(s) && s.totp === secret.totp);
            });
        });
    }
    /**
     * invokes the backend mutation and pushes the new secret to the bgState
     * @param secrets
     * @returns the added secret in base64
     */
    addSecrets(secrets) {
        return __awaiter(this, void 0, void 0, function* () {
            const encryptedSecrets = yield Promise.all(secrets.map((secret) => __awaiter(this, void 0, void 0, function* () {
                const stringToEncrypt = secret.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP
                    ? JSON.stringify(secret.totp)
                    : JSON.stringify(secret.loginCredentials);
                const encrypted = yield this.encrypt(stringToEncrypt);
                return {
                    encrypted,
                    kind: secret.kind
                };
            })));
            const { data, errors } = yield apolloClient_1.apolloClient.mutate({
                mutation: ExtensionDevice_codegen_1.AddEncryptedSecretsDocument,
                variables: {
                    secrets: encryptedSecrets
                }
            });
            if (errors) {
                console.log('errors', errors);
                throw new Error('Erorror adding secret');
            }
            if (!data) {
                throw new Error('failed to save secret');
            }
            const secretsAdded = data.me.addEncryptedSecrets;
            this.secrets.push(...secretsAdded);
            yield this.save();
            return secretsAdded;
        });
    }
    removeSecret(secretId) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            webextension_polyfill_1.default.storage.local.set({
                backgroundState: Object.assign(Object.assign({}, exports.device.state), { secrets: (_a = exports.device.state) === null || _a === void 0 ? void 0 : _a.secrets.filter((s) => s.id !== secretId) })
            });
            this.secrets = this.secrets.filter((s) => s.id !== secretId);
            this.save();
        });
    }
    destroy() {
        webextension_polyfill_1.default.storage.onChanged.removeListener(this.onStorageChange);
    }
}
exports.DeviceState = DeviceState;
class ExtensionDevice {
    constructor() {
        this.state = null;
        this.fireToken = null;
        this.lockedState = null;
        this.id = null;
    }
    startLockInterval(lockTime) {
        return __awaiter(this, void 0, void 0, function* () {
            yield exports.extensionDeviceTrpc.setLockInterval.mutate({ time: lockTime });
        });
    }
    clearLockInterval() {
        return __awaiter(this, void 0, void 0, function* () {
            yield exports.extensionDeviceTrpc.clearLockInterval.mutate();
        });
    }
    get platform() {
        return browserInfo.getOSName();
    }
    /**
     * runs on startup
     */
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            (0, exports.log)('Extension device initializing');
            this.id = yield this.getDeviceId();
            let storedState = null;
            const storage = yield webextension_polyfill_1.default.storage.local.get();
            if (storage.backgroundState) {
                storedState = storage.backgroundState;
                (0, exports.log)('device state init from storage', storedState);
            }
            else if (storage.lockedState) {
                this.lockedState = storage.lockedState;
                (0, exports.log)('device state locked', this.lockedState);
            }
            if (storedState) {
                this.state = new DeviceState(storedState);
                this.name = storedState.deviceName;
                this.state.save();
            }
            else {
                this.name = this.generateDeviceName();
                this.listenForUserLogin();
            }
            if (this.state) {
                this.startLockInterval(this.state.lockTime);
            }
            // const fireToken = await generateFireToken()
            const fireToken = 'aaaa';
            this.fireToken = fireToken;
            this.rerenderViews(); // for letting vault/popup know that the state has changed
        });
    }
    listenForUserLogin() {
        this.state = null;
        const onStorageChangeLogin = (changes, areaName) => {
            (0, exports.log)('storage change UL', changes, areaName);
            if (areaName === 'local' && changes.backgroundState) {
                this.state = new DeviceState(changes.backgroundState.newValue);
                webextension_polyfill_1.default.storage.onChanged.removeListener(onStorageChangeLogin);
            }
            else if (areaName === 'local' && changes.lockedState) {
                this.lockedState = changes.lockedState.newValue;
                webextension_polyfill_1.default.storage.onChanged.removeListener(onStorageChangeLogin);
            }
        };
        webextension_polyfill_1.default.storage.onChanged.addListener(onStorageChangeLogin);
    }
    rerenderViews() {
        if (exports.isRunningInBgPage === false) {
            rerenderViewInThisRuntime();
            // browser.runtime.sendMessage({
            //   action: BackgroundMessageType.rerenderViews
            // })
        }
    }
    generateDeviceName() {
        return `${browserInfo.getOSName()} ${browserInfo.getBrowserName()} extension`;
    }
    clearLocalStorage() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const deviceId = yield this.getDeviceId();
            (_a = this.state) === null || _a === void 0 ? void 0 : _a.destroy();
            yield webextension_polyfill_1.default.storage.local.clear();
            this.state = null;
            yield webextension_polyfill_1.default.storage.local.set({ deviceId: deviceId }); // restore deviceId so that we keep it even after logout
        });
    }
    /**
     * @returns a stored deviceId or a new UUID if the extension was just installed
     */
    getDeviceId() {
        return __awaiter(this, void 0, void 0, function* () {
            const storage = yield webextension_polyfill_1.default.storage.local.get('deviceId');
            if (!storage.deviceId) {
                const deviceId = crypto.randomUUID();
                yield webextension_polyfill_1.default.storage.local.set({ deviceId: deviceId });
                (0, exports.log)('Creating new deviceID', deviceId);
                return deviceId;
            }
            else {
                (0, exports.log)('Got deviceID', storage.deviceId);
                return storage.deviceId;
            }
        });
    }
    generateBackendSecret() {
        const lengthMultiplier = getRandomInt(1, 10);
        let secret = '';
        for (let i = 0; i < lengthMultiplier; i++) {
            secret += Math.random().toString(36).substr(2, 20);
        }
        return secret;
    }
    /**
     * @returns strings in base64
     */
    initLocalDeviceAuthSecret(masterEncryptionKey, salt) {
        return __awaiter(this, void 0, void 0, function* () {
            const authSecret = this.generateBackendSecret();
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const addDeviceSecretAb = yield window.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, masterEncryptionKey, generateEncryptionKey_1.enc.encode(authSecret));
            const addDeviceSecretEncrypted = (0, generateEncryptionKey_1.encryptedBuf_to_base64)(addDeviceSecretAb, iv, salt);
            return {
                addDeviceSecret: authSecret,
                addDeviceSecretEncrypted: addDeviceSecretEncrypted
            };
        });
    }
    lock() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.state) {
                throw new Error('no state to lock');
            }
            this.clearLockInterval();
            (0, exports.log)('locking device');
            const { email, userId, secrets, encryptionSalt, lockTime, syncTOTP, autofill, language, theme, authSecret, authSecretEncrypted } = this.state;
            this.lockedState = {
                email,
                userId,
                secrets,
                deviceName: this.name,
                encryptionSalt,
                authSecret,
                authSecretEncrypted,
                lockTime,
                syncTOTP,
                autofill,
                language,
                theme
            };
            yield webextension_polyfill_1.default.storage.local.set({
                lockedState: this.lockedState,
                backgroundState: null
            }); // restore deviceId so that we keep it even after logout
            this.state.destroy();
            this.state = null;
            this.rerenderViews();
        });
    }
    clearAndReload() {
        return __awaiter(this, void 0, void 0, function* () {
            yield (0, accessTokenExtension_1.removeToken)();
            yield exports.device.clearLocalStorage();
            exports.device.rerenderViews(); // TODO figure out if we can have logout without full extensions reload
            exports.device.listenForUserLogin();
            webextension_polyfill_1.default.runtime.reload();
        });
    }
    logout() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield apolloClient_1.apolloClient.mutate({
                    mutation: ExtensionDevice_codegen_1.LogoutDocument
                });
            }
            catch (err) {
                (0, Providers_1.toast)({
                    title: `There was an error logging out: ${err.message} \n., you will need to deauthorize the device manually in device management.`,
                    status: 'error',
                    onCloseComplete: () => {
                        this.clearAndReload();
                    }
                });
            }
            finally {
                yield this.clearAndReload();
            }
            yield this.clearAndReload();
        });
    }
    serializeSecrets(secrets, newPsw) {
        return __awaiter(this, void 0, void 0, function* () {
            const state = this.state;
            if (!state) {
                throw new Error('device not initialized');
            }
            return Promise.all(secrets.map((secret) => __awaiter(this, void 0, void 0, function* () {
                const { id, encrypted, kind } = secret;
                const decr = yield state.decrypt(encrypted);
                (0, exports.log)('decrypted secret', decr);
                yield state.setMasterEncryptionKey(newPsw);
                const enc = yield state.encrypt(decr);
                (0, exports.log)('encrypted secret', enc, state.masterEncryptionKey);
                return {
                    id,
                    encrypted: enc,
                    kind
                };
            })));
        });
    }
    syncSettings(config) {
        var _a;
        if (this.state) {
            this.state.autofill = config.autofill;
            this.state.lockTime = config.vaultLockTimeoutSeconds;
            this.state.syncTOTP = config.syncTOTP;
            this.state.language = config.language;
            this.state.theme = (_a = config.theme) !== null && _a !== void 0 ? _a : 'dark';
        }
    }
    save(deviceState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.state = new DeviceState(deviceState);
            this.state.save();
            this.rerenderViews();
        });
    }
}
(0, exports.log)('Extension device started');
exports.device = new ExtensionDevice();
exports.device.initialize();
// @ts-expect-error TODO fix types
window.extensionDevice = exports.device;
//# sourceMappingURL=ExtensionDevice.js.map