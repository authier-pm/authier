"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.autofill = exports.autofillEnabled = exports.getElementCoordinates = exports.autofillValueIntoInput = exports.autofillEventsDispatched = void 0;
const domMutationObserver_1 = require("./domMutationObserver");
const otplib_1 = require("otplib");
const debug_1 = __importDefault(require("debug"));
const generate_password_1 = require("generate-password");
const isElementInViewport_1 = require("./isElementInViewport");
const contentScript_1 = require("./contentScript");
const graphqlBaseTypes_1 = require("../../../shared/generated/graphqlBaseTypes");
const chakraRawTheme_1 = require("../../../shared/chakraRawTheme");
const react_toastify_1 = require("react-toastify");
require("react-toastify/dist/ReactToastify.css");
const lodash_1 = require("lodash");
const renderLoginCredOption_1 = require("./renderLoginCredOption");
const DOMEventsRecorder_1 = require("./DOMEventsRecorder");
const renderPasswordGenerator_1 = require("./renderPasswordGenerator");
const log = (0, debug_1.default)('au:autofill');
exports.autofillEventsDispatched = new Set();
function imitateKeyInput(el, keyChar) {
    if (el) {
        const keyboardEventInit = {
            bubbles: false,
            cancelable: false,
            composed: false,
            key: '',
            code: '',
            location: 0
        };
        const keyDown = new KeyboardEvent('keydown', keyboardEventInit);
        exports.autofillEventsDispatched.add(keyDown);
        el.dispatchEvent(keyDown);
        el.value = keyChar;
        const keyUp = new KeyboardEvent('keyup', keyboardEventInit);
        exports.autofillEventsDispatched.add(keyUp);
        el.dispatchEvent(keyUp);
        const change = new Event('change', { bubbles: true });
        exports.autofillEventsDispatched.add(change);
        el.dispatchEvent(change);
    }
    else {
        console.error('el is null');
    }
}
const autofillValueIntoInput = (element, value) => {
    log('autofillValueIntoInput:', value, element);
    if (element.childNodes.length > 0) {
        //we should again loop through the children of the element and find th right input
        //@ts-ignore
        imitateKeyInput(element.childNodes[0], value);
    }
    if ((0, isElementInViewport_1.isElementInViewport)(element) === false || (0, isElementInViewport_1.isHidden)(element)) {
        log('isHidden');
        return null; // could be dangerous to autofill into a hidden element-if the website got hacked, someone could be using this: https://websecurity.dev/password-managers/autofill/
    }
    element.style.backgroundColor = chakraRawTheme_1.authierColors.green[400];
    imitateKeyInput(element, value);
    return element;
};
exports.autofillValueIntoInput = autofillValueIntoInput;
const uselessInputTypes = [
    'hidden',
    'submit',
    'button',
    'reset',
    'button',
    'checkbox',
    'radio',
    'file',
    'color',
    'image',
    'range',
    'search',
    'time'
];
const filterUselessInputs = (documentBody) => {
    const inputEls = documentBody.querySelectorAll('input');
    const inputElsArray = Array.from(inputEls).filter((el) => uselessInputTypes.includes(el.type) === false &&
        el.offsetWidth > 0 &&
        el.offsetHeight > 0);
    return inputElsArray;
};
const getElementCoordinates = (el) => {
    const rect = el.getBoundingClientRect();
    return {
        x: rect.x,
        y: rect.y
    };
};
exports.getElementCoordinates = getElementCoordinates;
exports.autofillEnabled = false;
let onInputAddedHandler;
const autofill = (initState, autofillEnabled = false) => {
    const { secretsForHost, webInputs } = initState;
    if (autofillEnabled === true) {
        log('enabled is true, returning');
        return () => { };
    }
    log('init autofill', initState);
    autofillEnabled = true;
    const namePassSecret = secretsForHost.loginCredentials[0];
    const totpSecret = secretsForHost.totpSecrets[0];
    //NOTE: scan all inputs
    const scanKnownWebInputsAndFillWhenFound = (body) => __awaiter(void 0, void 0, void 0, function* () {
        var _a;
        /**
         * filter text, email, password, tel
         */
        const usefulInputs = filterUselessInputs(document.body);
        //Distinguish between register and login from by the number of inputs
        //Then Distinguish between phased and not phased
        //Register screen
        //After certain condition is met, we can assume this is register page
        log('usefull', usefulInputs);
        if (usefulInputs.length > 2) {
            for (let index = 0; index < usefulInputs.length - 1; index++) {
                const input = usefulInputs[index];
                if (input.type === 'password' &&
                    usefulInputs[index + 1].type === 'password') {
                    const password = (0, generate_password_1.generate)({
                        length: 10,
                        numbers: true,
                        uppercase: true,
                        symbols: true,
                        strict: true
                    });
                    (0, exports.autofillValueIntoInput)(usefulInputs[index], password);
                    (0, exports.autofillValueIntoInput)(usefulInputs[index + 1], password);
                    break;
                }
                else if (input.getAttribute('autocomplete') === 'new-password') {
                    (0, renderPasswordGenerator_1.renderPasswordGenerator)({ input: input });
                    const password = (0, generate_password_1.generate)({
                        length: 10,
                        numbers: true,
                        uppercase: true,
                        symbols: true,
                        strict: true
                    });
                    (0, exports.autofillValueIntoInput)(input, password);
                    break;
                }
            }
        }
        //Fill known inputs
        const filledElements = webInputs
            .filter(({ url }) => {
            console.log('~ url', url);
            //FIX: THIS
            const host = new URL(url).host;
            const matches = location.href.includes(host);
            return matches;
        })
            .map((webInputGql) => {
            let inputEl = document.body.querySelector(webInputGql.domPath);
            const rect = inputEl.getBoundingClientRect();
            log('cords', rect.x, rect.y);
            //NOTE: We found element by DOM path
            if (inputEl) {
                log('autofilled by domPath');
                if (webInputGql.kind === graphqlBaseTypes_1.WebInputType.PASSWORD && namePassSecret) {
                    return (0, exports.autofillValueIntoInput)(inputEl, namePassSecret.loginCredentials.password);
                }
                else if ([
                    graphqlBaseTypes_1.WebInputType.EMAIL,
                    graphqlBaseTypes_1.WebInputType.USERNAME,
                    graphqlBaseTypes_1.WebInputType.USERNAME_OR_EMAIL
                ].includes(webInputGql.kind) &&
                    namePassSecret) {
                    return (0, exports.autofillValueIntoInput)(inputEl, namePassSecret.loginCredentials.username);
                }
                else if (webInputGql.kind === graphqlBaseTypes_1.WebInputType.TOTP && totpSecret) {
                    return (0, exports.autofillValueIntoInput)(inputEl, 
                    //@sleaper TODO: fix this
                    otplib_1.authenticator.generate(totpSecret.totp.secret));
                }
                //NOTE: We did not find element by DOM path, so find it by input coords
            }
            else if (webInputGql.domCoordinates.x === rect.x &&
                webInputGql.domCoordinates.y === rect.y) {
                inputEl = document.elementFromPoint(rect.x, rect.y);
                log('el', inputEl);
            }
        })
            .filter((el) => !!el);
        //NOTE: Guess web inputs, if we have credentials without DOM PATHS
        if (webInputs.length === 0 &&
            secretsForHost.loginCredentials.length > 0
        // filledElements.length === 0
        ) {
            const autofillResult = searchInputsAndAutofill(document.body);
            if (autofillResult) {
                yield contentScript_1.trpc.saveCapturedInputEvents.mutate({
                    inputEvents: contentScript_1.domRecorder.toJSON(),
                    url: document.documentURI
                });
            }
            log('autofillResult', autofillResult);
        }
        if (onInputAddedHandler) {
            domMutationObserver_1.bodyInputChangeEmitter.off('inputAdded', onInputAddedHandler);
        }
        //TODO: this does not work right
        //Catch new inputs
        onInputAddedHandler = (0, lodash_1.debounce)((input) => {
            const passwordGenOptions = { length: 12, numbers: true, symbols: true }; // TODO get from user's options
            // For one input on page
            if (input.autocomplete === 'new-password') {
                (0, exports.autofillValueIntoInput)(input, (0, generate_password_1.generate)(passwordGenOptions));
            }
            else {
                // More inputs on page
                if (input.type === 'password') {
                    const passwordInputsOnPage = document.querySelectorAll('input[type="password"]');
                    if (passwordInputsOnPage.length === 2 &&
                        passwordInputsOnPage[0].autocomplete !== 'current-password' &&
                        passwordInputsOnPage[1].autocomplete !== 'current-password') {
                        const newPassword = (0, generate_password_1.generate)(passwordGenOptions);
                        // must be some kind of signup page
                        (0, exports.autofillValueIntoInput)(passwordInputsOnPage[0], newPassword);
                        (0, exports.autofillValueIntoInput)(passwordInputsOnPage[1], newPassword);
                    }
                }
            }
        }, 500, {
            trailing: true
        });
        //If input shows on loaded page
        domMutationObserver_1.bodyInputChangeEmitter.on('inputAdded', onInputAddedHandler);
        if (!namePassSecret && !totpSecret) {
            log('no secrets for host');
            return () => { };
        }
        if (filledElements.length === 2) {
            const form = (_a = filledElements[0]) === null || _a === void 0 ? void 0 : _a.form;
            if (form) {
                // TODO try to submit the form
                // filledElements[0]?.form?.dispatchEvent(
                //   new Event('submit', {
                //     bubbles: true,
                //     cancelable: true
                //   })
                // )
                const clickEvent = new MouseEvent('click', {
                    view: window,
                    bubbles: true,
                    cancelable: true
                });
                if (form.submit instanceof HTMLElement) {
                    // @ts-expect-error TODO
                    form.submit.dispatchEvent(clickEvent);
                }
                // TODO show notification
                react_toastify_1.toast.success('Submitted autofilled form');
            }
        }
        function searchInputsAndAutofill(documentBody) {
            const newWebInputs = [];
            const inputElsArray = filterUselessInputs(documentBody);
            for (let index = 0; index < inputElsArray.length; index++) {
                const input = inputElsArray[index];
                if (input.type === 'password') {
                    //Save password input, if we have more credentials with no DOM PATH
                    if (webInputs.length === 0 &&
                        secretsForHost.loginCredentials.length > 1) {
                        newWebInputs.push({
                            createdAt: new Date().toString(),
                            domPath: (0, DOMEventsRecorder_1.getSelectorForElement)(input).css,
                            host: location.host,
                            url: location.href,
                            kind: graphqlBaseTypes_1.WebInputType.PASSWORD,
                            domCoordinates: (0, exports.getElementCoordinates)(input)
                        });
                        contentScript_1.domRecorder.addInputEvent({
                            element: input,
                            eventType: 'input',
                            kind: graphqlBaseTypes_1.WebInputType.PASSWORD,
                            inputted: input.value
                        });
                    }
                    //Search for a username input
                    for (let j = index - 1; j >= 0; j--) {
                        if (inputElsArray[j].type !== 'hidden') {
                            log('found username input', inputElsArray[j]);
                            //Save username input, if we have more credentials with no DOM PATH then break from loop and let user choose which psw to use
                            if (webInputs.length === 0 &&
                                secretsForHost.loginCredentials.length > 1) {
                                newWebInputs.push({
                                    createdAt: new Date().toString(),
                                    domPath: (0, DOMEventsRecorder_1.getSelectorForElement)(inputElsArray[j]).css,
                                    host: location.host,
                                    url: location.href,
                                    kind: graphqlBaseTypes_1.WebInputType.USERNAME,
                                    domCoordinates: (0, exports.getElementCoordinates)(input)
                                });
                                contentScript_1.domRecorder.addInputEvent({
                                    element: inputElsArray[j],
                                    eventType: 'input',
                                    kind: graphqlBaseTypes_1.WebInputType.USERNAME_OR_EMAIL,
                                    inputted: inputElsArray[j].value
                                });
                                break;
                            }
                            const autofilledElUsername = (0, exports.autofillValueIntoInput)(inputElsArray[j], secretsForHost.loginCredentials[0].loginCredentials.username);
                            contentScript_1.domRecorder.addInputEvent({
                                element: inputElsArray[j],
                                eventType: 'input',
                                inputted: secretsForHost.loginCredentials[0].loginCredentials.username,
                                kind: graphqlBaseTypes_1.WebInputType.USERNAME
                            });
                            const autofilledElPassword = (0, exports.autofillValueIntoInput)(input, secretsForHost.loginCredentials[0].loginCredentials.password);
                            contentScript_1.domRecorder.addInputEvent({
                                element: input,
                                eventType: 'input',
                                inputted: secretsForHost.loginCredentials[0].loginCredentials.password,
                                kind: graphqlBaseTypes_1.WebInputType.PASSWORD
                            });
                            return !!autofilledElUsername || !!autofilledElPassword;
                        }
                    }
                    //Let user choose which credential to use
                    if (webInputs.length === 0 &&
                        secretsForHost.loginCredentials.length > 1) {
                        log('choose credential', contentScript_1.domRecorder.toJSON());
                        (0, renderLoginCredOption_1.renderLoginCredOption)({
                            loginCredentials: secretsForHost.loginCredentials,
                            webInputs: newWebInputs
                        });
                        return true;
                    }
                    return false;
                }
            }
            return false;
        }
    });
    const scanGlobalDocument = () => scanKnownWebInputsAndFillWhenFound(document.body);
    setTimeout(scanGlobalDocument, 150); // let's wait a bit for the page to load
    return () => {
        autofillEnabled = false;
        domMutationObserver_1.bodyInputChangeEmitter.off('inputAdded', scanGlobalDocument);
    };
};
exports.autofill = autofill;
//# sourceMappingURL=autofill.js.map