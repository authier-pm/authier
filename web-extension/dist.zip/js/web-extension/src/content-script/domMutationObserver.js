"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.domMutationObserver = exports.bodyInputChangeEmitter = void 0;
const mitt_1 = __importDefault(require("mitt"));
exports.bodyInputChangeEmitter = (0, mitt_1.default)();
const inputDebounceMap = new Map();
const DEBOUNCE_TIME = 180; // we want to debounce the emitted events- we don't want to emit events for every DOM mutation if there are many in quick succession
function emitDebounced(eventName, input) {
    if (inputDebounceMap.has(input)) {
        clearTimeout(inputDebounceMap.get(input));
    }
    const timer = setTimeout(() => {
        exports.bodyInputChangeEmitter.emit(eventName, input);
        inputDebounceMap.delete(input);
    }, DEBOUNCE_TIME);
    inputDebounceMap.set(input, timer);
}
/**
 * inspired from https://usefulangle.com/post/357/javascript-detect-element-removed-from-dom
 */
exports.domMutationObserver = new MutationObserver(function (mutationsList) {
    mutationsList.forEach(function (mutation) {
        mutation.removedNodes.forEach(function (removedNode) {
            if (removedNode.nodeName === 'INPUT') {
                emitDebounced('inputRemoved', removedNode);
            }
        });
        mutation.addedNodes.forEach(function (addedNode) {
            const node = addedNode;
            if (node.nodeName === 'INPUT') {
                emitDebounced('inputAdded', node);
            }
            else if (node['querySelectorAll']) {
                node.querySelectorAll('input').forEach((input) => {
                    emitDebounced('inputAdded', input);
                });
                const childIframe = node.querySelector('input');
                if (childIframe) {
                    emitDebounced('inputAdded', node);
                }
            }
        });
    });
});
exports.domMutationObserver.observe(document.body, {
    subtree: true,
    childList: true
});
//# sourceMappingURL=domMutationObserver.js.map