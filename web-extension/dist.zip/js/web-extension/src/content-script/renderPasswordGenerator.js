"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderPasswordGenerator = exports.generatorDiv = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
// @ts-nocheck
const preact_1 = require("preact");
const PromptPasswordGenerator_1 = require("./components/PromptPasswordGenerator");
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
function renderPasswordGenerator({ input }) {
    console.log('PEPA');
    exports.generatorDiv = document.createElement('div');
    (0, preact_1.render)((0, jsx_runtime_1.jsx)(PromptPasswordGenerator_1.PromptPasswordGenerator, { input: input }), exports.generatorDiv);
    document.body.appendChild(exports.generatorDiv);
}
exports.renderPasswordGenerator = renderPasswordGenerator;
//# sourceMappingURL=renderPasswordGenerator.js.map