"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateQuerySelectorForOrphanedElement = void 0;
const generateQuerySelectorForOrphanedElement = (el) => {
    if (el.tagName.toLowerCase() == 'html')
        return 'HTML';
    let str = el.tagName;
    str += el.id != '' ? '#' + el.id : '';
    if (el.className) {
        const classes = el.className.split(/\s/);
        for (let i = 0; i < classes.length; i++) {
            str += '.' + classes[i];
        }
    }
    return str;
};
exports.generateQuerySelectorForOrphanedElement = generateQuerySelectorForOrphanedElement;
//# sourceMappingURL=generateQuerySelectorForOrphanedElement.js.map