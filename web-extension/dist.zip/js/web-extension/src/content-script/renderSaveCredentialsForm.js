"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderSaveCredentialsForm = exports.loginPrompt = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
// @ts-nocheck
const PromptPassword_1 = require("./components/PromptPassword");
const preact_1 = require("preact");
const contentScript_1 = require("./contentScript");
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
function renderSaveCredentialsForm(username, password, passwordLimit, passwordCount) {
    return __awaiter(this, void 0, void 0, function* () {
        const inputEvents = yield contentScript_1.trpc.getCapturedInputEvents.query();
        console.log('passwordLimit', passwordLimit);
        console.log('passwordCount', passwordCount);
        exports.loginPrompt = document.createElement('div');
        (0, preact_1.render)((0, jsx_runtime_1.jsx)(PromptPassword_1.PromptPassword, { username: username, password: password, inputEvents: inputEvents, passwordLimit: passwordLimit, passwordCount: passwordCount }), exports.loginPrompt);
        document.body.appendChild(exports.loginPrompt);
        yield contentScript_1.trpc.saveLoginCredentialsModalShown.mutate({ username, password });
    });
}
exports.renderSaveCredentialsForm = renderSaveCredentialsForm;
//# sourceMappingURL=renderSaveCredentialsForm.js.map