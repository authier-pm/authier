"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Toast = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
// @ts-nocheck
const preact_1 = require("preact");
const hooks_1 = require("preact/hooks");
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
require("./Toast.css");
const Toast = ({ header, text }) => {
    (0, hooks_1.useEffect)(() => {
        const x = document.getElementById('toast');
        x.className = 'show';
        // setTimeout(function () {
        //   x.className = x.className.replace('show', '')
        // }, 5000)
    }, []);
    return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ id: "toast" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ id: "img" }, { children: header })), (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "desc" }, { children: text }))] })));
};
exports.Toast = Toast;
//# sourceMappingURL=Toast.js.map