"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrompItemPopup = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
// @ts-nocheck
const preact_1 = require("preact");
const hooks_1 = require("preact/hooks");
const renderItemPopup_1 = require("../renderItemPopup");
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
const PrompItemPopup = ({ inputEvents }) => {
    const [username, setUsername] = (0, hooks_1.useState)('');
    const [password, setPassword] = (0, hooks_1.useState)('');
    const addCredential = (openInVault = false) => __awaiter(void 0, void 0, void 0, function* () {
        const loginCredentials = {
            username,
            password,
            capturedInputEvents: inputEvents.capturedInputEvents,
            openInVault,
            url: inputEvents.inputsUrl ? inputEvents.inputsUrl : ''
        };
        //fill inputs
        inputEvents.capturedInputEvents.forEach((element) => {
            const input = document.body.querySelector(element.element);
            if (input.type === 'password') {
                input.value = password;
            }
            else {
                input.value = username;
            }
        });
        return yield trpc.addLoginCredentials.mutate(loginCredentials);
    });
    const onInput = (e) => {
        if (e.target.type === 'text') {
            setUsername(e.target.value);
        }
        else {
            setPassword(e.target.value);
        }
    };
    return ((0, jsx_runtime_1.jsx)("div", Object.assign({ style: {
            zIndex: '2147483647',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'baseline',
            fontFamily: 'sans-serif !important',
            position: 'fixed',
            top: '50%',
            left: '50%',
            backgroundColor: '#64cabd'
        } }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ style: { display: 'flex', flexDirection: 'column' } }, { children: [(0, jsx_runtime_1.jsx)("span", Object.assign({ style: { fontWeight: '13px', color: 'black' } }, { children: "Username: " })), (0, jsx_runtime_1.jsx)("input", { placeholder: "username", type: "text", value: username, onInput: onInput }), (0, jsx_runtime_1.jsx)("span", Object.assign({ style: { fontWeight: '13px', color: 'black' } }, { children: "Password: " })), (0, jsx_runtime_1.jsx)("input", { type: "password", placeholder: "password", value: password, onInput: onInput }), (0, jsx_runtime_1.jsx)("button", Object.assign({ onClick: () => {
                        addCredential();
                        renderItemPopup_1.popupDiv === null || renderItemPopup_1.popupDiv === void 0 ? void 0 : renderItemPopup_1.popupDiv.remove();
                    } }, { children: "Save" }))] })) })));
};
exports.PrompItemPopup = PrompItemPopup;
//# sourceMappingURL=PromptItemPopup.js.map