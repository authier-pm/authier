"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptPasswordGenerator = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
// @ts-nocheck
const preact_1 = require("preact");
const hooks_1 = require("preact/hooks");
const generate_password_1 = require("generate-password");
//import { css } from '@emotion/css'
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
require("./Option.css");
const renderPasswordGenerator_1 = require("../renderPasswordGenerator");
const autofill_1 = require("../autofill");
const PromptPasswordGenerator = ({ input }) => {
    if (!input) {
        console.log('No web inputs in PromptPasswordOption');
        return null;
    }
    const [pos, setPos] = (0, hooks_1.useState)(input.getBoundingClientRect());
    const [showDropdown, setShowDropdown] = (0, hooks_1.useState)(false);
    const [password, setPassword] = (0, hooks_1.useState)((0, generate_password_1.generate)({
        length: 10,
        numbers: true,
        uppercase: true,
        symbols: true,
        strict: true
    }));
    let resizeTimer;
    window.onresize = function () {
        if (renderPasswordGenerator_1.generatorDiv) {
            renderPasswordGenerator_1.generatorDiv.remove();
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function () {
                setPos(input.getBoundingClientRect());
                document.body.appendChild(renderPasswordGenerator_1.generatorDiv);
            }, 100);
        }
    };
    if (!pos) {
        console.log('No pos in PromptPasswordOption');
        return null;
    }
    return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ onMouseEnter: () => setShowDropdown(true), onMouseLeave: () => setShowDropdown(false), style: {
            zIndex: '2147483647',
            justifyContent: 'center',
            alignItems: 'baseline',
            fontFamily: 'sans-serif !important',
            position: 'fixed',
            top: pos.top - 10 + 'px',
            left: pos.left + pos.width + 'px',
            right: pos.right + 'px',
            bottom: pos.bottom + 'px'
        } }, { children: [(0, jsx_runtime_1.jsx)("span", { style: {
                    height: '25px',
                    width: '25px',
                    backgroundColor: '#3e8e41',
                    display: 'block'
                } }), (0, jsx_runtime_1.jsxs)("div", Object.assign({ style: {
                    display: showDropdown ? 'flex' : 'none',
                    justifyContent: 'space-between',
                    flexDirection: 'row',
                    position: 'absolute',
                    backgroundColor: 'white',
                    minWidth: '160px',
                    zIndex: '1',
                    boxShadow: '0px 8px 16px 0px rgba(0,0,0,0.2)'
                    /*background: url('./icon-16.png');*/
                } }, { children: [(0, jsx_runtime_1.jsx)("a", Object.assign({ style: {
                            textDecoration: 'none',
                            color: 'black',
                            padding: '12px 16px'
                        } }, { children: password })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ style: {
                            display: 'flex',
                            flexDirection: 'column'
                        } }, { children: [(0, jsx_runtime_1.jsx)("button", Object.assign({ onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                    setPassword((0, generate_password_1.generate)({
                                        length: 10,
                                        numbers: true,
                                        uppercase: true,
                                        symbols: true,
                                        strict: true
                                    }));
                                }) }, { children: "Next" })), (0, jsx_runtime_1.jsx)("button", Object.assign({ onClick: () => {
                                    (0, autofill_1.autofillValueIntoInput)(input, password);
                                } }, { children: "Use" }))] }))] }))] })));
};
exports.PromptPasswordGenerator = PromptPasswordGenerator;
//# sourceMappingURL=PromptPasswordGenerator.js.map