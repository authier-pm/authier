"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptPasswordOption = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
// @ts-nocheck
const preact_1 = require("preact");
const hooks_1 = require("preact/hooks");
const renderLoginCredOption_1 = require("../renderLoginCredOption");
//import { css } from '@emotion/css'
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
require("./Option.css");
const debug_1 = __importDefault(require("debug"));
const log = (0, debug_1.default)('au:PromptPasswordOption');
const autofill_1 = require("../autofill");
const PromptPasswordOption = (props) => {
    let { loginCredentials, webInputs } = props;
    log('GOT in option prompt', { webInputs, loginCredentials });
    if (webInputs.length === 0) {
        log('No web inputs in PromptPasswordOption');
        return null;
    }
    if (!el) {
        el = document.elementFromPoint(webInputs[0].domCoordinates.x, webInputs[0].domCoordinates.y);
        log('el', el);
    }
    const [pos, setPos] = (0, hooks_1.useState)(el === null || el === void 0 ? void 0 : el.getBoundingClientRect());
    let resizeTimer;
    window.onresize = function () {
        if (renderLoginCredOption_1.promptOption) {
            renderLoginCredOption_1.promptOption.remove();
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function () {
                setPos(el === null || el === void 0 ? void 0 : el.getBoundingClientRect());
                document.body.appendChild(renderLoginCredOption_1.promptOption);
            }, 100);
        }
    };
    if (!pos) {
        log('No pos in PromptPasswordOption');
        return null;
    }
    return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ className: "dropdown", style: {
            zIndex: '2147483647',
            justifyContent: 'center',
            alignItems: 'baseline',
            fontFamily: 'sans-serif !important',
            position: 'fixed',
            top: pos.top - 10 + 'px',
            left: pos.left + pos.width + 'px',
            right: pos.right + 'px',
            bottom: pos.bottom + 'px'
        } }, { children: [(0, jsx_runtime_1.jsx)("span", { className: "iconAuthier" }), (0, jsx_runtime_1.jsx)("div", Object.assign({ className: "dropdown-content" }, { children: loginCredentials.map((el) => {
                    return ((0, jsx_runtime_1.jsx)("a", Object.assign({ onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                            (0, autofill_1.autofill)({
                                secretsForHost: { loginCredentials: [el], totpSecrets: [] },
                                autofillEnabled: true,
                                extensionDeviceReady: true,
                                saveLoginModalsState: undefined,
                                webInputs: webInputs
                            }, false);
                        }) }, { children: el.loginCredentials.username })));
                }) }))] })));
};
exports.PromptPasswordOption = PromptPasswordOption;
//# sourceMappingURL=PromptPasswordOption.js.map