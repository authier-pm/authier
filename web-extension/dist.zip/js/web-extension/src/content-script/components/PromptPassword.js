"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptPassword = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const preact_1 = require("preact");
const chakraRawTheme_1 = require("../../../../shared/chakraRawTheme");
const renderSaveCredentialsForm_1 = require("../renderSaveCredentialsForm");
const contentScript_1 = require("../contentScript");
//import { css } from '@emotion/css'
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
const escapeHtml = (unsafe) => {
    return unsafe
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
};
const PromptPassword = ({ username, password, inputEvents, passwordLimit, passwordCount }) => {
    const h3Style = {
        margin: 0,
        fontFamily: 'sans-serif !important',
        fontSize: '14px',
        fontWeight: 'bold',
        color: '#000'
    };
    const spanStyle = {
        fontSize: '13px',
        color: '#000'
    };
    const buttonStyle = (bgColor) => {
        return {
            backgroundColor: bgColor,
            margin: '4px',
            borderRadius: '8px',
            fontSize: '13px',
            fontWeight: '500',
            height: '40px',
            outline: 'none',
            padding: '10px 16px',
            borderDecoration: 'none'
        };
    };
    const addCredential = (openInVault = false) => __awaiter(void 0, void 0, void 0, function* () {
        if (passwordCount >= passwordLimit) {
            alert('You have reached the maximum number of passwords allowed in your vault. Please delete some passwords to add more.');
            return yield contentScript_1.trpc.hideLoginCredentialsModal.mutate();
        }
        const loginCredential = {
            capturedInputEvents: inputEvents.capturedInputEvents,
            openInVault,
            username,
            password
        };
        yield contentScript_1.trpc.addLoginCredentials.mutate(loginCredential);
    });
    const removeCredential = () => __awaiter(void 0, void 0, void 0, function* () {
        renderSaveCredentialsForm_1.loginPrompt === null || renderSaveCredentialsForm_1.loginPrompt === void 0 ? void 0 : renderSaveCredentialsForm_1.loginPrompt.remove();
        yield contentScript_1.trpc.hideLoginCredentialsModal.mutate();
    });
    let passwordShown = false;
    console.log('nanojsx');
    return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ style: {
            zIndex: '2147483647',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'baseline',
            fontFamily: 'sans-serif !important',
            width: '100%',
            position: 'fixed',
            padding: '8px',
            backgroundColor: '#64cabd',
            top: '0px'
        } }, { children: [(0, jsx_runtime_1.jsx)("span", Object.assign({ style: { fontWeight: '13px', color: 'black' } }, { children: "Username: " })), (0, jsx_runtime_1.jsx)("h3", Object.assign({ style: h3Style }, { children: username })), (0, jsx_runtime_1.jsx)("span", Object.assign({ style: spanStyle }, { children: "Password: " })), ' ', (0, jsx_runtime_1.jsx)("h3", Object.assign({ style: h3Style, id: "__AUTHIER__pswdDisplay" }, { children: password.replaceAll(/./g, '*') })), (0, jsx_runtime_1.jsx)("button", Object.assign({ style: buttonStyle(chakraRawTheme_1.authierColors.teal[100]), onClick: () => {
                    const passwordDisplayEl = document.querySelector('#__AUTHIER__pswdDisplay');
                    if (passwordShown) {
                        passwordDisplayEl.innerHTML = password.replaceAll(/./g, '*');
                        passwordShown = false;
                    }
                    else {
                        passwordDisplayEl.innerHTML = escapeHtml(password);
                        passwordShown = true;
                    }
                } }, { children: "\uD83D\uDC41\uFE0F" })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ style: { margin: '0 15px' } }, { children: [(0, jsx_runtime_1.jsx)("button", Object.assign({ style: buttonStyle('#57c7e9'), onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                            yield addCredential();
                            renderSaveCredentialsForm_1.loginPrompt === null || renderSaveCredentialsForm_1.loginPrompt === void 0 ? void 0 : renderSaveCredentialsForm_1.loginPrompt.remove();
                        }) }, { children: "save" })), (0, jsx_runtime_1.jsx)("button", Object.assign({ style: buttonStyle('#1EAE9B'), onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                            yield addCredential(true);
                            renderSaveCredentialsForm_1.loginPrompt === null || renderSaveCredentialsForm_1.loginPrompt === void 0 ? void 0 : renderSaveCredentialsForm_1.loginPrompt.remove();
                        }) }, { children: "save & edit" })), (0, jsx_runtime_1.jsx)("button", Object.assign({ style: buttonStyle('#072C27'), onClick: () => {
                            removeCredential();
                        } }, { children: "close" }))] }))] })));
};
exports.PromptPassword = PromptPassword;
//# sourceMappingURL=PromptPassword.js.map