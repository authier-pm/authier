"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.showSavePromptIfAppropriate = exports.renderer = exports.recordInputs = void 0;
const contentScript_1 = require("./contentScript");
const renderLoginCredOption_1 = require("./renderLoginCredOption");
const renderSaveCredentialsForm_1 = require("./renderSaveCredentialsForm");
const debug_1 = __importDefault(require("debug"));
const renderItemPopup_1 = require("./renderItemPopup");
const renderToast_1 = require("./renderToast");
const log = (0, debug_1.default)('au:contentScript:renderer');
localStorage.debug = localStorage.debug || 'au:*'; // enable all debug messages, TODO remove this for production
let clickCount = 0;
let recording = false;
const hideToast = () => {
    const x = document.getElementById('toast');
    setTimeout(function () {
        x === null || x === void 0 ? void 0 : x.remove();
    }, 5000);
};
function recordInputs(e) {
    if (e &&
        e.shiftKey &&
        e.ctrlKey &&
        (e.key === 'q' || e.key === 'Q') &&
        !recording) {
        recording = true;
        (0, renderToast_1.renderToast)({
            header: 'Recording started',
            text: 'Press Ctrl + shift + Q to stop'
        });
        document.addEventListener('click', clicked);
    }
    else if (e &&
        e.shiftKey &&
        e.ctrlKey &&
        (e.key === 'q' || e.key === 'Q') &&
        recording) {
        contentScript_1.domRecorder.clearCapturedEvents();
        document.removeEventListener('click', clicked);
        renderToast_1.recordDiv === null || renderToast_1.recordDiv === void 0 ? void 0 : renderToast_1.recordDiv.remove();
        clickCount = 0;
        recording = false;
        hideToast();
    }
}
exports.recordInputs = recordInputs;
function clicked(e) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log(e);
        //@ts-expect-error TODO
        if (e.target.type === 'password' || e.target.type === 'text') {
            contentScript_1.domRecorder.addInputEvent({
                element: e.target,
                eventType: 'input',
                kind: (0, contentScript_1.getWebInputKind)(e.target)
            });
            clickCount = clickCount + 1;
        }
        if (clickCount === 2) {
            yield contentScript_1.trpc.saveCapturedInputEvents.mutate({
                inputEvents: contentScript_1.domRecorder.toJSON(),
                url: document.documentURI
            });
            renderToast_1.recordDiv === null || renderToast_1.recordDiv === void 0 ? void 0 : renderToast_1.recordDiv.remove();
            recording = false;
            clickCount = 0;
            document.removeEventListener('click', clicked);
            //TODO: We can use inputs on page???
            (0, renderItemPopup_1.renderItemPopup)();
        }
    });
}
const renderer = (stateInit) => {
    const { saveLoginModalsState, secretsForHost, webInputs, passwordLimit, passwordCount } = stateInit;
    if (secretsForHost.loginCredentials.length > 1 && webInputs.length > 0) {
        (0, renderLoginCredOption_1.renderLoginCredOption)({
            loginCredentials: secretsForHost.loginCredentials,
            webInputs
        });
        return;
    }
    // Render save credential modal after page-rerender
    if (saveLoginModalsState &&
        saveLoginModalsState.username &&
        saveLoginModalsState.password) {
        log('rendering save credentials form');
        (0, renderSaveCredentialsForm_1.renderSaveCredentialsForm)(saveLoginModalsState.username, saveLoginModalsState.password, passwordLimit, passwordCount);
        return; // the modal is already displayed
    }
};
exports.renderer = renderer;
const showSavePromptIfAppropriate = (secretsForHost, passwordLimit, passwordCount) => __awaiter(void 0, void 0, void 0, function* () {
    log('showSavePromptIfAppropriate', contentScript_1.domRecorder.toJSON(), document.documentURI);
    if (renderSaveCredentialsForm_1.loginPrompt) {
        return;
    }
    yield contentScript_1.trpc.saveCapturedInputEvents.mutate({
        inputEvents: contentScript_1.domRecorder.toJSON(),
        url: document.documentURI
    });
    const username = contentScript_1.domRecorder.getUsername();
    const password = contentScript_1.domRecorder.getPassword();
    const existingCredentialWithSamePassword = secretsForHost === null || secretsForHost === void 0 ? void 0 : secretsForHost.loginCredentials.find(({ loginCredentials }) => loginCredentials.password === password);
    if (password && !existingCredentialWithSamePassword) {
        if (username) {
            (0, renderSaveCredentialsForm_1.renderSaveCredentialsForm)(username, password, passwordLimit, passwordCount);
        }
        else {
            //@ts-expect-error
            const fallbackUsernames = yield contentScript_1.trpc.getFallbackUsernames.query();
            log('fallbackUsernames', fallbackUsernames);
            // const fallbackUsernames: string[] = await browser.runtime.sendMessage({
            //   action: BackgroundMessageType.getFallbackUsernames
            // })
            (0, renderSaveCredentialsForm_1.renderSaveCredentialsForm)(fallbackUsernames[0], password, passwordLimit, passwordCount);
        }
    }
});
exports.showSavePromptIfAppropriate = showSavePromptIfAppropriate;
//# sourceMappingURL=renderer.js.map