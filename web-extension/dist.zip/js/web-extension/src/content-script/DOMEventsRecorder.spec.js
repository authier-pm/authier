"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const graphqlBaseTypes_1 = require("../../../shared/generated/graphqlBaseTypes");
const DOMEventsRecorder_1 = require("./DOMEventsRecorder");
describe('DOMEventsRecorder', () => {
    it.todo('should only add event once per input', () => __awaiter(void 0, void 0, void 0, function* () {
        // multiple events from single input must remove the previous ones stored in the recorder
    }));
    describe('getUsername', () => {
        it('should mark the input previous to the password kind as username', () => __awaiter(void 0, void 0, void 0, function* () {
            const recorder = new DOMEventsRecorder_1.DOMEventsRecorder();
            recorder.addInputEvent({
                element: document.createElement('input'),
                eventType: 'input',
                kind: null
            });
            recorder.addInputEvent({
                element: document.createElement('input'),
                eventType: 'input',
                kind: graphqlBaseTypes_1.WebInputType.PASSWORD
            });
            expect(recorder.toJSON()).toMatchInlineSnapshot(`
        [
          {
            "cssSelector": "INPUT",
            "domOrdinal": 0,
            "inputted": undefined,
            "kind": "USERNAME_OR_EMAIL",
            "type": "input",
          },
          {
            "cssSelector": "INPUT",
            "domOrdinal": 0,
            "inputted": undefined,
            "kind": "PASSWORD",
            "type": "input",
          },
        ]
      `);
        }));
        it.todo('should use email input as username if there is one');
        it.todo('should use username input as username if there are more than one email inputs');
        it.todo('should grep inner text of the HTML page body and return the email if there is exactly one on the page');
    });
});
describe('getSelectorForElement', () => {
    it.todo('should return a selector based on autocomplete attribute if it is present');
});
//# sourceMappingURL=DOMEventsRecorder.spec.js.map