"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderLoginCredOption = exports.promptOption = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const preact_1 = require("preact");
const PromptPasswordOption_1 = require("./components/PromptPasswordOption");
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const nano = preact_1.h;
function renderLoginCredOption(props) {
    exports.promptOption = document.createElement('div');
    (0, preact_1.render)((0, jsx_runtime_1.jsx)(PromptPasswordOption_1.PromptPasswordOption, { loginCredentials: props.loginCredentials, webInputs: props.webInputs }), exports.promptOption);
    document.body.appendChild(exports.promptOption);
}
exports.renderLoginCredOption = renderLoginCredOption;
//# sourceMappingURL=renderLoginCredOption.js.map