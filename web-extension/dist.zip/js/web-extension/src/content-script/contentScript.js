"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initInputWatch = exports.domRecorder = exports.getWebInputKind = exports.trpc = void 0;
const lodash_1 = require("lodash");
const DOMEventsRecorder_1 = require("./DOMEventsRecorder");
const debug_1 = __importDefault(require("debug"));
const graphqlBaseTypes_1 = require("../../../shared/generated/graphqlBaseTypes");
const domMutationObserver_1 = require("./domMutationObserver");
const autofill_1 = require("./autofill");
const otplib_1 = require("otplib");
const renderer_1 = require("./renderer");
const client_1 = require("@trpc/client");
const link_1 = require("trpc-chrome/link");
const log = (0, debug_1.default)('au:contentScript');
localStorage.debug = localStorage.debug || 'au:*'; // enable all debug messages, TODO remove this for production
const port = chrome.runtime.connect();
exports.trpc = (0, client_1.createTRPCProxyClient)({
    links: [(0, link_1.chromeLink)({ port })]
});
const inputKindMap = {
    email: graphqlBaseTypes_1.WebInputType.EMAIL,
    username: graphqlBaseTypes_1.WebInputType.USERNAME
};
// TODO spec
function getWebInputKind(targetElement) {
    var _a;
    return ((_a = (targetElement.type === 'password'
        ? graphqlBaseTypes_1.WebInputType.PASSWORD
        : inputKindMap[targetElement.autocomplete])) !== null && _a !== void 0 ? _a : 'USERNAME_OR_EMAIL');
}
exports.getWebInputKind = getWebInputKind;
exports.domRecorder = new DOMEventsRecorder_1.DOMEventsRecorder();
const formsRegisteredForSubmitEvent = [];
let stateInitRes;
function initInputWatch() {
    return __awaiter(this, void 0, void 0, function* () {
        stateInitRes =
            (yield exports.trpc.getContentScriptInitialState.query());
        log('~ stateInitRes', stateInitRes);
        if (stateInitRes) {
            log('Press key');
            document.addEventListener('keydown', renderer_1.recordInputs, true);
        }
        if (!stateInitRes) {
            log('no state');
            return;
        }
        const { extensionDeviceReady, secretsForHost, autofillEnabled, passwordLimit, passwordCount } = stateInitRes;
        if (!extensionDeviceReady || !autofillEnabled) {
            log('no need to do anything-user locked out');
            return;
        }
        (0, renderer_1.renderer)(stateInitRes);
        const stopAutofillListener = (0, autofill_1.autofill)(stateInitRes);
        const onSubmit = (element) => {
            exports.domRecorder.addInputEvent({
                element,
                eventType: 'submit',
                kind: graphqlBaseTypes_1.WebInputType.SUBMIT_BUTTON
            });
            (0, renderer_1.showSavePromptIfAppropriate)(secretsForHost, passwordLimit, passwordCount);
        };
        const onInputRemoved = (input) => {
            // handle case when password input is removed from DOM by javascript
            if (input.type === 'password' && exports.domRecorder.hasInput(input)) {
                onSubmit(input);
            }
        };
        const onInputAdded = (input) => {
            // handle case when password input is added to DOM by javascript
            if (input.type === 'password' && !exports.domRecorder.hasInput(input)) {
                (0, autofill_1.autofill)(stateInitRes);
            }
        };
        domMutationObserver_1.bodyInputChangeEmitter.on('inputRemoved', onInputRemoved);
        domMutationObserver_1.bodyInputChangeEmitter.on('inputAdded', onInputAdded);
        /**
         * responsible for saving new web inputs
         */
        const debouncedInputEventListener = (0, lodash_1.debounce)((ev) => {
            log('Catched action', ev, ev.type);
            if (autofill_1.autofillEventsDispatched.has(ev)) {
                // this was dispatched by autofill, we don't need to do anything here
                autofill_1.autofillEventsDispatched.delete(ev);
                return;
            }
            const targetElement = ev.target;
            const isPasswordType = targetElement.type === 'password';
            const inputted = targetElement.value;
            if (isPasswordType ||
                targetElement.type === 'text' ||
                targetElement.type === 'email') {
                if (inputted) {
                    const inputRecord = {
                        element: targetElement,
                        eventType: 'input',
                        inputted,
                        kind: getWebInputKind(targetElement)
                    };
                    exports.domRecorder.addInputEvent(inputRecord);
                    // TOTP Recognision
                    if (inputted.length === 6 && secretsForHost.totpSecrets.length > 0) {
                        // TODO if this is a number check existing TOTP and add TOTP web input if it matches the OTP input
                        secretsForHost.totpSecrets.forEach((totpSecret) => __awaiter(this, void 0, void 0, function* () {
                            if (otplib_1.authenticator.generate(totpSecret.totp.secret) === inputted) {
                                const elementSelector = (0, DOMEventsRecorder_1.getSelectorForElement)(targetElement);
                                const webInput = {
                                    domPath: elementSelector.css,
                                    domOrdinal: elementSelector.domOrdinal,
                                    kind: graphqlBaseTypes_1.WebInputType.TOTP,
                                    url: location.href,
                                    domCoordinates: (0, autofill_1.getElementCoordinates)(targetElement)
                                };
                                yield exports.trpc.addTOTPInput.mutate(webInput);
                                log(`TOTP WebInput added for selector "${elementSelector}"`);
                            }
                        }));
                    }
                    if (targetElement.type === 'password') {
                        log('password inputted', inputted);
                        const form = targetElement.form;
                        if (form) {
                            // handle case when this is inside a form
                            if (formsRegisteredForSubmitEvent.includes(targetElement.form)) {
                                log('includes');
                                return;
                            }
                            form.addEventListener('submit', (ev) => {
                                onSubmit(form);
                            }, { once: true });
                            formsRegisteredForSubmitEvent.push(form);
                        }
                        // handle when the user uses enter key-custom JS might be listening for keydown as well and trigger submit externally
                        targetElement.addEventListener('keydown', (ev) => {
                            if (ev.code === 'Enter') {
                                exports.domRecorder.addInputEvent({
                                    element: targetElement,
                                    eventType: 'keydown',
                                    kind: null
                                });
                                (0, renderer_1.showSavePromptIfAppropriate)(secretsForHost, passwordLimit, passwordCount);
                            }
                        }, { once: true });
                        // some login flows don't have any forms, in that case we are listening for click, keydown
                        targetElement.ownerDocument.body.addEventListener('click', () => (0, renderer_1.showSavePromptIfAppropriate)(secretsForHost, passwordLimit, passwordCount), {
                            once: true
                        });
                    }
                }
            }
        }, 400);
        document.body.addEventListener('input', debouncedInputEventListener, true); // maybe there are websites where this won't work, we need to test this out larger number of websites
        return () => {
            document.body.removeEventListener('input', debouncedInputEventListener, true);
            stopAutofillListener();
            domMutationObserver_1.bodyInputChangeEmitter.off('inputRemoved', onInputRemoved);
            domMutationObserver_1.bodyInputChangeEmitter.off('inputAdded', onInputAdded);
        };
    });
}
exports.initInputWatch = initInputWatch;
initInputWatch();
// document.addEventListener('readystatechange', (event) => {
//   if (
//     event.target instanceof Document &&
//     event.target?.readyState === 'complete'
//   ) {
//     initInputWatch()
//   }
// })
// For SPA websites https://stackoverflow.com/questions/2844565/is-there-a-javascript-jquery-dom-change-listener/39508954#39508954
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        initInputWatch();
    }
}).observe(document, { subtree: true, childList: true });
//# sourceMappingURL=contentScript.js.map