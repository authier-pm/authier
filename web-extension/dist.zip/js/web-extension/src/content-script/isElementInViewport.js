"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isHidden = exports.isElementInViewport = void 0;
/**
 *
 * @param el
 * @returns boolean
 */
function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <=
            (window.innerHeight ||
                document.documentElement.clientHeight) /* or $(window).height() */ &&
        rect.right <=
            (window.innerWidth ||
                document.documentElement.clientWidth) /* or $(window).width() */);
}
exports.isElementInViewport = isElementInViewport;
function isHidden(el) {
    const style = window.getComputedStyle(el);
    return style.display === 'none';
}
exports.isHidden = isHidden;
//# sourceMappingURL=isElementInViewport.js.map