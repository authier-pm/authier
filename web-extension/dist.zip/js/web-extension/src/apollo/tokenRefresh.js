"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tokenRefresh = void 0;
const accessTokenExtension_1 = require("../util/accessTokenExtension");
const apollo_link_token_refresh_1 = require("apollo-link-token-refresh");
const jwt_decode_1 = __importDefault(require("jwt-decode"));
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const apolloClient_1 = require("./apolloClient");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
exports.tokenRefresh = new apollo_link_token_refresh_1.TokenRefreshLink({
    accessTokenField: 'accessToken',
    isTokenValidOrUndefined: () => {
        //Get token from local storage
        if (!accessTokenExtension_1.accessToken) {
            return false;
        }
        try {
            const { exp } = (0, jwt_decode_1.default)(accessTokenExtension_1.accessToken);
            if (Date.now() >= exp * 1000) {
                return false;
            }
            else {
                return true;
            }
        }
        catch (error) {
            return false;
        }
    },
    fetchAccessToken: () => __awaiter(void 0, void 0, void 0, function* () {
        return yield fetch(`${apolloClient_1.API_URL === null || apolloClient_1.API_URL === void 0 ? void 0 : apolloClient_1.API_URL.replace('/graphql', '')}/refresh_token`, {
            method: 'POST',
            credentials: 'include'
        });
    }),
    handleFetch: (accessToken) => __awaiter(void 0, void 0, void 0, function* () {
        yield webextension_polyfill_1.default.storage.local.set({ 'access-token': accessToken });
        (0, accessTokenExtension_1.setAccessToken)(accessToken);
    }),
    handleError: (err) => __awaiter(void 0, void 0, void 0, function* () {
        console.warn('Your refresh token is invalid. You must login again', err);
        yield (0, accessTokenExtension_1.removeToken)();
        yield ExtensionDevice_1.device.clearLocalStorage();
        ExtensionDevice_1.device.rerenderViews();
    })
});
//# sourceMappingURL=tokenRefresh.js.map