"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.apolloClient = exports.API_URL = void 0;
const client_1 = require("@apollo/client");
const context_1 = require("@apollo/client/link/context");
const accessTokenExtension_1 = require("../util/accessTokenExtension");
const errorLink_1 = require("../../../shared/errorLink");
const tokenRefresh_1 = require("./tokenRefresh");
const apollo_link_serialize_1 = __importDefault(require("apollo-link-serialize"));
exports.API_URL = process.env.API_URL;
const httpLink = (0, client_1.createHttpLink)({
    uri: exports.API_URL,
    credentials: 'include'
});
const serializingLink = new apollo_link_serialize_1.default();
const authLink = (0, context_1.setContext)((_, { headers }) => __awaiter(void 0, void 0, void 0, function* () {
    //get the authentication token
    const accessToken = yield (0, accessTokenExtension_1.getTokenFromLocalStorage)();
    //return the headers to the context so httpLink can read them
    return {
        headers: Object.assign(Object.assign({}, headers), { authorization: accessToken ? `bearer ${accessToken}` : '' })
    };
}));
exports.apolloClient = new client_1.ApolloClient({
    link: client_1.ApolloLink.from([
        tokenRefresh_1.tokenRefresh,
        //FIX: Remove any
        errorLink_1.errorLink,
        serializingLink,
        authLink,
        httpLink
    ]),
    cache: new client_1.InMemoryCache(),
    queryDeduplication: true
});
//# sourceMappingURL=apolloClient.js.map