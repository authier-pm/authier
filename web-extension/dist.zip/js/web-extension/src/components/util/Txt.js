"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Txt = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
/**
 * just a convenience wrapper, because vscode doesn't autocomplete the chakra-ui Text component
 */
const Txt = (props) => {
    return (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({}, props));
};
exports.Txt = Txt;
//# sourceMappingURL=Txt.js.map