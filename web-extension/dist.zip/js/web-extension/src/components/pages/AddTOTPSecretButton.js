"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTokenSecretFromQrCode = exports.AddTOTPSecretButton = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const macro_1 = require("@lingui/macro");
const executeScriptInCurrentTab_1 = require("@src/util/executeScriptInCurrentTab");
const react_2 = require("react");
const uuid_1 = require("uuid");
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const query_string_1 = __importDefault(require("query-string"));
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const getQrCodeFromUrl_1 = require("@src/util/getQrCodeFromUrl");
const graphqlBaseTypes_1 = require("../../../../shared/generated/graphqlBaseTypes");
const AccountLimits_codegen_1 = require("@src/pages-vault/AccountLimits.codegen");
const Providers_1 = require("@src/Providers");
const AddTOTPSecretButton = () => {
    const { deviceState, TOTPSecrets } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { data } = (0, AccountLimits_codegen_1.useMeExtensionQuery)();
    const addToTOTPs = (qr) => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        const tab = yield (0, executeScriptInCurrentTab_1.getCurrentTab)();
        const TOTPCount = (_b = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.secrets.filter((s) => s.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP).length) !== null && _b !== void 0 ? _b : 0;
        const TOTPLimit = (_d = (_c = data === null || data === void 0 ? void 0 : data.me) === null || _c === void 0 ? void 0 : _c.TOTPlimit) !== null && _d !== void 0 ? _d : 0;
        console.log('TOTPCount', TOTPCount, 'TOTPLimit', TOTPLimit);
        if (TOTPCount >= TOTPLimit) {
            (0, Providers_1.toast)({
                title: (0, macro_1.t) `You have reached your password limit. Please upgrade your account to add more passwords.`,
                status: 'error',
                isClosable: true
            });
            console.log('You have reached your password limit. Please upgrade your account to add more passwords.');
            return;
        }
        if (!tab || !deviceState) {
            return;
        }
        const newTotpSecret = yield getTokenSecretFromQrCode(qr, tab);
        const existingTotpSecret = TOTPSecrets.find(({ totp }) => newTotpSecret.totp.secret === totp.secret);
        if (existingTotpSecret) {
            (0, Providers_1.toast)({
                title: (0, macro_1.t) `This TOTP secret is already in your vault`,
                status: 'success',
                isClosable: true
            });
        }
        else {
            yield ((_e = ExtensionDevice_1.device.state) === null || _e === void 0 ? void 0 : _e.addSecrets([newTotpSecret]));
            (0, Providers_1.toast)({
                title: (0, macro_1.t) `Successfully added TOTP for ${newTotpSecret.totp.label}`,
                status: 'success',
                isClosable: true
            });
        }
    });
    return ((0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ className: "btn btn-block btn-outline-dark", onClick: () => __awaiter(void 0, void 0, void 0, function* () {
            const src = yield webextension_polyfill_1.default.tabs.captureVisibleTab();
            const qr = yield (0, getQrCodeFromUrl_1.getQrCodeFromUrl)(src);
            if (qr) {
                addToTOTPs(qr);
            }
            else {
                (0, Providers_1.toast)({
                    title: (0, macro_1.t) `could not find any QR code on this page. Make sure QR code is visible.`,
                    status: 'error',
                    isClosable: true
                });
            }
        }) }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Add QR TOTP" }) })));
};
exports.AddTOTPSecretButton = AddTOTPSecretButton;
function getTokenSecretFromQrCode(qr, tab) {
    var _a, _b;
    return __awaiter(this, void 0, void 0, function* () {
        const parsedQuery = query_string_1.default.parseUrl(qr.data);
        const secret = parsedQuery.query.secret;
        if (!secret) {
            console.error('QR code does not have any secret', qr.data);
            throw new Error('QR code does not have any secret');
        }
        let encrypted = yield ExtensionDevice_1.device.state.encrypt(secret);
        return {
            id: (0, uuid_1.v4)(),
            kind: graphqlBaseTypes_1.EncryptedSecretType.TOTP,
            totp: {
                secret: secret,
                digits: 6,
                period: 30,
                iconUrl: (_a = tab.favIconUrl) !== null && _a !== void 0 ? _a : null,
                label: (_b = parsedQuery.query.issuer) !== null && _b !== void 0 ? _b : decodeURIComponent(parsedQuery.url.replace('otpauth://totp/', '')),
                url: tab.url
            },
            createdAt: new Date().toJSON(),
            encrypted
        };
    });
}
exports.getTokenSecretFromQrCode = getTokenSecretFromQrCode;
//# sourceMappingURL=AddTOTPSecretButton.js.map