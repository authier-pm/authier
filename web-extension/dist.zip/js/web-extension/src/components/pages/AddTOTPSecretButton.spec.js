"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AddTOTPSecretButton_1 = require("./AddTOTPSecretButton");
describe('getTokenSecretFromQrCode', () => {
    it('should work for bitfinex TOTP secret QR codes with/without issuer', () => {
        const secretToken = (0, AddTOTPSecretButton_1.getTokenSecretFromQrCode)({
            data: 'otpauth://totp/Bitfinex-8-30-2021?secret=SuperDUperSecretToken&issuer=Bitfinex'
        }, {
            favIconUrl: 'test.ico',
            title: 'testTitle',
            url: 'https://www.bitfinex.com/'
        });
        expect(secretToken).toMatchInlineSnapshot(`
      Object {
        "icon": "test.ico",
        "label": "Bitfinex",
        "originalUrl": "https://www.bitfinex.com/",
        "secret": "SuperDUperSecretToken",
      }
    `);
        expect((0, AddTOTPSecretButton_1.getTokenSecretFromQrCode)({
            data: 'otpauth://totp/Bitfinex-8-30-2021?secret=SuperDUperSecretToken'
        }, {
            favIconUrl: 'test.ico',
            title: 'testTitle',
            url: 'https://www.bitfinex.com/'
        })).toMatchInlineSnapshot(`
      Object {
        "icon": "test.ico",
        "label": "Bitfinex-8-30-2021",
        "originalUrl": "https://www.bitfinex.com/",
        "secret": "SuperDUperSecretToken",
      }
    `);
    });
});
//# sourceMappingURL=AddTOTPSecretButton.spec.js.map