"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthsList = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_2 = require("@chakra-ui/react");
const otplib_1 = require("otplib");
const icons_1 = require("@chakra-ui/icons");
const react_3 = require("@chakra-ui/react");
const macro_1 = require("@lingui/macro");
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const debug_1 = __importDefault(require("debug"));
const SecretItemIcon_1 = require("../SecretItemIcon");
const extractHostname_1 = require("@src/util/extractHostname");
const AuthList_codegen_1 = require("./AuthList.codegen");
const log = (0, debug_1.default)('au:AuthsList');
const OtpCode = ({ totpSecret }) => {
    const [addOTPEvent, { data, error }] = (0, AuthList_codegen_1.useAddOtpEventMutation)(); //ignore results??
    // const otpCode = '1111'
    const otpCode = otplib_1.authenticator.generate(totpSecret.totp.secret);
    const [showWhole, setShowWhole] = (0, react_1.useState)(false);
    const { onCopy } = (0, react_2.useClipboard)(otpCode);
    (0, react_1.useEffect)(() => {
        setShowWhole(false);
    }, [otpCode]);
    return ((0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ p: "3", m: 1, rounded: "md", bg: (0, react_2.useColorModeValue)('gray.100', 'gray.700'), minW: "300px" }, { children: (0, jsx_runtime_1.jsx)(react_2.Stat, Object.assign({ maxW: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ justify: "space-between", align: "center", w: "100%" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: (0, jsx_runtime_1.jsx)(SecretItemIcon_1.SecretItemIcon, Object.assign({}, totpSecret.totp)) })), (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ ml: 4, mr: "auto" }, { children: [(0, jsx_runtime_1.jsx)(react_2.StatLabel, { children: totpSecret.totp.label }), (0, jsx_runtime_1.jsx)(react_2.StatNumber, Object.assign({ onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                    setShowWhole(!showWhole);
                                    if (!showWhole) {
                                        // CHECK
                                        const tabs = yield webextension_polyfill_1.default.tabs.query({ active: true });
                                        const url = tabs[0].url;
                                        yield addOTPEvent({
                                            variables: {
                                                event: {
                                                    kind: 'show OTP',
                                                    url: url,
                                                    secretId: totpSecret.id
                                                }
                                            }
                                        });
                                        log(data, error);
                                    }
                                }) }, { children: showWhole ? (otpCode) : ((0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: (0, macro_1.t) `Click to show the whole` }, { children: otpCode.substr(0, 3) + '***' }))) }))] })), (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: (0, macro_1.t) `Copy TOTP` }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ size: "md", ml: 2, variant: "solid", colorScheme: 'cyan', onClick: () => {
                                onCopy();
                                // TODO log usage of this token to backend
                            } }, { children: (0, jsx_runtime_1.jsx)(icons_1.CopyIcon, {}) })) }))] })) })) })));
};
const LoginCredentialsListItem = ({ loginSecret }) => {
    const { loginCredentials } = loginSecret;
    const { onCopy } = (0, react_2.useClipboard)(loginCredentials.password);
    return ((0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ boxShadow: "xl", m: 2 }, { children: (0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ p: "3", rounded: "md", bg: (0, react_2.useColorModeValue)('gray.100', 'gray.700') }, { children: (0, jsx_runtime_1.jsx)(react_2.Stat, Object.assign({ maxW: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ justify: "space-between", align: "center", w: "100%" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: (0, jsx_runtime_1.jsx)(SecretItemIcon_1.SecretItemIcon, Object.assign({}, loginCredentials)) })), (0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ ml: 2, mr: "auto", maxW: "200px" }, { children: [(0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "sm", whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }, { children: loginCredentials.label })), (0, jsx_runtime_1.jsx)(react_2.Text, Object.assign({ fontSize: "sm", whiteSpace: "nowrap" }, { children: loginCredentials.username.replace(/http:\/\/|https:\/\//, '') }))] })), (0, jsx_runtime_1.jsx)(react_3.Tooltip, Object.assign({ label: (0, macro_1.t) `Copy password` }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ size: "md", ml: "auto", boxShadow: "md", variant: "solid", color: 'green.700', bgColor: 'green.200', onClick: () => {
                                    onCopy();
                                    // TODO log usage of this token to backend
                                } }, { children: (0, jsx_runtime_1.jsx)(icons_1.CopyIcon, {}) })) }))] })) })) }), loginCredentials.url) })));
};
const AuthsList = ({ filterByTLD }) => {
    const { deviceState, TOTPSecrets, loginCredentials, currentURL } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    if (!deviceState) {
        return null;
    }
    const TOTPForCurrentDomain = TOTPSecrets.filter(({ totp }) => {
        if (!currentURL || !totp.url) {
            return true;
        }
        return (0, extractHostname_1.extractHostname)(totp.url) === (0, extractHostname_1.extractHostname)(currentURL);
    });
    const loginCredentialForCurrentDomain = loginCredentials.filter(({ loginCredentials }) => {
        if (!loginCredentials.url) {
            return false; // for example TOTP secrets do not have any URL after import from authy
        }
        if (!currentURL) {
            return true;
        }
        return ((0, extractHostname_1.extractHostname)(loginCredentials.url) === (0, extractHostname_1.extractHostname)(currentURL));
    });
    const hasNoSecrets = deviceState.secrets.length === 0;
    const getRecentlyUsed = (secrets) => {
        return secrets
            .sort((a, b) => { var _a, _b; return ((_a = a.lastUsedAt) !== null && _a !== void 0 ? _a : a.createdAt) >= ((_b = b.lastUsedAt) !== null && _b !== void 0 ? _b : b.createdAt) ? 1 : -1; })
            .slice(0, 20); // we get items
    };
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDirection: "column" }, { children: [hasNoSecrets === false &&
                    filterByTLD &&
                    TOTPForCurrentDomain.length === 0 &&
                    loginCredentialForCurrentDomain.length === 0 && ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_2.Text, { children: [(0, jsx_runtime_1.jsx)(icons_1.NotAllowedIcon, {}), "There are no stored secrets for current domain."] }) })), filterByTLD ? ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [TOTPForCurrentDomain.map((auth, i) => {
                            return ((0, jsx_runtime_1.jsx)(OtpCode, { totpSecret: auth }, auth.totp.label + i));
                        }), loginCredentialForCurrentDomain.map((credentials, i) => {
                            console.log('credentials', credentials);
                            return ((0, jsx_runtime_1.jsx)(LoginCredentialsListItem, { loginSecret: credentials }, credentials.loginCredentials.label + i));
                        })] })) : ([
                    getRecentlyUsed(TOTPSecrets).map((auth, i) => {
                        return ((0, jsx_runtime_1.jsx)(OtpCode, { totpSecret: auth }, auth.totp.label + i));
                    }),
                    getRecentlyUsed(loginCredentials).map((psw, i) => {
                        // console.log(psw.loginCredentials.url)
                        return ((0, jsx_runtime_1.jsx)(LoginCredentialsListItem, { loginSecret: psw }, psw.loginCredentials.label + i));
                    })
                ]), hasNoSecrets && (
                // TODO login form illustration
                (0, jsx_runtime_1.jsx)(react_2.Text, { children: "Start by adding a secret by logging onto any website or by adding a TOTP code" }))] })) }));
};
exports.AuthsList = AuthsList;
//# sourceMappingURL=AuthsList.js.map