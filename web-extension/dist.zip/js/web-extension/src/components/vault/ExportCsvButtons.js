"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExportLoginCredentialsToCsvButton = exports.ExportTOTPToCsvButton = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = require("react");
const papaparse_1 = __importDefault(require("papaparse"));
const downloadAsFile_1 = require("@src/util/downloadAsFile");
const macro_1 = require("@lingui/macro");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const ExportTOTPToCsvButton = () => {
    const { TOTPSecrets } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    return ((0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ mt: 4, minW: "300px", colorScheme: "teal", type: "submit", onClick: () => {
            const csv = papaparse_1.default.unparse(TOTPSecrets);
            (0, downloadAsFile_1.downloadAsFile)(csv, 'totp');
        } }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Export TOTP to CSV" }) })));
};
exports.ExportTOTPToCsvButton = ExportTOTPToCsvButton;
const ExportLoginCredentialsToCsvButton = () => {
    const { loginCredentials: LoginCredentials } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    return ((0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ mt: 4, minW: "300px", colorScheme: "teal", type: "submit", onClick: () => {
            // Call here export mutation for export notification
            const csv = papaparse_1.default.unparse(LoginCredentials.map(({ id, loginCredentials }) => ({
                id,
                url: loginCredentials.url,
                label: loginCredentials.label,
                username: loginCredentials.username,
                password: loginCredentials.password
            })));
            (0, downloadAsFile_1.downloadAsFile)(csv, 'credentials');
        } }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Export Login Credentials to CSV" }) })));
};
exports.ExportLoginCredentialsToCsvButton = ExportLoginCredentialsToCsvButton;
//# sourceMappingURL=ExportCsvButtons.js.map