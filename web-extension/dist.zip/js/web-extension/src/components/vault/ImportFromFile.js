"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportFromFile = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_dropzone_1 = require("react-dropzone");
const react_2 = require("@chakra-ui/react");
const ai_1 = require("react-icons/ai");
function ImportFromFile({ onFileAccepted }) {
    const onDrop = (0, react_1.useCallback)((acceptedFiles) => {
        onFileAccepted(acceptedFiles[0]);
    }, [onFileAccepted]);
    const { getRootProps, getInputProps, isDragActive } = (0, react_dropzone_1.useDropzone)({
        onDrop,
        accept: {
            'text/*': ['.csv', '.json']
        },
        maxFiles: 1,
        multiple: false
    });
    const dropText = isDragActive
        ? 'Drop the files here ...'
        : "Drag 'n' drop .csv, json file here, or click to select files";
    const activeBg = (0, react_2.useColorModeValue)('gray.100', 'gray.600');
    const borderColor = (0, react_2.useColorModeValue)(isDragActive ? 'teal.300' : 'gray.300', isDragActive ? 'teal.500' : 'gray.500');
    return ((0, jsx_runtime_1.jsxs)(react_2.Center, Object.assign({ p: 10, cursor: "pointer", bg: isDragActive ? activeBg : 'transparent', _hover: { bg: activeBg }, transition: "background-color 0.2s ease", borderRadius: 4, border: "3px dashed", borderColor: borderColor }, getRootProps(), { children: [(0, jsx_runtime_1.jsx)("input", Object.assign({}, getInputProps())), (0, jsx_runtime_1.jsx)(react_2.Icon, { as: ai_1.AiFillFileAdd, mr: 2, boxSize: 20 }), (0, jsx_runtime_1.jsx)("p", { children: dropText })] })));
}
exports.ImportFromFile = ImportFromFile;
//# sourceMappingURL=ImportFromFile.js.map