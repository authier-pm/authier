"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const formik_1 = require("formik");
const react_2 = require("react");
const framer_motion_1 = require("framer-motion");
const macro_1 = require("@lingui/macro");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const Settings_codegen_1 = require("@shared/graphql/Settings.codegen");
function VaultConfig() {
    const { setSecuritySettings, device } = (0, react_2.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const [updateSettings] = (0, Settings_codegen_1.useUpdateSettingsMutation)({
        refetchQueries: [{ query: Settings_codegen_1.SyncSettingsDocument, variables: {} }]
    });
    // Split to container component to avoid rewriting the same code twice (Account and VaultConfig)
    if (device.state) {
        return ((0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: { opacity: 1, y: 0 }, initial: { opacity: 0, y: 20 }, exit: { opacity: 0, y: -20 }, transition: { duration: 0.35 }, style: {
                display: 'contents'
            } }, { children: (0, jsx_runtime_1.jsx)(react_1.VStack, Object.assign({ width: '70%', maxW: "600px", alignItems: 'normal', spacing: 20, rounded: 'lg', boxShadow: 'lg', p: 30, bg: (0, react_1.useColorModeValue)('white', 'gray.800') }, { children: (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ textAlign: "start" }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                            autofill: device.state.autofill,
                            language: device.state.language,
                            syncTOTP: device.state.syncTOTP,
                            vaultLockTimeoutSeconds: device.state.lockTime
                        }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                            const config = Object.assign(Object.assign({}, values), { vaultLockTimeoutSeconds: parseInt(values.vaultLockTimeoutSeconds.toString()) });
                            yield updateSettings({
                                variables: {
                                    config
                                }
                            });
                            setSecuritySettings(config);
                            setSubmitting(false);
                        }) }, { children: ({ dirty, handleSubmit, errors, touched, values, isSubmitting, submitForm, resetForm }) => ((0, jsx_runtime_1.jsx)("form", Object.assign({ onBlur: () => __awaiter(this, void 0, void 0, function* () {
                                if (dirty) {
                                    yield submitForm();
                                    resetForm({ values });
                                }
                            }), onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ spacing: 4, align: "flex-start" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.vaultLockTimeoutSeconds &&
                                            touched.vaultLockTimeoutSeconds }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "vaultLockTimeoutSeconds" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Lock time" }) })), (0, jsx_runtime_1.jsxs)(formik_1.Field, Object.assign({ as: react_1.Select, id: "vaultLockTimeoutSeconds", name: "vaultLockTimeoutSeconds" }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ value: 20 }, { children: "1 minute" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 120 }, { children: "2 minutes" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 3600 }, { children: "1 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 14400 }, { children: "4 hour" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 28800 }, { children: "8 hours" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 86400 }, { children: "1 day" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 604800 }, { children: "1 week" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 2592000 }, { children: "1 month" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: 0 }, { children: "Never" }))] })), (0, jsx_runtime_1.jsx)(react_1.FormHelperText, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Automatically locks vault after chosen period of time" }) })] })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "syncTOTP" }, { children: ({ field, form }) => {
                                            const { onChange } = field, rest = __rest(field, ["onChange"]);
                                            return ((0, jsx_runtime_1.jsx)(react_1.FormControl, Object.assign({ id: "syncTOTP", isInvalid: !!form.errors['syncTOTP'] &&
                                                    !!form.touched['syncTOTP'] }, { children: (0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({}, rest, { id: "syncTOTP", onChange: onChange, defaultChecked: values.syncTOTP }, { children: "2FA" })) })));
                                        } })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "autofill" }, { children: ({ field, form }) => {
                                            const { onChange } = field, rest = __rest(field, ["onChange"]);
                                            return ((0, jsx_runtime_1.jsx)(react_1.FormControl, Object.assign({ id: "autofill", isInvalid: !!form.errors['autofill'] &&
                                                    !!form.touched['autofill'] }, { children: (0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({}, rest, { id: "autofill", onChange: onChange, defaultChecked: values.autofill }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Autofill" }) })) })));
                                        } })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.language && touched.language }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "language" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Language" }) })), (0, jsx_runtime_1.jsxs)(formik_1.Field, Object.assign({ as: react_1.Select, id: "language", name: "language" }, { children: [(0, jsx_runtime_1.jsx)("option", Object.assign({ value: "en" }, { children: "English" })), (0, jsx_runtime_1.jsx)("option", Object.assign({ value: "cz" }, { children: "\u010Ce\u0161tina" }))] }))] })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ mt: 4, colorScheme: "teal", disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Save" }) }))] })) }))) })) })) })) })));
    }
    return null;
}
exports.default = VaultConfig;
//# sourceMappingURL=VaultConfig.js.map