"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const formik_1 = require("formik");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const react_2 = require("react");
const framer_motion_1 = require("framer-motion");
const Account_codegen_1 = require("./Account.codegen");
const Login_codegen_1 = require("@shared/graphql/Login.codegen");
const react_toastify_1 = require("react-toastify");
const icons_1 = require("@chakra-ui/icons");
const NbSp_1 = require("@src/components/util/NbSp");
const macro_1 = require("@lingui/macro");
const react_3 = require("@chakra-ui/react");
function Account() {
    var _a;
    const email = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.email;
    const [showCurr, setShowCurr] = (0, react_2.useState)(false);
    const [showNew, setShownNew] = (0, react_2.useState)(false);
    const [showPass, setShowPass] = (0, react_2.useState)(false);
    const [changePassword] = (0, Account_codegen_1.useChangeMasterPasswordMutation)();
    const [deviceDecryptionChallenge] = (0, Login_codegen_1.useDeviceDecryptionChallengeMutation)();
    const { data } = (0, Account_codegen_1.useAccountQuery)();
    if (!email) {
        return (0, jsx_runtime_1.jsx)(react_1.Spinner, {});
    }
    return ((0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: { opacity: 1, y: 0 }, initial: { opacity: 0, y: 20 }, exit: { opacity: 0, y: -20 }, transition: { duration: 0.35 }, style: {
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ width: '70%', maxW: "600px", alignItems: 'normal', spacing: 20, rounded: 'lg', boxShadow: 'lg', p: 30, bg: (0, react_1.useColorModeValue)('white', 'gray.800') }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Box, { children: [(0, jsx_runtime_1.jsx)(react_3.Heading, Object.assign({ as: "h3", size: "lg", mb: 5 }, { children: "Change master password" })), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                                email: email,
                                currPassword: '',
                                newPassword: '',
                                confirmPassword: ''
                            }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                                var _b, _c, _d;
                                console.log(values.newPassword);
                                if (values.newPassword === values.confirmPassword &&
                                    values.currPassword === ((_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.masterEncryptionKey)) {
                                    const decryptionChallenge = yield deviceDecryptionChallenge({
                                        variables: {
                                            deviceInput: {
                                                id: ExtensionDevice_1.device.id,
                                                name: ExtensionDevice_1.device.name,
                                                platform: ExtensionDevice_1.device.platform
                                            },
                                            email: values.email
                                        }
                                    });
                                    const secrets = ExtensionDevice_1.device.state.secrets;
                                    const { state } = ExtensionDevice_1.device;
                                    yield changePassword({
                                        variables: {
                                            secrets: yield ExtensionDevice_1.device.serializeSecrets(secrets, values.newPassword),
                                            addDeviceSecret: state.authSecret,
                                            addDeviceSecretEncrypted: state.authSecretEncrypted,
                                            decryptionChallengeId: (_d = (_c = decryptionChallenge.data) === null || _c === void 0 ? void 0 : _c.deviceDecryptionChallenge) === null || _d === void 0 ? void 0 : _d.id
                                        }
                                    });
                                    yield ExtensionDevice_1.device.logout();
                                }
                                else {
                                    react_toastify_1.toast.warning('Wrong password');
                                }
                                setSubmitting(false);
                                return false;
                            }) }, { children: ({ isSubmitting, dirty, touched, handleSubmit, errors }) => {
                                var _a, _b;
                                return ((0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ spacing: 4, align: "flex-start" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.email && touched.email }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormLabel, Object.assign({ htmlFor: "email" }, { children: ["Email", (0, jsx_runtime_1.jsx)(NbSp_1.NbSp, {}), ((_b = (_a = data === null || data === void 0 ? void 0 : data.me) === null || _a === void 0 ? void 0 : _a.primaryEmailVerification) === null || _b === void 0 ? void 0 : _b.verifiedAt) ? ((0, jsx_runtime_1.jsx)(icons_1.CheckIcon, { boxSize: 18 })) : ((0, jsx_runtime_1.jsx)(icons_1.WarningIcon, { boxSize: 18 }))] })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "email", name: "email", type: "email" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.email })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.currPassword && touched.currPassword }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "currPassword" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Current password" }) })), (0, jsx_runtime_1.jsxs)(react_1.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, pr: "4.5rem", type: showCurr ? 'text' : 'password', placeholder: "Master password", id: "currPassword", name: "currPassword" }), (0, jsx_runtime_1.jsx)(react_1.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShowCurr(!showCurr) }, { children: showCurr ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.currPassword })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.newPassword && touched.newPassword }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "newPassword", whiteSpace: 'nowrap' }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Set new Master password" }) })), (0, jsx_runtime_1.jsxs)(react_1.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, pr: "4.5rem", type: showNew ? 'text' : 'password', placeholder: "New master password", id: "newPassword", name: "newPassword" }), (0, jsx_runtime_1.jsx)(react_1.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShownNew(!showNew) }, { children: showNew ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.newPassword })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isRequired: true, isInvalid: !!errors.confirmPassword && touched.confirmPassword }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "confirmPassword", whiteSpace: 'nowrap' }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Confirm new password" }) })), (0, jsx_runtime_1.jsxs)(react_1.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, pr: "4.5rem", type: showPass ? 'text' : 'password', placeholder: "Confirm password", id: "confirmPassword", name: "confirmPassword" }), (0, jsx_runtime_1.jsx)(react_1.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShowPass(!showPass) }, { children: showPass ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.confirmPassword })] })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ mt: 4, colorScheme: "teal", disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit" }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Set master password" }) }))] })) })));
                            } }))] }), (0, jsx_runtime_1.jsxs)(react_1.Box, { children: [(0, jsx_runtime_1.jsx)(react_3.Heading, Object.assign({ as: "h3", size: "lg", color: 'red', mb: 5 }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Danger zone" }) })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ colorScheme: 'red' }, { children: "Delete your account" }))] })] })) })));
}
exports.default = Account;
//# sourceMappingURL=Account.js.map