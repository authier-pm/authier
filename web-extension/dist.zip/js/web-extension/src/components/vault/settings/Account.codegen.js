"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useResendEmailVerificationMutation = exports.ResendEmailVerificationDocument = exports.useAccountLazyQuery = exports.useAccountQuery = exports.AccountDocument = exports.useChangeMasterPasswordMutation = exports.ChangeMasterPasswordDocument = void 0;
const client_1 = require("@apollo/client");
const Apollo = __importStar(require("@apollo/client"));
const defaultOptions = {};
exports.ChangeMasterPasswordDocument = (0, client_1.gql) `
    mutation changeMasterPassword($secrets: [EncryptedSecretPatchInput!]!, $addDeviceSecret: NonEmptyString!, $addDeviceSecretEncrypted: NonEmptyString!, $decryptionChallengeId: PositiveInt!) {
  me {
    changeMasterPassword(
      input: {secrets: $secrets, addDeviceSecret: $addDeviceSecret, addDeviceSecretEncrypted: $addDeviceSecretEncrypted, decryptionChallengeId: $decryptionChallengeId}
    )
  }
}
    `;
/**
 * __useChangeMasterPasswordMutation__
 *
 * To run a mutation, you first call `useChangeMasterPasswordMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useChangeMasterPasswordMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [changeMasterPasswordMutation, { data, loading, error }] = useChangeMasterPasswordMutation({
 *   variables: {
 *      secrets: // value for 'secrets'
 *      addDeviceSecret: // value for 'addDeviceSecret'
 *      addDeviceSecretEncrypted: // value for 'addDeviceSecretEncrypted'
 *      decryptionChallengeId: // value for 'decryptionChallengeId'
 *   },
 * });
 */
function useChangeMasterPasswordMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.ChangeMasterPasswordDocument, options);
}
exports.useChangeMasterPasswordMutation = useChangeMasterPasswordMutation;
exports.AccountDocument = (0, client_1.gql) `
    query Account {
  me {
    id
    deviceRecoveryCooldownMinutes
    primaryEmailVerification {
      createdAt
      verifiedAt
    }
  }
}
    `;
/**
 * __useAccountQuery__
 *
 * To run a query within a React component, call `useAccountQuery` and pass it any options that fit your needs.
 * When your component renders, `useAccountQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useAccountQuery({
 *   variables: {
 *   },
 * });
 */
function useAccountQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useQuery(exports.AccountDocument, options);
}
exports.useAccountQuery = useAccountQuery;
function useAccountLazyQuery(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useLazyQuery(exports.AccountDocument, options);
}
exports.useAccountLazyQuery = useAccountLazyQuery;
exports.ResendEmailVerificationDocument = (0, client_1.gql) `
    mutation resendEmailVerification {
  me {
    sendEmailVerification
  }
}
    `;
/**
 * __useResendEmailVerificationMutation__
 *
 * To run a mutation, you first call `useResendEmailVerificationMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useResendEmailVerificationMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [resendEmailVerificationMutation, { data, loading, error }] = useResendEmailVerificationMutation({
 *   variables: {
 *   },
 * });
 */
function useResendEmailVerificationMutation(baseOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), baseOptions);
    return Apollo.useMutation(exports.ResendEmailVerificationDocument, options);
}
exports.useResendEmailVerificationMutation = useResendEmailVerificationMutation;
//# sourceMappingURL=Account.codegen.js.map