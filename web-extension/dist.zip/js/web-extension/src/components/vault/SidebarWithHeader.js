"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const fi_1 = require("react-icons/fi");
const react_router_dom_1 = require("react-router-dom");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const md5_1 = __importDefault(require("crypto-js/md5"));
const icons_1 = require("@chakra-ui/icons");
const macro_1 = require("@lingui/macro");
const ColorModeButton_1 = require("../ColorModeButton");
const LinkItems = [
    { title: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Vault" }), icon: fi_1.FiHome, path: '/' },
    {
        title: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Settings" }),
        icon: fi_1.FiSettings,
        path: '/settings/account'
    },
    {
        title: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Account Limits" }),
        icon: fi_1.FiStar,
        path: '/account-limits'
    },
    { title: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Devices" }), icon: fi_1.FiHardDrive, path: '/devices' },
    {
        title: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Import & Export" }),
        icon: fi_1.FiDisc,
        path: '/import-export'
    }
];
function SidebarWithHeader({ children }) {
    const { isOpen, onOpen, onClose } = (0, react_1.useDisclosure)();
    return ((0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ minH: "100vh", bg: (0, react_1.useColorModeValue)('gray.50', 'gray.900') }, { children: [(0, jsx_runtime_1.jsx)(SidebarContent, { onClose: () => onClose, display: { base: 'none', md: 'block' } }), (0, jsx_runtime_1.jsx)(react_1.Drawer, Object.assign({ autoFocus: false, isOpen: isOpen, placement: "left", onClose: onClose, returnFocusOnClose: false, onOverlayClick: onClose, size: "full" }, { children: (0, jsx_runtime_1.jsx)(react_1.DrawerContent, { children: (0, jsx_runtime_1.jsx)(SidebarContent, { onClose: onClose }) }) })), (0, jsx_runtime_1.jsx)(MobileNav, { display: { base: 'flex', md: 'none' }, onOpen: onOpen }), (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ ml: { base: 0, md: 60 }, p: "7" }, { children: children }))] })));
}
exports.default = SidebarWithHeader;
const SidebarContent = (_a) => {
    var _b;
    var { onClose } = _a, rest = __rest(_a, ["onClose"]);
    const email = (_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.email;
    if (!email) {
        return (0, jsx_runtime_1.jsx)(react_1.Spinner, {});
    }
    return ((0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ transition: "1s ease", bg: (0, react_1.useColorModeValue)('white', 'gray.800'), borderRight: "1px", borderRightColor: (0, react_1.useColorModeValue)('gray.200', 'gray.700'), w: { base: 'full', md: 60 }, pos: "fixed", h: "full", flexDirection: "column", alignItems: "center" }, rest, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ justifyContent: 'flex-end', flexDirection: "column", height: "inherit" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ h: "20", alignItems: "center", mx: "8", justifyContent: "space-between" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: "2xl", fontFamily: "monospace", fontWeight: "bold" }, { children: "Authier" })), (0, jsx_runtime_1.jsx)(react_1.CloseButton, { display: { base: 'flex', md: 'none' }, onClick: onClose })] })), (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "column", height: "100%" }, { children: [LinkItems.map((link, i) => ((0, jsx_runtime_1.jsx)(NavItem, Object.assign({ icon: link.icon, path: link.path }, { children: link.title }), i))), (0, jsx_runtime_1.jsx)(ColorModeButton_1.ColorModeButton, {})] })), (0, jsx_runtime_1.jsx)(react_1.HStack, Object.assign({ spacing: { base: '0', md: '6' }, w: "80%", m: 4 }, { children: (0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ alignItems: 'center', w: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_1.Menu, { children: [(0, jsx_runtime_1.jsx)(react_1.MenuButton, Object.assign({ py: 2, transition: "all 0.3s", _focus: { boxShadow: 'none' }, w: "100%" }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ w: "100%" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Avatar, { size: 'sm', src: `https://www.gravatar.com/avatar/${(0, md5_1.default)(email)}}` }), (0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ display: { base: 'none', md: 'flex' }, alignItems: "flex-start", spacing: "1px", ml: "2", mr: "auto" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: "sm" }, { children: email })), (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: "xs", color: "gray.600" }, { children: "Admin" }))] })), (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ display: { base: 'none', md: 'flex' }, ml: "auto" }, { children: (0, jsx_runtime_1.jsx)(icons_1.ChevronDownIcon, { boxSize: 19 }) }))] })) })), (0, jsx_runtime_1.jsxs)(react_1.MenuList, Object.assign({ bg: (0, react_1.useColorModeValue)('white', 'gray.900'), borderColor: (0, react_1.useColorModeValue)('gray.200', 'gray.700') }, { children: [(0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/settings/account" }, { children: (0, jsx_runtime_1.jsx)(react_1.MenuItem, { children: "Settings" }) })), (0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/account-limits" }, { children: (0, jsx_runtime_1.jsx)(react_1.MenuItem, { children: "Billing" }) })), (0, jsx_runtime_1.jsx)(react_1.MenuDivider, {}), (0, jsx_runtime_1.jsx)(react_1.MenuItem, Object.assign({ backgroundColor: "red.500", _hover: {
                                                backgroundColor: (0, react_1.useColorModeValue)('red.200', 'red.400')
                                            }, onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                                yield ExtensionDevice_1.device.logout();
                                            }) }, { children: "Logout" }))] }))] }) })) }))] })) })));
};
const NavItem = (_a) => {
    var { icon, path, children } = _a, rest = __rest(_a, ["icon", "path", "children"]);
    return ((0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ as: react_router_dom_1.NavLink, to: path, style: { textDecoration: 'none' }, _activeLink: {
            bg: 'teal.700' // TODO fix
        } }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ align: "center", p: "4", mx: "4", borderRadius: "lg", role: "group", cursor: "pointer", _hover: {
                bg: 'orange.300',
                color: 'orange.800'
            } }, rest, { children: [icon && ((0, jsx_runtime_1.jsx)(react_1.Icon, { mr: "4", fontSize: "16", _groupHover: {
                        color: 'gray.400'
                    }, as: icon })), children] })) })));
};
const MobileNav = (_a) => {
    var _b;
    var { onOpen } = _a, rest = __rest(_a, ["onOpen"]);
    const email = (_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.email;
    return ((0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ ml: { base: 0, md: 60 }, px: { base: 4, md: 4 }, height: "20", alignItems: "center", bg: (0, react_1.useColorModeValue)('white', 'gray.900'), borderBottomWidth: "1px", borderBottomColor: (0, react_1.useColorModeValue)('gray.200', 'gray.700'), justifyContent: { base: 'space-between', md: 'flex-end' } }, rest, { children: [(0, jsx_runtime_1.jsx)(react_1.IconButton, { display: { base: 'flex', md: 'none' }, onClick: onOpen, variant: "outline", "aria-label": "open menu", icon: (0, jsx_runtime_1.jsx)(fi_1.FiMenu, {}) }), (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ display: { base: 'flex', md: 'none' }, fontSize: "2xl", fontFamily: "monospace", fontWeight: "bold" }, { children: "Logo" })), (0, jsx_runtime_1.jsxs)(react_1.HStack, Object.assign({ spacing: { base: '0', md: '6' } }, { children: [(0, jsx_runtime_1.jsx)(ColorModeButton_1.ColorModeButton, {}), (0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ alignItems: 'center' }, { children: (0, jsx_runtime_1.jsxs)(react_1.Menu, { children: [(0, jsx_runtime_1.jsx)(react_1.MenuButton, Object.assign({ py: 2, transition: "all 0.3s", _focus: { boxShadow: 'none' } }, { children: (0, jsx_runtime_1.jsxs)(react_1.HStack, { children: [(0, jsx_runtime_1.jsx)(react_1.Avatar, { size: 'sm', src: `https://www.gravatar.com/avatar/${(0, md5_1.default)(email)}}` }), (0, jsx_runtime_1.jsxs)(react_1.VStack, Object.assign({ display: { base: 'none', md: 'flex' }, alignItems: "flex-start", spacing: "1px", ml: "2" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: "sm" }, { children: email })), (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: "xs", color: "gray.600" }, { children: "Admin" }))] })), (0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ display: { base: 'none', md: 'flex' } }, { children: (0, jsx_runtime_1.jsx)(fi_1.FiChevronDown, {}) }))] }) })), (0, jsx_runtime_1.jsxs)(react_1.MenuList, Object.assign({ bg: (0, react_1.useColorModeValue)('white', 'gray.900'), borderColor: (0, react_1.useColorModeValue)('gray.200', 'gray.700') }, { children: [(0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/settings/account" }, { children: (0, jsx_runtime_1.jsx)(react_1.MenuItem, { children: "Settings" }) })), (0, jsx_runtime_1.jsx)(react_1.Link, Object.assign({ as: react_router_dom_1.NavLink, to: "/account-limits" }, { children: (0, jsx_runtime_1.jsx)(react_1.MenuItem, { children: "Billing" }) })), (0, jsx_runtime_1.jsx)(react_1.MenuDivider, {}), (0, jsx_runtime_1.jsx)(react_1.MenuItem, Object.assign({ backgroundColor: "red.400", onClick: () => {
                                                ExtensionDevice_1.device.logout();
                                            } }, { children: "Logout" }))] }))] }) }))] }))] })));
};
//# sourceMappingURL=SidebarWithHeader.js.map