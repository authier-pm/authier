"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VirtualizedList = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const react_2 = require("@chakra-ui/react");
const react_virtualized_1 = require("react-virtualized");
const VaultList_1 = require("@src/pages-vault/VaultList");
const useDebounce_1 = require("@src/pages-vault/useDebounce");
const graphqlBaseTypes_1 = require("@shared/generated/graphqlBaseTypes");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
//Inspiration => https://plnkr.co/edit/zjCwNeRZ7XtmFp1PDBsc?p=preview&preview
const VirtualizedList = ({ filter }) => {
    const debouncedSearchTerm = (0, useDebounce_1.useDebounce)(filter, 400);
    const { loginCredentials: LoginCredentials, TOTPSecrets } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const filteredItems = [...LoginCredentials, ...TOTPSecrets].filter((item) => {
        var _a;
        console.log('item', { item });
        const label = (_a = (item.kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP
            ? item.totp.label
            : item.loginCredentials.label)) !== null && _a !== void 0 ? _a : '';
        const url = (0, ExtensionDevice_1.getDecryptedSecretProp)(item, 'url');
        return (label.includes(debouncedSearchTerm) || url.includes(debouncedSearchTerm));
    });
    const ITEMS_COUNT = filteredItems.length;
    const ITEM_SIZE = 270;
    return ((0, jsx_runtime_1.jsx)(react_virtualized_1.AutoSizer, { children: ({ height, width }) => {
            const itemsPerRow = Math.floor(width / ITEM_SIZE);
            const rowCount = Math.ceil(ITEMS_COUNT / itemsPerRow);
            return ((0, jsx_runtime_1.jsx)(react_virtualized_1.List, { className: "List", width: width, height: height, rowCount: rowCount, rowHeight: ITEM_SIZE, rowRenderer: ({ index, key, style }) => {
                    const items = [];
                    const fromIndex = index * itemsPerRow;
                    const toIndex = Math.min(fromIndex + itemsPerRow, ITEMS_COUNT);
                    for (let i = fromIndex; i < toIndex; i++) {
                        items.push((0, jsx_runtime_1.jsx)(VaultList_1.VaultListItem, { secret: filteredItems[i] }, filteredItems[i].id));
                    }
                    return ((0, jsx_runtime_1.jsx)(react_2.Flex, Object.assign({ flexDirection: 'row', justifyContent: "center", alignItems: 'center', w: '100%', h: "100%", className: "Row", style: style }, { children: items }), key));
                } }));
        } }));
};
exports.VirtualizedList = VirtualizedList;
//# sourceMappingURL=VirtualizedList.js.map