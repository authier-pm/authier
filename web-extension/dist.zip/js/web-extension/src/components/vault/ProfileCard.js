"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const crypto_js_1 = require("crypto-js");
const page_url = process.env.PAGE_URL;
function ProfileCard() {
    var _a;
    const email = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.email;
    return ((0, jsx_runtime_1.jsx)(react_1.Center, Object.assign({ py: 6 }, { children: (0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ maxW: '320px', w: 'full', bg: (0, react_1.useColorModeValue)('white', 'gray.800'), boxShadow: '2xl', rounded: 'lg', p: 6, textAlign: 'center' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Avatar, { size: 'xl', src: `https://www.gravatar.com/avatar/${(0, crypto_js_1.MD5)(email)}}`, mb: 4, pos: 'relative', _after: {
                        content: '""',
                        w: 4,
                        h: 4,
                        bg: 'green.300',
                        border: '2px solid white',
                        rounded: 'full',
                        pos: 'absolute',
                        bottom: 0,
                        right: 3
                    } }), (0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ fontSize: '2xl', fontFamily: 'body' }, { children: email })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ onClick: () => chrome.tabs.create({
                        url: `${page_url}/pricing?portal=true`
                    }), mt: 8, flex: 1, fontSize: 'sm', rounded: 'full', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                        bg: 'blue.500'
                    }, _focus: {
                        bg: 'blue.500'
                    } }, { children: "Subscriptions" }))] })) })));
}
exports.default = ProfileCard;
//# sourceMappingURL=ProfileCard.js.map