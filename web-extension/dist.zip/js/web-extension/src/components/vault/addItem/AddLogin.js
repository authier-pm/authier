"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddLogin = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = require("react");
const react_router_dom_1 = require("react-router-dom");
const check_password_strength_1 = require("check-password-strength");
const PasswordGenerator_1 = require("@src/components/vault/PasswordGenerator");
const formik_1 = require("formik");
const icons_1 = require("@chakra-ui/icons");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const loginCredentialsSchema_1 = require("@src/util/loginCredentialsSchema");
const graphqlBaseTypes_1 = require("../../../../../shared/generated/graphqlBaseTypes");
const formikSharedTypes_1 = require("@shared/formikSharedTypes");
const AddLogin = () => {
    const navigate = (0, react_router_dom_1.useNavigate)();
    const [show, setShow] = (0, react_2.useState)(false);
    const [initPassword, setInitPassword] = (0, react_2.useState)('');
    const { isOpen, onToggle } = (0, react_1.useDisclosure)();
    const handleClick = () => setShow(!show);
    return ((0, jsx_runtime_1.jsxs)(react_1.Box, Object.assign({ width: { base: '90%', sm: '70%', lg: '60%', xl: '70%' } }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ enableReinitialize: true, initialValues: {
                    url: '',
                    password: initPassword,
                    label: '',
                    username: ''
                }, validationSchema: formikSharedTypes_1.PasswordSchema, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                    var _a;
                    const namePassPair = {
                        password: values.password,
                        username: values.username,
                        url: values.url,
                        label: values.label,
                        iconUrl: null
                    };
                    loginCredentialsSchema_1.loginCredentialsSchema.parse(namePassPair);
                    yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.addSecrets([
                        {
                            kind: graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS,
                            loginCredentials: namePassPair,
                            encrypted: yield ExtensionDevice_1.device.state.encrypt(JSON.stringify(namePassPair)),
                            createdAt: new Date().toJSON()
                        }
                    ]));
                    setSubmitting(false);
                    navigate(-1);
                }) }, { children: ({ values, isSubmitting, dirty, handleSubmit, errors, touched }) => {
                    const levelOfPsw = (0, check_password_strength_1.passwordStrength)(values.password);
                    return ((0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ p: 5, flexDirection: "column", w: "inherit" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.username && touched.username }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "username" }, { children: "Username:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "username", name: "username" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.username })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.password && touched.password }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password:" })), (0, jsx_runtime_1.jsx)(react_1.Progress, { value: levelOfPsw.id, size: "xs", colorScheme: "green", max: 3, min: 0, mb: 1 }), (0, jsx_runtime_1.jsxs)(react_1.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "password", name: "password", pr: "4.5rem", type: show ? 'text' : 'password' }), (0, jsx_runtime_1.jsx)(react_1.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: handleClick }, { children: show ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.password })] })), (0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ _focus: {
                                                bg: 'gray.200'
                                            }, fontSize: 'sm', size: "sm", onClick: () => navigate('/') }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                                bg: 'blue.500'
                                            }, _focus: {
                                                bg: 'blue.500'
                                            }, "aria-label": "Create" }, { children: "Create" }))] }))] })) })));
                } })), (0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ label: "Password generator" }, { children: (0, jsx_runtime_1.jsx)(react_1.IconButton, { w: "min-content", "aria-label": "Open password generator", icon: isOpen ? (0, jsx_runtime_1.jsx)(icons_1.ChevronUpIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ChevronDownIcon, {}), onClick: onToggle, m: 3 }) })), (0, jsx_runtime_1.jsx)(PasswordGenerator_1.PasswordGenerator, { isOpen: isOpen, setInitPassword: setInitPassword })] })));
};
exports.AddLogin = AddLogin;
//# sourceMappingURL=AddLogin.js.map