"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddTOTP = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const formik_1 = require("formik");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const graphqlBaseTypes_1 = require("@src/generated/graphqlBaseTypes");
const react_router_dom_1 = require("react-router-dom");
const formikSharedTypes_1 = require("@shared/formikSharedTypes");
const AddTOTP = () => {
    const navigate = (0, react_router_dom_1.useNavigate)();
    return ((0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ width: { base: '90%', sm: '70%', lg: '60%', xl: '70%' } }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ enableReinitialize: true, initialValues: {
                url: '',
                secret: '',
                label: '',
                iconUrl: '',
                digits: 6,
                period: 30
            }, validationSchema: formikSharedTypes_1.TOTPSchema, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                var _a;
                yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.addSecrets([
                    {
                        kind: graphqlBaseTypes_1.EncryptedSecretsType.TOTP,
                        totp: values,
                        encrypted: yield ExtensionDevice_1.device.state.encrypt(JSON.stringify(values)),
                        createdAt: new Date().toJSON()
                    }
                ]));
                setSubmitting(false);
                navigate(-1);
            }) }, { children: ({ isSubmitting, handleSubmit, dirty, errors, touched }) => {
                return ((0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ p: 5, flexDirection: "column", w: "inherit" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.secret && touched.secret }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "secret" }, { children: "Secret:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "secret", name: "secret" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.secret })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.digits && touched.digits }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "digits" }, { children: "Digits:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "digits", name: "digits" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.digits })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.period && touched.period }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "period" }, { children: "Period:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "period", name: "period" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.period })] })), (0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ _focus: {
                                            bg: 'gray.200'
                                        }, fontSize: 'sm', size: "sm", onClick: () => navigate('/') }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                            bg: 'blue.500'
                                        }, _focus: {
                                            bg: 'blue.500'
                                        }, "aria-label": "Create" }, { children: "Create" }))] }))] })) })));
            } })) })));
};
exports.AddTOTP = AddTOTP;
//# sourceMappingURL=AddTOTP.js.map