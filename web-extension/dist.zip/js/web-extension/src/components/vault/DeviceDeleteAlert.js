"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceDeleteAlert = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = require("@chakra-ui/react");
const icons_1 = require("@chakra-ui/icons");
const react_3 = require("react");
const react_4 = require("@chakra-ui/react");
const AccountDevices_codegen_1 = require("@shared/graphql/AccountDevices.codegen");
function DeviceDeleteAlert({ isOpen, id, onClose }) {
    const { refetch: devicesRefetch } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    const cancelRef = (0, react_3.useRef)();
    const [remove, setRemove] = (0, react_3.useState)(false);
    const [logoutDevice] = (0, AccountDevices_codegen_1.useLogoutDeviceMutation)({
        variables: {
            id: id
        }
    });
    const [removeDevice] = (0, AccountDevices_codegen_1.useRemoveDeviceMutation)({ variables: { id: id } });
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_2.AlertDialog, Object.assign({ motionPreset: "slideInBottom", 
            //@ts-expect-error TODO: fix this
            leastDestructiveRef: cancelRef, onClose: onClose, isOpen: isOpen, isCentered: true }, { children: [(0, jsx_runtime_1.jsx)(react_2.AlertDialogOverlay, {}), (0, jsx_runtime_1.jsxs)(react_2.AlertDialogContent, { children: [(0, jsx_runtime_1.jsx)(react_2.AlertDialogHeader, { children: "Logout confirmation" }), (0, jsx_runtime_1.jsx)(react_2.AlertDialogCloseButton, {}), (0, jsx_runtime_1.jsxs)(react_2.AlertDialogBody, Object.assign({ fontSize: 20 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Text, { children: "Are you sure you want to logout this device?" }), (0, jsx_runtime_1.jsxs)(react_4.HStack, { children: [(0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({ isChecked: remove, onChange: () => setRemove(!remove) }, { children: "Remove device from list" })), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: "You will have to confirm login", fontSize: "sm" }, { children: (0, jsx_runtime_1.jsx)(icons_1.QuestionOutlineIcon, {}) }))] })] })), (0, jsx_runtime_1.jsxs)(react_2.AlertDialogFooter, { children: [(0, jsx_runtime_1.jsx)(react_2.Button
                                //@ts-expect-error TODO: fix this
                                , Object.assign({ 
                                    //@ts-expect-error TODO: fix this
                                    ref: cancelRef, onClick: onClose }, { children: "No" })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ colorScheme: "red", ml: 3, onClick: () => __awaiter(this, void 0, void 0, function* () {
                                        if (remove) {
                                            yield removeDevice();
                                        }
                                        else {
                                            yield logoutDevice();
                                        }
                                        onClose();
                                        devicesRefetch();
                                    }) }, { children: "Yes" }))] })] })] })) }));
}
exports.DeviceDeleteAlert = DeviceDeleteAlert;
//# sourceMappingURL=DeviceDeleteAlert.js.map