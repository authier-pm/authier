"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteAlert = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = __importDefault(require("react"));
function DeleteAlert({ isOpen, onClose, deleteItem }) {
    const cancelRef = react_2.default.useRef();
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)(react_1.AlertDialog, Object.assign({ motionPreset: "slideInBottom", 
            //@ts-expect-error
            leastDestructiveRef: cancelRef, onClose: onClose, isOpen: isOpen, isCentered: true }, { children: [(0, jsx_runtime_1.jsx)(react_1.AlertDialogOverlay, {}), (0, jsx_runtime_1.jsxs)(react_1.AlertDialogContent, { children: [(0, jsx_runtime_1.jsx)(react_1.AlertDialogHeader, { children: "Delete confirmation" }), (0, jsx_runtime_1.jsx)(react_1.AlertDialogCloseButton, {}), (0, jsx_runtime_1.jsx)(react_1.AlertDialogBody, Object.assign({ fontSize: 20 }, { children: "Are you sure you want to delete this item?" })), (0, jsx_runtime_1.jsxs)(react_1.AlertDialogFooter, { children: [(0, jsx_runtime_1.jsx)(react_1.Button
                                //@ts-expect-error
                                , Object.assign({ 
                                    //@ts-expect-error
                                    ref: cancelRef, onClick: onClose }, { children: "No" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ colorScheme: "red", ml: 3, onClick: () => {
                                        onClose();
                                        deleteItem();
                                    } }, { children: "Yes" }))] })] })] })) }));
}
exports.DeleteAlert = DeleteAlert;
//# sourceMappingURL=DeleteAlert.js.map