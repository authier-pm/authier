"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasswordGenerator = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const generate_password_1 = require("generate-password");
const formik_1 = require("formik");
const PasswordGenerator = ({ isOpen, setInitPassword }) => {
    return (
    //@ts-ignore TODO: fix this
    (0, jsx_runtime_1.jsx)(react_1.Collapse, Object.assign({ in: isOpen, animateOpacity: true }, { children: (0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ flexDirection: "column", justifyContent: "center", alignItems: "center", m: 2 }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                    numbers: false,
                    symbols: false,
                    uppercase: true,
                    lowercase: true,
                    length: 8
                }, onSubmit: (values, { setSubmitting }) => {
                    setInitPassword((0, generate_password_1.generate)(Object.assign({}, values)));
                    setSubmitting(false);
                } }, { children: ({ isSubmitting }) => ((0, jsx_runtime_1.jsx)(formik_1.Form, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ justifyContent: "center", flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.HStack, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "numbers" }, { children: ({ field }) => ((0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({ id: "numbers", name: "numbers" }, field, { children: "numbers" }))) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "symbols" }, { children: ({ field }) => ((0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({ id: "symbols", name: "symbols" }, field, { children: "symbols" }))) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "uppercase" }, { children: ({ field }) => ((0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({ id: "uppercase", name: "uppercase" }, field, { defaultChecked: true }, { children: "uppercase" }))) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "lowercase" }, { children: ({ field }) => ((0, jsx_runtime_1.jsx)(react_1.Checkbox, Object.assign({ id: "lowercase", name: "lowercase" }, field, { defaultChecked: true }, { children: "lowercase" }))) })), (0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "length" }, { children: ({ field, form }) => ((0, jsx_runtime_1.jsxs)(react_1.NumberInput, Object.assign({ id: "length", name: "length", size: "md", maxW: 20, defaultValue: 8, min: 5, onChange: (val) => {
                                                form.setFieldValue(field.name, parseInt(val));
                                            } }, { children: [(0, jsx_runtime_1.jsx)(react_1.NumberInputField, {}), (0, jsx_runtime_1.jsxs)(react_1.NumberInputStepper, { children: [(0, jsx_runtime_1.jsx)(react_1.NumberIncrementStepper, {}), (0, jsx_runtime_1.jsx)(react_1.NumberDecrementStepper, {})] })] }))) }))] }), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ w: 150, alignSelf: "center", mt: 4, colorScheme: "teal", isLoading: isSubmitting, type: "submit" }, { children: "Generate" }))] })) })) })) })) })));
};
exports.PasswordGenerator = PasswordGenerator;
//# sourceMappingURL=PasswordGenerator.js.map