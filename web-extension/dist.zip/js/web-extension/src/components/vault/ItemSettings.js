"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VaultItemSettings = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = require("react");
const react_router_dom_1 = require("react-router-dom");
const check_password_strength_1 = require("check-password-strength");
const icons_1 = require("@chakra-ui/icons");
const PasswordGenerator_1 = require("@src/components/vault/PasswordGenerator");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const EncryptedSecrets_codegen_1 = require("@shared/graphql/EncryptedSecrets.codegen");
const formik_1 = require("formik");
const macro_1 = require("@lingui/macro");
const framer_motion_1 = require("framer-motion");
const formikSharedTypes_1 = require("@shared/formikSharedTypes");
const TOTPSecret = (secretProps) => {
    const { totp } = secretProps;
    const navigate = (0, react_router_dom_1.useNavigate)();
    const [updateSecret] = (0, EncryptedSecrets_codegen_1.useUpdateEncryptedSecretMutation)();
    const [show, setShow] = (0, react_2.useState)(false);
    const bg = (0, react_1.useColorModeValue)('white', 'gray.800');
    return ((0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: { opacity: 1 }, initial: { opacity: 0 }, exit: { opacity: 0 }, transition: { duration: 0.35 }, style: {
            width: '80%',
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsx)(react_1.Flex, Object.assign({ width: { base: '90%', sm: '70%', md: '60%', lg: '40%', xl: '30%' }, mt: 4, flexDirection: "column", boxShadow: '2xl', rounded: 'md', overflow: 'hidden', m: "auto", alignItems: 'center', bg: bg }, { children: (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: {
                    secret: totp.secret,
                    url: totp.url,
                    label: totp.label,
                    digits: totp.digits,
                    period: totp.period
                }, validationSchema: formikSharedTypes_1.TOTPSchema, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                    var _a, _b;
                    const secret = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.secrets.find(({ id }) => id === secretProps.id);
                    if (secret && ExtensionDevice_1.device.state) {
                        secret.encrypted = yield ExtensionDevice_1.device.state.encrypt(JSON.stringify(Object.assign(Object.assign({}, values), { iconUrl: '', digits: 6, period: 30 })));
                        yield updateSecret({
                            variables: {
                                id: secret.id,
                                patch: {
                                    encrypted: secret.encrypted,
                                    kind: secret.kind
                                }
                            }
                        });
                        yield ((_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.save());
                        setSubmitting(false);
                    }
                }) }, { children: ({ isSubmitting, dirty, handleSubmit, errors, touched }) => ((0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ width: '80%', mt: 5 }, { children: (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.secret && touched.secret }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "secret" }, { children: "Secret:" })), (0, jsx_runtime_1.jsxs)(react_1.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { id: "secret", pr: "4.5rem", type: show ? 'text' : 'password', as: react_1.Input, name: "secret" }), (0, jsx_runtime_1.jsx)(react_1.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: () => setShow(!show) }, { children: show ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.secret })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.digits && touched.digits }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "digits" }, { children: "Digits:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "digits", name: "digits" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.digits })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.period && touched.period }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "period" }, { children: "Period:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "period", name: "period" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.period })] })), (0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ _focus: {
                                                bg: 'gray.200'
                                            }, fontSize: 'sm', size: "sm", onClick: () => navigate(-1) }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                                bg: 'blue.500'
                                            }, _focus: {
                                                bg: 'blue.500'
                                            }, "aria-label": "Save" }, { children: "Save" }))] }))] })) })) }))) })) })) })));
};
const LoginSecret = (secretProps) => {
    const navigate = (0, react_router_dom_1.useNavigate)();
    const [show, setShow] = (0, react_2.useState)(false);
    const { isOpen, onToggle } = (0, react_1.useDisclosure)();
    const handleClick = () => setShow(!show);
    const [initPassword, setInitPassword] = (0, react_2.useState)('');
    const [updateSecret] = (0, EncryptedSecrets_codegen_1.useUpdateEncryptedSecretMutation)();
    return ((0, jsx_runtime_1.jsx)(framer_motion_1.motion.div, Object.assign({ animate: { opacity: 1 }, initial: { opacity: 0 }, exit: { opacity: 0 }, transition: { duration: 0.35 }, style: {
            width: '80%',
            display: 'contents'
        } }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ width: { base: '90%', sm: '70%', md: '60%', lg: '40%', xl: '30%' }, mt: 4, flexDirection: "column", boxShadow: '2xl', rounded: 'md', overflow: 'hidden', m: "auto", alignItems: 'center', bg: (0, react_1.useColorModeValue)('white', 'gray.800') }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ enableReinitialize: true, initialValues: {
                        url: secretProps.loginCredentials.url,
                        password: initPassword === ''
                            ? secretProps.loginCredentials.password
                            : initPassword,
                        label: secretProps.loginCredentials.label,
                        username: secretProps.loginCredentials.username
                    }, onSubmit: (values, { setSubmitting }) => __awaiter(void 0, void 0, void 0, function* () {
                        var _a, _b;
                        const secret = (_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.secrets.find(({ id }) => id === secretProps.id);
                        if (secret && ExtensionDevice_1.device.state) {
                            secret.encrypted = yield ExtensionDevice_1.device.state.encrypt(JSON.stringify({
                                password: values.password,
                                username: values.username,
                                url: values.url,
                                label: values.label,
                                iconUrl: null
                            }));
                            yield updateSecret({
                                variables: {
                                    id: secretProps.id,
                                    patch: {
                                        encrypted: secret.encrypted,
                                        kind: secretProps.kind
                                    }
                                }
                            });
                            yield ((_b = ExtensionDevice_1.device.state) === null || _b === void 0 ? void 0 : _b.save());
                            setSubmitting(false);
                        }
                    }) }, { children: ({ values, isSubmitting, dirty, handleSubmit, errors, touched }) => {
                        const levelOfPsw = (0, check_password_strength_1.passwordStrength)(values.password);
                        return ((0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ w: '80%' }, { children: (0, jsx_runtime_1.jsx)("form", Object.assign({ onSubmit: handleSubmit }, { children: (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ mt: 3, flexDirection: "column" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.url && touched.url }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "url" }, { children: "URL:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "url", name: "url" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.url })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.label && touched.label }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "label" }, { children: "Label:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "label", name: "label" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.label })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.username && touched.username }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "username" }, { children: "Username:" })), (0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "username", name: "username" }), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.username })] })), (0, jsx_runtime_1.jsxs)(react_1.FormControl, Object.assign({ isInvalid: !!errors.password && touched.password }, { children: [(0, jsx_runtime_1.jsx)(react_1.FormLabel, Object.assign({ htmlFor: "password" }, { children: "Password:" })), (0, jsx_runtime_1.jsx)(react_1.Progress, { value: levelOfPsw.id, size: "xs", colorScheme: "green", max: 3, min: 0, mb: 1 }), (0, jsx_runtime_1.jsxs)(react_1.InputGroup, Object.assign({ size: "md" }, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, { as: react_1.Input, id: "password", name: "password", pr: "4.5rem", type: show ? 'text' : 'password' }), (0, jsx_runtime_1.jsx)(react_1.InputRightElement, Object.assign({ width: "4.5rem" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ h: "1.75rem", size: "sm", onClick: handleClick }, { children: show ? 'Hide' : 'Show' })) }))] })), (0, jsx_runtime_1.jsx)(react_1.FormErrorMessage, { children: errors.password })] })), secretProps.loginCredentials.parseError && ((0, jsx_runtime_1.jsxs)(react_1.Alert, Object.assign({ status: "error", mt: 4 }, { children: [(0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Failed to parse this secret:" }), JSON.stringify(secretProps.loginCredentials.parseError)] }))), (0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: 'row', justifyContent: "flex-end", spacing: 1, my: 5, alignItems: 'baseline' }, { children: [(0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ _focus: {
                                                        bg: 'gray.200'
                                                    }, fontSize: 'sm', size: "sm", onClick: () => navigate(-1) }, { children: "Go back" })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ disabled: isSubmitting || !dirty, isLoading: isSubmitting, type: "submit", size: 'sm', fontSize: 'sm', bg: 'blue.400', color: 'white', boxShadow: '0px 1px 25px -5px rgb(66 153 225 / 48%), 0 10px 10px -5px rgb(66 153 225 / 43%)', _hover: {
                                                        bg: 'blue.500'
                                                    }, _focus: {
                                                        bg: 'blue.500'
                                                    }, "aria-label": "Save" }, { children: "Save" }))] }))] })) })) })));
                    } })), (0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ label: "Password generator" }, { children: (0, jsx_runtime_1.jsx)(react_1.IconButton, { w: "min-content", "aria-label": "Open password generator", icon: isOpen ? (0, jsx_runtime_1.jsx)(icons_1.ChevronUpIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ChevronDownIcon, {}), onClick: onToggle, m: 3 }) })), (0, jsx_runtime_1.jsx)(PasswordGenerator_1.PasswordGenerator, { isOpen: isOpen, setInitPassword: setInitPassword })] })) })));
};
const VaultItemSettings = () => {
    const [secret, setSecret] = (0, react_2.useState)(null);
    const params = (0, react_router_dom_1.useParams)();
    (0, react_2.useEffect)(() => {
        function loadSecret() {
            var _a;
            return __awaiter(this, void 0, void 0, function* () {
                const secret = yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.getSecretDecryptedById(params.secretId));
                setSecret(secret);
            });
        }
        loadSecret();
    }, []);
    if (!ExtensionDevice_1.device.state && !secret) {
        return (0, jsx_runtime_1.jsx)(react_1.Spinner, {});
    }
    if (!secret) {
        return (0, jsx_runtime_1.jsx)(react_1.Alert, { children: "Could not find this secret, it may be deleted" });
    }
    console.log('secret', secret);
    if (secret.kind === 'TOTP') {
        return (0, jsx_runtime_1.jsx)(TOTPSecret, Object.assign({}, secret));
    }
    else if (secret.kind === 'LOGIN_CREDENTIALS') {
        return (0, jsx_runtime_1.jsx)(LoginSecret, Object.assign({}, secret));
    }
    return null;
};
exports.VaultItemSettings = VaultItemSettings;
//# sourceMappingURL=ItemSettings.js.map