"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecretItemIcon = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const bi_1 = require("react-icons/bi");
function SecretItemIcon(props) {
    let hostname;
    if (props.iconUrl) {
        return ((0, jsx_runtime_1.jsx)(react_1.Image, { src: props.iconUrl, maxW: "30px", boxSize: "30px" }));
    }
    if (props.url) {
        try {
            hostname = new URL(props.url).hostname;
            return ((0, jsx_runtime_1.jsx)(react_1.Image, { src: `https://icons.duckduckgo.com/ip3/${hostname}.ico` // https://stackoverflow.com/a/10796141
                , maxW: "30px", boxSize: "30px" }));
        }
        catch (err) {
            return (0, jsx_runtime_1.jsx)(bi_1.BiFileBlank, {});
        }
    }
    return (0, jsx_runtime_1.jsx)(bi_1.BiFileBlank, {});
}
exports.SecretItemIcon = SecretItemIcon;
//# sourceMappingURL=SecretItemIcon.js.map