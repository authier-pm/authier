"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NavBar = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_2 = require("@chakra-ui/react");
const icons_1 = require("@chakra-ui/icons");
const wouter_1 = require("wouter");
const NavMenu_1 = require("@src/pages/NavMenu");
const UserNavMenu_1 = require("@src/pages/UserNavMenu");
const io_1 = require("react-icons/io");
const macro_1 = require("@lingui/macro");
const RefreshSecretsButton_1 = require("./RefreshSecretsButton");
const NavBar = () => {
    const { isOpen: isNavMenuOpen, onOpen: onNavMenuOpen, onClose: onNavMenuClose } = (0, react_2.useDisclosure)();
    const { isOpen: isUserMenuOpen, onOpen: onUserMenuOpen, onClose: onUserMenuClose } = (0, react_2.useDisclosure)();
    const [location, setLocation] = (0, wouter_1.useLocation)();
    const [lastPage, SetLastPage] = (0, react_1.useState)('/');
    const ActiveLink = (props) => {
        const [isActive] = (0, wouter_1.useRoute)(props.href);
        return ((0, jsx_runtime_1.jsx)(wouter_1.Link, Object.assign({}, props, { children: (0, jsx_runtime_1.jsx)("a", Object.assign({ className: isActive ? 'active' : '' }, { children: props.children })) })));
    };
    const bg = (0, react_2.useColorModeValue)('gray.100', 'gray.800');
    (0, react_1.useEffect)(() => {
        SetLastPage(location);
    }, []);
    return ((0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDir: "column", position: "fixed", top: "0", w: "100%", backgroundColor: bg, zIndex: 2 }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ p: 1, textAlign: "center", fontSize: "16px", borderBottom: "1px", borderBottomColor: "gray.300", width: "100%" }, { children: [(0, jsx_runtime_1.jsxs)(react_2.Box, Object.assign({ mr: "auto" }, { children: [isNavMenuOpen ? ((0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.CloseIcon, {}), onClick: () => {
                                    onNavMenuClose();
                                } })) : ((0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.HamburgerIcon, {}), onClick: () => {
                                    onNavMenuOpen();
                                    onUserMenuClose();
                                } })), (0, jsx_runtime_1.jsx)(RefreshSecretsButton_1.RefreshSecretsButton, {}), (0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: (0, macro_1.t) `Open vault`, "aria-label": (0, macro_1.t) `Open vault` }, { children: (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", ml: "2", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(io_1.IoMdArchive, {}), onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                                        chrome.tabs.create({ url: 'vault.html' });
                                    }) }) }))] })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ ml: "auto" }, { children: isUserMenuOpen ? ((0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.CloseIcon, {}), onClick: () => {
                                onUserMenuClose();
                            } })) : ((0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(icons_1.LockIcon, {}), onClick: () => {
                                onUserMenuOpen();
                                onNavMenuClose();
                            } })) }))] })), isNavMenuOpen && (0, jsx_runtime_1.jsx)(NavMenu_1.NavMenu, {}), isUserMenuOpen && (0, jsx_runtime_1.jsx)(UserNavMenu_1.UserNavMenu, {})] })));
};
exports.NavBar = NavBar;
//# sourceMappingURL=NavBar.js.map