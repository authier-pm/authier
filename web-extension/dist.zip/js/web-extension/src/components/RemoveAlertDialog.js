"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const button_1 = require("@chakra-ui/button");
const react_1 = require("@chakra-ui/react");
function RemoveAlertDialog({ isOpen, onClose, cancelRef }) {
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsx)(react_1.AlertDialog, Object.assign({ isOpen: isOpen, leastDestructiveRef: cancelRef, onClose: onClose }, { children: (0, jsx_runtime_1.jsx)(react_1.AlertDialogOverlay, { children: (0, jsx_runtime_1.jsxs)(react_1.AlertDialogContent, { children: [(0, jsx_runtime_1.jsx)(react_1.AlertDialogHeader, Object.assign({ fontSize: "lg", fontWeight: "bold" }, { children: "Delete password" })), (0, jsx_runtime_1.jsx)(react_1.AlertDialogBody, { children: "Are you sure? You can't undo this action afterwards." }), (0, jsx_runtime_1.jsxs)(react_1.AlertDialogFooter, { children: [(0, jsx_runtime_1.jsx)(button_1.Button, Object.assign({ ref: cancelRef, onClick: onClose }, { children: "Cancel" })), (0, jsx_runtime_1.jsx)(button_1.Button, Object.assign({ colorScheme: "red", onClick: onClose, ml: 3 }, { children: "Delete" }))] })] }) }) })) }));
}
exports.default = RemoveAlertDialog;
//# sourceMappingURL=RemoveAlertDialog.js.map