"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RefreshSecretsButton = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_2 = require("@chakra-ui/react");
const io_1 = require("react-icons/io");
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const macro_1 = require("@lingui/macro");
function RefreshSecretsButton() {
    const [isSyncing, setIsSyncing] = (0, react_1.useState)(false);
    const toast = (0, react_2.useToast)();
    return ((0, jsx_runtime_1.jsx)(react_2.Tooltip, Object.assign({ label: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Synchronize vault" }), "aria-label": (0, macro_1.t) `Synchronize vault` }, { children: (0, jsx_runtime_1.jsx)(react_2.IconButton, { size: "md", ml: "2", "aria-label": "menu", icon: (0, jsx_runtime_1.jsx)(io_1.IoMdRefreshCircle, {}), disabled: isSyncing, onClick: () => __awaiter(this, void 0, void 0, function* () {
                var _a;
                setIsSyncing(true);
                let res;
                try {
                    res = yield ((_a = ExtensionDevice_1.device.state) === null || _a === void 0 ? void 0 : _a.backendSync());
                }
                catch (error) {
                    setIsSyncing(false);
                    return;
                }
                toast({
                    title: (0, macro_1.t) `Sync successful`,
                    description: `added/updated ${res === null || res === void 0 ? void 0 : res.newAndUpdatedSecrets}, removed ${res === null || res === void 0 ? void 0 : res.removedSecrets}`,
                    status: 'success',
                    position: 'bottom',
                    isClosable: true
                });
                setIsSyncing(false);
            }) }) })));
}
exports.RefreshSecretsButton = RefreshSecretsButton;
//# sourceMappingURL=RefreshSecretsButton.js.map