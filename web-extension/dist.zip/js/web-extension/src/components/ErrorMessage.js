"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
function ErrorMessage({ message }) {
    return ((0, jsx_runtime_1.jsx)(react_1.Box, Object.assign({ my: 4 }, { children: (0, jsx_runtime_1.jsxs)(react_1.Alert, Object.assign({ status: "error", borderRadius: 4 }, { children: [(0, jsx_runtime_1.jsx)(react_1.AlertIcon, {}), (0, jsx_runtime_1.jsx)(react_1.AlertDescription, { children: message })] })) })));
}
exports.default = ErrorMessage;
//# sourceMappingURL=ErrorMessage.js.map