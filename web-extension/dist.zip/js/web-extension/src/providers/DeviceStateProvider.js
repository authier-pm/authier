"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceStateProvider = exports.DeviceStateContext = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const useDeviceState_1 = require("@src/util/useDeviceState");
const react_1 = require("react");
exports.DeviceStateContext = (0, react_1.createContext)({});
const DeviceStateProvider = ({ children }) => {
    const deviceState = (0, useDeviceState_1.useDeviceState)();
    return ((0, jsx_runtime_1.jsx)(exports.DeviceStateContext.Provider, Object.assign({ value: deviceState }, { children: children })));
};
exports.DeviceStateProvider = DeviceStateProvider;
//# sourceMappingURL=DeviceStateProvider.js.map