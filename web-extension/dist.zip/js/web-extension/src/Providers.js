"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.chakraCustomTheme = exports.toast = exports.ToastContainer = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = require("@lingui/react");
const core_1 = require("@lingui/core");
const UserProvider_1 = require("./providers/UserProvider");
const PopupRoutes_1 = __importDefault(require("./PopupRoutes"));
const chakraRawTheme_1 = require("../../shared/chakraRawTheme");
const DeviceStateProvider_1 = require("./providers/DeviceStateProvider");
const messages_1 = require("./locale/en-gb/messages");
const VaultRouter_1 = require("./pages-vault/VaultRouter");
_a = (0, react_1.createStandaloneToast)({
    theme: chakraRawTheme_1.chakraRawTheme
}), exports.ToastContainer = _a.ToastContainer, exports.toast = _a.toast;
core_1.i18n.load('en', messages_1.messages);
core_1.i18n.activate('en');
exports.chakraCustomTheme = (0, react_1.extendTheme)(chakraRawTheme_1.chakraRawTheme);
function Providers({ parent }) {
    return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsx)(react_1.ChakraProvider, Object.assign({ theme: exports.chakraCustomTheme }, { children: (0, jsx_runtime_1.jsx)(DeviceStateProvider_1.DeviceStateProvider, { children: (0, jsx_runtime_1.jsx)(UserProvider_1.UserProvider, { children: (0, jsx_runtime_1.jsx)(react_2.I18nProvider, Object.assign({ i18n: core_1.i18n }, { children: parent === 'vault' ? (0, jsx_runtime_1.jsx)(VaultRouter_1.VaultRouter, {}) : (0, jsx_runtime_1.jsx)(PopupRoutes_1.default, {}) })) }) }) })) }));
}
exports.default = Providers;
//# sourceMappingURL=Providers.js.map