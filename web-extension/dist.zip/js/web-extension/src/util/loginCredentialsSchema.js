"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.totpSchema = exports.loginCredentialsSchema = void 0;
const zod_1 = require("zod");
const secretUrlsSchema = zod_1.z.object({
    url: zod_1.z.string().min(1),
    label: zod_1.z.string().min(1),
    androidUri: zod_1.z.string().min(1).nullable().optional(),
    iosUri: zod_1.z.string().min(1).nullable().optional(),
    iconUrl: zod_1.z.string().min(1).nullable()
});
exports.loginCredentialsSchema = secretUrlsSchema.extend({
    username: zod_1.z.string().min(1),
    password: zod_1.z.string().min(1)
});
exports.totpSchema = secretUrlsSchema.extend({
    secret: zod_1.z.string().min(1),
    digits: zod_1.z.number(),
    period: zod_1.z.number(),
    url: zod_1.z.string().min(1).nullish()
});
//# sourceMappingURL=loginCredentialsSchema.js.map