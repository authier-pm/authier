"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeScriptInCurrentTab = exports.getCurrentTab = void 0;
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
function getCurrentTab() {
    return __awaiter(this, void 0, void 0, function* () {
        const tabs = yield webextension_polyfill_1.default.tabs.query({
            active: true,
            currentWindow: true
        });
        // Pulls current tab from browser.tabs.query response
        const currentTab = tabs[0];
        return currentTab;
    });
}
exports.getCurrentTab = getCurrentTab;
/**
 * Executes a string of Javascript on the current tab
 * @param code The string of code to execute on the current tab
 */
const executeScriptInCurrentTab = (code) => __awaiter(void 0, void 0, void 0, function* () {
    // Query for the active tab in the current window
    const currentTab = yield getCurrentTab();
    // Short circuits function execution is current tab isn't found
    if (!currentTab) {
        return;
    }
    const result = yield webextension_polyfill_1.default.tabs.executeScript(currentTab.id, {
        code
    });
    if (result[0]) {
        console.log('~ resul1t', result);
    }
    return result[0];
    // Executes the script in the current tab
});
exports.executeScriptInCurrentTab = executeScriptInCurrentTab;
//# sourceMappingURL=executeScriptInCurrentTab.js.map