"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useDeviceState = void 0;
const react_1 = require("react");
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
const graphqlBaseTypes_1 = require("../../../shared/generated/graphqlBaseTypes");
const debug_1 = __importDefault(require("debug"));
const ExtensionDevice_1 = require("@src/background/ExtensionDevice");
const executeScriptInCurrentTab_1 = require("./executeScriptInCurrentTab");
const client_1 = require("@trpc/client");
const link_1 = require("trpc-chrome/link");
const port = chrome.runtime.connect();
const trpc = (0, client_1.createTRPCProxyClient)({
    links: [(0, link_1.chromeLink)({ port })]
});
const log = (0, debug_1.default)('au:useDeviceState');
let registered = false; // we need to only register once
function useDeviceState() {
    const [currentTab, setCurrentTab] = (0, react_1.useState)(null);
    const [currentURL, setCurrentURL] = (0, react_1.useState)('');
    const [isFilling, setIsFilling] = (0, react_1.useState)(false);
    const [deviceState, setDeviceState] = (0, react_1.useState)(ExtensionDevice_1.device.state);
    const onStorageChange = (changes, areaName) => __awaiter(this, void 0, void 0, function* () {
        log('onStorageChange useDevice', areaName, changes);
        if (areaName === 'local' && changes.backgroundState) {
            setDeviceState(changes.backgroundState.newValue);
            log('states loaded from storage');
        }
    });
    //TODO move this whole thing into it' own hook
    (0, react_1.useEffect)(() => {
        log('registering storage change listener');
        (0, executeScriptInCurrentTab_1.getCurrentTab)().then((tab) => {
            var _a;
            setCurrentTab(tab !== null && tab !== void 0 ? tab : null);
            setCurrentURL((_a = tab === null || tab === void 0 ? void 0 : tab.url) !== null && _a !== void 0 ? _a : '');
        });
        if (registered) {
            return;
        }
        registered = true;
        webextension_polyfill_1.default.storage.onChanged.addListener(onStorageChange);
    }, []);
    const backgroundStateContext = {
        currentURL,
        deviceState,
        currentTab,
        get loginCredentials() {
            var _a;
            return ((_a = deviceState === null || deviceState === void 0 ? void 0 : deviceState.decryptedSecrets.filter(({ kind }) => {
                return kind === graphqlBaseTypes_1.EncryptedSecretType.LOGIN_CREDENTIALS;
            })) !== null && _a !== void 0 ? _a : []);
        },
        get TOTPSecrets() {
            var _a;
            return ((_a = deviceState === null || deviceState === void 0 ? void 0 : deviceState.decryptedSecrets.filter(({ kind }) => {
                return kind === graphqlBaseTypes_1.EncryptedSecretType.TOTP;
            })) !== null && _a !== void 0 ? _a : []);
        },
        setSecuritySettings: (config) => __awaiter(this, void 0, void 0, function* () {
            yield trpc.securitySettings.mutate(config);
        }),
        setDeviceState: (state) => __awaiter(this, void 0, void 0, function* () {
            ExtensionDevice_1.device.save(state);
            yield trpc.setDeviceState.mutate(state);
        }),
        device: ExtensionDevice_1.device,
        isFilling,
        registered
    };
    window['backgroundState'] = backgroundStateContext;
    return backgroundStateContext;
}
exports.useDeviceState = useDeviceState;
//# sourceMappingURL=useDeviceState.js.map