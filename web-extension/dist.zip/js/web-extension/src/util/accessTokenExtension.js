"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserFromToken = exports.removeToken = exports.setAccessToken = exports.getTokenFromLocalStorage = exports.accessToken = void 0;
const jwt_decode_1 = __importDefault(require("jwt-decode"));
const webextension_polyfill_1 = __importDefault(require("webextension-polyfill"));
exports.accessToken = null;
const getTokenFromLocalStorage = () => __awaiter(void 0, void 0, void 0, function* () {
    const storage = yield webextension_polyfill_1.default.storage.local.get('access-token');
    return storage['access-token'];
});
exports.getTokenFromLocalStorage = getTokenFromLocalStorage;
const setAccessToken = (s) => __awaiter(void 0, void 0, void 0, function* () {
    exports.accessToken = s;
    yield webextension_polyfill_1.default.storage.local.set({
        'access-token': s
    });
});
exports.setAccessToken = setAccessToken;
const removeToken = () => __awaiter(void 0, void 0, void 0, function* () {
    yield webextension_polyfill_1.default.storage.local.remove('access-token');
    exports.accessToken = '';
});
exports.removeToken = removeToken;
const getUserFromToken = () => __awaiter(void 0, void 0, void 0, function* () {
    return (0, jwt_decode_1.default)(yield (0, exports.getTokenFromLocalStorage)());
});
exports.getUserFromToken = getUserFromToken;
(() => __awaiter(void 0, void 0, void 0, function* () {
    exports.accessToken = yield (0, exports.getTokenFromLocalStorage)();
}))();
//# sourceMappingURL=accessTokenExtension.js.map