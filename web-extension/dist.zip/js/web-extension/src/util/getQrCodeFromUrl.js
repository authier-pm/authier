"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getQrCodeFromUrl = void 0;
const jsqr_1 = __importDefault(require("jsqr"));
const getQrCodeFromUrl = (imageUrl) => __awaiter(void 0, void 0, void 0, function* () {
    const response = yield fetch(imageUrl);
    const fileBlob = yield response.blob();
    const bitmap = yield createImageBitmap(fileBlob);
    //TODO: Change, this option is limited on Firefox https://github.com/BabylonJS/Spector.js/issues/137#issue-550442024
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    const context = canvas.getContext('2d');
    if (context) {
        //TODO: Solve this error
        context.drawImage(bitmap, 0, 0);
        const imageData = context.getImageData(0, 0, bitmap.width, bitmap.height);
        const result = (0, jsqr_1.default)(imageData.data, imageData.width, imageData.height);
        return result;
    }
});
exports.getQrCodeFromUrl = getQrCodeFromUrl;
//# sourceMappingURL=getQrCodeFromUrl.js.map