"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadAsFile = void 0;
const js_file_download_1 = __importDefault(require("js-file-download"));
const slugify_1 = __importDefault(require("slugify"));
const date_fns_1 = require("date-fns");
const downloadAsFile = (fileData, prefix, extension = 'csv') => {
    (0, js_file_download_1.default)(fileData, `${prefix}-${(0, slugify_1.default)((0, date_fns_1.formatISO)(new Date()), {
        replacement: '-'
    })}.${extension}`);
};
exports.downloadAsFile = downloadAsFile;
//# sourceMappingURL=downloadAsFile.js.map