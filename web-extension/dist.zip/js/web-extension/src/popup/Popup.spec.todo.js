"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const Popup_1 = require("./Popup");
const react_test_renderer_1 = __importDefault(require("react-test-renderer"));
const providers_1 = require("../../tests/providers");
it('component renders', () => {
    const ac = (0, providers_1.makeSsrClient)({});
    const tree = react_test_renderer_1.default.create((0, providers_1.wrapInFEProviders)((0, jsx_runtime_1.jsx)(Popup_1.Popup, {}), ac)).toJSON();
    expect(tree).toMatchSnapshot();
});
//# sourceMappingURL=Popup.spec.todo.js.map