"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Popup = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const wouter_1 = require("wouter");
const NavBar_1 = require("@src/components/NavBar");
const Home_1 = require("../pages/Home");
const core_1 = require("@lingui/core");
const QRcode_1 = require("@src/pages/QRcode");
const Devices_1 = __importDefault(require("@src/pages/Devices"));
const AboutPage_1 = require("@src/pages/AboutPage");
const debug_1 = __importDefault(require("debug"));
const log = (0, debug_1.default)('au:Popup');
core_1.i18n.activate('en');
const Popup = () => {
    const [location, setLocation] = (0, wouter_1.useLocation)();
    (0, react_1.useEffect)(() => {
        setLocation('/');
        //browser.runtime.sendMessage({ popupMounted: true })
    }, []);
    return ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(NavBar_1.NavBar, {}), (0, jsx_runtime_1.jsxs)(wouter_1.Switch, Object.assign({ location: location }, { children: [(0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/", component: Home_1.Home }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/secrets", component: Home_1.Home }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/popup.html", component: Home_1.Home }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/qr-code", component: QRcode_1.QRCode }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/devices", component: Devices_1.default }), (0, jsx_runtime_1.jsx)(wouter_1.Route, { path: "/about", component: AboutPage_1.AboutPage })] }))] }));
};
exports.Popup = Popup;
//# sourceMappingURL=Popup.js.map