"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NavMenu = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const icons_1 = require("@chakra-ui/icons");
const wouter_1 = require("wouter");
const AddTOTPSecretButton_1 = require("@src/components/pages/AddTOTPSecretButton");
const NavMenu = () => {
    const bg = (0, react_1.useColorModeValue)('teal.200', 'teal.700');
    return ((0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: "row", bgColor: bg, justify: "center", p: "10px" }, { children: [(0, jsx_runtime_1.jsx)(react_1.ButtonGroup, Object.assign({ spacing: 4 }, { children: (0, jsx_runtime_1.jsxs)(react_1.Stack, { children: [(0, jsx_runtime_1.jsx)(wouter_1.Link, Object.assign({ to: "/" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ colorScheme: "teal" }, { children: "Secrets" })) })), (0, jsx_runtime_1.jsx)(AddTOTPSecretButton_1.AddTOTPSecretButton, {})] }) })), (0, jsx_runtime_1.jsx)(react_1.ButtonGroup, Object.assign({ spacing: 4, variant: "solid", m: "10px" }, { children: (0, jsx_runtime_1.jsxs)(react_1.Stack, Object.assign({ direction: "column" }, { children: [(0, jsx_runtime_1.jsx)(wouter_1.Link, Object.assign({ to: "/about" }, { children: (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ leftIcon: (0, jsx_runtime_1.jsx)(icons_1.InfoOutlineIcon, {}) }, { children: "About" })) })), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ onClick: () => {
                                chrome.tabs.create({ url: 'vault.html' });
                            } }, { children: "My vault" }))] })) }))] })));
};
exports.NavMenu = NavMenu;
//# sourceMappingURL=NavMenu.js.map