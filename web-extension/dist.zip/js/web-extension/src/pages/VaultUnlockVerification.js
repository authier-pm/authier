"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VaultUnlockVerification = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_2 = require("@chakra-ui/react");
const formik_1 = require("formik");
const icons_1 = require("@chakra-ui/icons");
const macro_1 = require("@lingui/macro");
const generateEncryptionKey_1 = require("@util/generateEncryptionKey");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const Providers_1 = require("@src/Providers");
function VaultUnlockVerification() {
    const [showPassword, setShowPassword] = (0, react_1.useState)(false);
    const { setDeviceState, device } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    const { lockedState } = device;
    if (!lockedState) {
        return null;
    }
    return ((0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ flexDirection: "column", width: "315px", p: 4 }, { children: [(0, jsx_runtime_1.jsx)(react_2.Center, { children: (0, jsx_runtime_1.jsx)(icons_1.LockIcon, { boxSize: "50px", mx: 20, my: 3 }) }), (0, jsx_runtime_1.jsx)(formik_1.Formik, Object.assign({ initialValues: { password: '' }, onSubmit: (values, { setSubmitting }) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        const masterEncryptionKey = yield (0, generateEncryptionKey_1.generateEncryptionKey)(values.password, (0, generateEncryptionKey_1.base64_to_buf)(lockedState.encryptionSalt));
                        const encryptedDataBuff = (0, generateEncryptionKey_1.base64_to_buf)(lockedState.authSecretEncrypted);
                        const iv = encryptedDataBuff.slice(16, 16 + 12);
                        const data = encryptedDataBuff.slice(16 + 12);
                        let decryptedContent = yield window.crypto.subtle.decrypt({ name: 'AES-GCM', iv }, masterEncryptionKey, data);
                        let currentAddDeviceSecret = generateEncryptionKey_1.dec.decode(decryptedContent);
                        if (currentAddDeviceSecret !== lockedState.authSecret) {
                            throw new Error((0, macro_1.t) `Incorrect password`);
                        }
                        setDeviceState(Object.assign({ masterEncryptionKey: yield (0, generateEncryptionKey_1.cryptoKeyToString)(masterEncryptionKey) }, lockedState));
                        device.startLockInterval(lockedState.lockTime);
                        device.rerenderViews();
                        setSubmitting(false);
                    }
                    catch (err) {
                        console.log(err);
                        (0, Providers_1.toast)({
                            title: err.message,
                            status: 'error',
                            isClosable: true
                        });
                    }
                }) }, { children: (props) => ((0, jsx_runtime_1.jsxs)(formik_1.Form, { children: [(0, jsx_runtime_1.jsx)(formik_1.Field, Object.assign({ name: "password" }, { children: ({ field, form }) => ((0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ isInvalid: form.errors.password && form.touched.password }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ htmlFor: "password" }, { children: (0, jsx_runtime_1.jsx)(react_2.Heading, Object.assign({ size: "md" }, { children: "Re-enter your Master Password" })) })), (0, jsx_runtime_1.jsxs)(react_2.InputGroup, { children: [(0, jsx_runtime_1.jsx)(react_2.Input, Object.assign({}, field, { type: showPassword ? 'text' : 'password' })), (0, jsx_runtime_1.jsx)(react_2.InputRightElement, Object.assign({ width: "3rem" }, { children: (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ h: "1.5rem", size: "sm", onClick: () => setShowPassword(!showPassword) }, { children: showPassword ? (0, jsx_runtime_1.jsx)(icons_1.ViewOffIcon, {}) : (0, jsx_runtime_1.jsx)(icons_1.ViewIcon, {}) })) }))] }), (0, jsx_runtime_1.jsx)(react_2.FormErrorMessage, { children: form.errors.password })] }))) })), (0, jsx_runtime_1.jsx)(react_2.Button, Object.assign({ colorScheme: "teal", variant: "outline", isDisabled: props.values.password.length < 3, type: "submit", width: "full", mt: 4, isLoading: props.isSubmitting }, { children: (0, jsx_runtime_1.jsx)(macro_1.Trans, { children: "Unlock vault" }) }))] })) }))] })));
}
exports.VaultUnlockVerification = VaultUnlockVerification;
//# sourceMappingURL=VaultUnlockVerification.js.map