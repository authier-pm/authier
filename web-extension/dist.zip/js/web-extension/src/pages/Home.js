"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Home = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("react");
const react_2 = require("@chakra-ui/react");
const otplib_1 = require("otplib");
const DeviceStateProvider_1 = require("@src/providers/DeviceStateProvider");
const icons_1 = require("@chakra-ui/icons");
const AuthsList_1 = require("@src/components/pages/AuthsList");
const Home = () => {
    const [seconds, setRemainingSeconds] = (0, react_1.useState)(otplib_1.authenticator.timeRemaining());
    const { deviceState, TOTPSecrets, currentURL } = (0, react_1.useContext)(DeviceStateProvider_1.DeviceStateContext);
    (0, react_2.useInterval)(() => {
        setRemainingSeconds(otplib_1.authenticator.timeRemaining());
    }, 1000);
    const [filterByTLDManual, setFilterByTLD] = (0, react_1.useState)(null); // when in vault or browser config, show all: ;
    const filterByTLD = !currentURL
        ? true
        : filterByTLDManual === null
            ? currentURL.startsWith('http')
            : filterByTLDManual;
    return ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)(react_2.Flex, Object.assign({ position: "sticky", align: "center", pl: 4, pr: 4, mt: '56px' }, { children: [(0, jsx_runtime_1.jsxs)(react_2.FormControl, Object.assign({ display: "flex", alignItems: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_2.FormLabel, Object.assign({ mb: "0" }, { children: "Filter by TLD" })), (0, jsx_runtime_1.jsx)(react_2.Switch, { mr: "auto", isChecked: filterByTLD, onChange: (enabled) => {
                                    setFilterByTLD(enabled.target.checked);
                                } })] })), (0, jsx_runtime_1.jsx)(react_2.IconButton, { mr: 15, colorScheme: "blue", "aria-label": "Add item", icon: (0, jsx_runtime_1.jsx)(icons_1.AddIcon, {}), rounded: 'full', onClick: () => __awaiter(void 0, void 0, void 0, function* () {
                            chrome.tabs.create({ url: 'vault.html#/addItem' });
                        }) }), deviceState && TOTPSecrets.length > 0 && ((0, jsx_runtime_1.jsx)(react_2.CircularProgress, { min: 1, ml: "auto", max: 30, value: 30 - seconds, valueText: seconds.toString(), size: "40px" }))] })), (0, jsx_runtime_1.jsx)(react_2.Box, Object.assign({ height: 300, width: 350, pr: 5, pl: 5, mb: 2 }, { children: (0, jsx_runtime_1.jsx)(react_2.Grid, Object.assign({ gap: 3, mb: 5 }, { children: (0, jsx_runtime_1.jsx)(AuthsList_1.AuthsList, { filterByTLD: filterByTLD }) })) }))] }));
};
exports.Home = Home;
//# sourceMappingURL=Home.js.map