"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QRCode = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const react_2 = require("react");
const react_qr_code_1 = __importDefault(require("react-qr-code"));
const QRcode_codegen_1 = require("./QRcode.codegen");
const wouter_1 = require("wouter");
const icons_1 = require("@chakra-ui/icons");
const UserProvider_1 = require("@src/providers/UserProvider");
function QRCode() {
    const [interval, setInterval] = (0, react_2.useState)(500);
    const [location, setLocation] = (0, wouter_1.useLocation)();
    const [count, setCount] = (0, react_2.useState)(1);
    const { userId } = (0, react_2.useContext)(UserProvider_1.UserContext);
    const { data, error, startPolling, stopPolling } = (0, QRcode_codegen_1.useDeviceCountQuery)();
    (0, react_2.useEffect)(() => {
        startPolling(interval);
    }, []);
    (0, react_2.useEffect)(() => {
        var _a, _b;
        const devicesCount = (_b = (_a = data === null || data === void 0 ? void 0 : data.me) === null || _a === void 0 ? void 0 : _a.devicesCount) !== null && _b !== void 0 ? _b : 0;
        if (typeof count !== undefined && devicesCount > count) {
            stopPolling();
            setLocation('/');
        }
    }, [data]);
    return ((0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "column", alignItems: "center" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ as: "h3", size: "lg" }, { children: "Scan QR code in app" })), (0, jsx_runtime_1.jsx)(react_qr_code_1.default, { size: 200, value: userId }), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ variant: "outline", onClick: () => {
                    stopPolling();
                    setLocation('/');
                }, leftIcon: (0, jsx_runtime_1.jsx)(icons_1.ArrowForwardIcon, {}) }, { children: "Skip" }))] })));
}
exports.QRCode = QRCode;
//# sourceMappingURL=QRcode.js.map