"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AboutPage = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const package_json_1 = __importDefault(require("../../package.json"));
const macro_1 = require("@lingui/macro");
const layout_1 = require("@chakra-ui/layout");
const react_1 = require("@chakra-ui/react");
const AboutPage = () => {
    return ((0, jsx_runtime_1.jsx)(layout_1.Center, Object.assign({ m: 2, p: 2 }, { children: (0, jsx_runtime_1.jsxs)(layout_1.Stack, Object.assign({ direction: "column" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Heading, Object.assign({ size: "md" }, { children: "Authier web extension" })), (0, jsx_runtime_1.jsx)(react_1.Text, Object.assign({ fontSize: 'large' }, { children: (0, jsx_runtime_1.jsxs)(macro_1.Trans, { children: ["Version: ", package_json_1.default.version] }) }))] })) })));
};
exports.AboutPage = AboutPage;
//# sourceMappingURL=AboutPage.js.map