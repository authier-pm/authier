"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const react_1 = require("@chakra-ui/react");
const icons_1 = require("@chakra-ui/icons");
const io_1 = require("react-icons/io");
const AccountDevices_codegen_1 = require("@shared/graphql/AccountDevices.codegen");
function Devices() {
    var _a;
    const { data, loading, error } = (0, AccountDevices_codegen_1.useMyDevicesQuery)();
    return ((0, jsx_runtime_1.jsxs)(react_1.Box, { children: [data && !loading ? ((_a = data.me) === null || _a === void 0 ? void 0 : _a.devices.map((device) => {
                return ((0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ boxShadow: "xl", 
                    //bg="white"
                    m: 2, pb: 2, flexDirection: "column", borderWidth: "5px" }, { children: [(0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ justifyContent: "flex-end", mr: 2 }, { children: [(0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ hasArrow: true, label: "Main device", fontSize: "sm" }, { children: (0, jsx_runtime_1.jsx)(react_1.IconButton, { size: "xs", variant: "unstyled", "aria-label": "Main device", fontSize: "17px", icon: (0, jsx_runtime_1.jsx)(icons_1.StarIcon, { color: "gold" }) }) })), (0, jsx_runtime_1.jsx)(react_1.Tooltip, Object.assign({ hasArrow: true, label: "Remove device", fontSize: "sm" }, { children: (0, jsx_runtime_1.jsx)(react_1.IconButton, { size: "xs", variant: "unstyled", "aria-label": "Remove device", fontSize: "17px", icon: (0, jsx_runtime_1.jsx)(icons_1.DeleteIcon, {}) }) }))] })), (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ justify: "flex-start", align: "center", flexDirection: "row" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Icon, { as: io_1.IoIosPhonePortrait, w: 20, h: 20 }), (0, jsx_runtime_1.jsxs)(react_1.Flex, Object.assign({ flexDirection: "column", ml: "5px", fontSize: "md" }, { children: [(0, jsx_runtime_1.jsx)(react_1.Text, { children: device.name }), (0, jsx_runtime_1.jsx)(react_1.Text, { children: device.lastIpAddress }), (0, jsx_runtime_1.jsxs)(react_1.Text, { children: ["Location: ", device.lastGeoLocation] })] }))] }))] }), device.lastIpAddress));
            })) : ((0, jsx_runtime_1.jsx)(react_1.Spinner, {})), (0, jsx_runtime_1.jsx)(react_1.Button, Object.assign({ onClick: () => {
                    //setLocation('/qr-code')
                } }, { children: "Add device" }))] }));
}
exports.default = Devices;
//# sourceMappingURL=Devices.js.map