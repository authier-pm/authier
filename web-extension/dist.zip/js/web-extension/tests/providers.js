"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.wrapInFEProviders = exports.makeSsrClient = void 0;
const jsx_runtime_1 = require("@emotion/react/jsx-runtime");
const client_1 = require("@apollo/client");
const schema_1 = require("@apollo/client/link/schema");
const react_1 = require("@lingui/react");
const wouter_1 = require("wouter");
//@ts-expect-error
const gqlSchemas_1 = require("gqlSchemas");
const core_1 = require("@lingui/core");
const static_location_1 = __importDefault(require("wouter/static-location"));
const makeSsrClient = (ctx) => {
    return new client_1.ApolloClient({
        cache: new client_1.InMemoryCache(),
        ssrMode: true,
        link: new schema_1.SchemaLink({
            schema: gqlSchemas_1.gqlSchema,
            context: ctx
        })
    });
};
exports.makeSsrClient = makeSsrClient;
/**
 * almost all of our FE components need these providers
 */
const wrapInFEProviders = (jsx, client) => {
    return ((0, jsx_runtime_1.jsx)(client_1.ApolloProvider, Object.assign({ client: client }, { children: (0, jsx_runtime_1.jsx)(react_1.I18nProvider, Object.assign({ i18n: core_1.i18n }, { children: (0, jsx_runtime_1.jsx)(wouter_1.Router, Object.assign({ hook: (0, static_location_1.default)('/') }, { children: jsx })) })) })));
};
exports.wrapInFEProviders = wrapInFEProviders;
//# sourceMappingURL=providers.js.map